function convertToMeters(value, unit) {
    if (unit === 'feet') {
        return value * 0.3048;
    } else if (unit === 'inches') {
        return value * 0.0254;
    } else {
        return value;
    }
}

function convertToInches(value, unit) {
    switch (unit) {
        case 'meters':
            return value * 39.3701; // Convert meters to inches
        case 'centimeters':
            return value * 0.393701; // Convert centimeters to inches
        case 'feet':
            return value * 12; // Convert feet to inches
        default:
            return value; // Assume same unit as inches
    }
}

function convertToFeet(value, unit) {
    switch (unit) {
        case 'meters':
            return value * 3.28084;
        case 'inches':
            return value / 12;
        case 'centimeters':
            return value / 30.48;
        case 'feet':
        default:
            return value;
    }
}
function convertToYards(value, unit) {
    switch (unit) {
        case 'feet':
            return value / 3;
        case 'meters':
            return value * 1.09361;
        case 'inches':
            return value / 36;
        case 'centimeters':
            return value / 91.44;
        case 'yards':
        default:
            return value;
    }
}

function convertToCentimeters(value, unit) {
    switch (unit) {
        case 'inches':
            return value * 2.54;
        case 'centimeters':
        default:
            return value;
    }
}






function calculatePavers() {
    const areaWidth = parseFloat(document.getElementById('areaWidth').value);
    const areaLength = parseFloat(document.getElementById('areaLength').value);
    const paverWidth = parseFloat(document.getElementById('paverWidth').value);
    const paverLength = parseFloat(document.getElementById('paverLength').value);

    const areaWidthUnit = document.getElementById('areaWidthUnit').value;
    const areaLengthUnit = document.getElementById('areaLengthUnit').value;
    const paverWidthUnit = document.getElementById('paverWidthUnit').value;
    const paverLengthUnit = document.getElementById('paverLengthUnit').value;

    if (isNaN(areaWidth) || isNaN(areaLength) || isNaN(paverWidth) || isNaN(paverLength)) {
        alert('Please enter valid numbers');
        return;
    }

    const areaWidthMeters = convertToMeters(areaWidth, areaWidthUnit); // Call the convertToMeters function correctly
    const areaLengthMeters = convertToMeters(areaLength, areaLengthUnit); // Call the convertToMeters function correctly
    const paverWidthMeters = convertToMeters(paverWidth, paverWidthUnit);
    const paverLengthMeters = convertToMeters(paverLength, paverLengthUnit);

    const area = areaWidthMeters * areaLengthMeters;
    const paverArea = paverWidthMeters * paverLengthMeters;
    const paversNeeded = Math.ceil(area / paverArea);

    document.getElementById('result').textContent = `You will need ${paversNeeded} pavers to cover an area of ${areaWidth} ${areaWidthUnit} by ${areaLength} ${areaLengthUnit}. Each paver is ${paverWidth} ${paverWidthUnit} by ${paverLength} ${paverLengthUnit}.`;
    document.getElementById('result').style.display = 'block';
}

function calculateTiles() {
    const roomWidth = parseFloat(document.getElementById('roomWidth').value);
    const roomLength = parseFloat(document.getElementById('roomLength').value);
    const tileWidth = parseFloat(document.getElementById('tileWidth').value);
    const tileLength = parseFloat(document.getElementById('tileLength').value);

    const roomWidthUnit = document.getElementById('roomWidthUnit').value;
    const roomLengthUnit = document.getElementById('roomLengthUnit').value;
    const tileWidthUnit = document.getElementById('tileWidthUnit').value;
    const tileLengthUnit = document.getElementById('tileLengthUnit').value;

    if (isNaN(roomWidth) || isNaN(roomLength) || isNaN(tileWidth) || isNaN(tileLength)) {
        alert('Please enter valid numbers');
        return;
    }

    const roomWidthMeters = convertToMeters(roomWidth, roomWidthUnit);
    const roomLengthMeters = convertToMeters(roomLength, roomLengthUnit);
    const tileWidthMeters = convertToMeters(tileWidth, tileWidthUnit);
    const tileLengthMeters = convertToMeters(tileLength, tileLengthUnit);

    const roomArea = roomWidthMeters * roomLengthMeters;
    const tileArea = tileWidthMeters * tileLengthMeters;
    const tilesNeeded = Math.ceil(roomArea / tileArea);

    document.getElementById('result').textContent = `You will need ${tilesNeeded} tiles to cover a room of ${roomWidth} ${roomWidthUnit} by ${roomLength} ${roomLengthUnit}. Each tile is ${tileWidth} ${tileWidthUnit} by ${tileLength} ${tileLengthUnit}.`;
    document.getElementById('result').style.display = 'block';
}

function calculateTruss() {
    const roofWidth = parseFloat(document.getElementById('roofWidth').value);
    const roofHeight = parseFloat(document.getElementById('roofHeight').value);

    const roofWidthUnit = document.getElementById('roofWidthUnit').value;
    const roofHeightUnit = document.getElementById('roofHeightUnit').value;

    if (isNaN(roofWidth) || isNaN(roofHeight)) {
        alert('Please enter valid numbers');
        return;
    }

    let roofWidthFeet, roofHeightFeet;

    if (roofWidthUnit === 'meters') {
        roofWidthFeet = roofWidth * 3.28084; // Convert meters to feet
    } else if (roofWidthUnit === 'inches') {
        roofWidthFeet = roofWidth / 12; // Convert inches to feet
    } else {
        roofWidthFeet = roofWidth; // Feet input
    }

    if (roofHeightUnit === 'meters') {
        roofHeightFeet = roofHeight * 3.28084; // Convert meters to feet
    } else if (roofHeightUnit === 'inches') {
        roofHeightFeet = roofHeight / 12; // Convert inches to feet
    } else {
        roofHeightFeet = roofHeight; // Feet input
    }

    const halfSpan = roofWidthFeet / 2;
    const pitchAngleRad = Math.atan(roofHeightFeet / halfSpan);
    const pitchAngleDeg = (pitchAngleRad * 180) / Math.PI;

    const trussHeight = roofHeightFeet / 2;

    const resultText = `To build a gambrel truss with a roof width of ${roofWidth} ${roofWidthUnit} and a roof height of ${roofHeight} ${roofHeightUnit}, each half of the truss should have a height of ${trussHeight.toFixed(2)} feet, and the pitch angle is approximately ${pitchAngleDeg.toFixed(2)} degrees.`;

    const resultElement = document.getElementById('result');
    resultElement.innerHTML = `<div>${resultText}</div>`;
    resultElement.style.display = 'block'; // Show the result box
}


function calculateSubwayTiles() {
    const wallWidth = parseFloat(document.getElementById('wallWidth').value);
    const wallHeight = parseFloat(document.getElementById('wallHeight').value);
    const tileWidth = parseFloat(document.getElementById('tileWidth').value);
    const tileHeight = parseFloat(document.getElementById('tileHeight').value);

    const wallWidthUnit = document.getElementById('wallWidthUnit').value;
    const wallHeightUnit = document.getElementById('wallHeightUnit').value;
    const tileWidthUnit = document.getElementById('tileWidthUnit').value;
    const tileHeightUnit = document.getElementById('tileHeightUnit').value;

    if (isNaN(wallWidth) || isNaN(wallHeight) || isNaN(tileWidth) || isNaN(tileHeight)) {
        alert('Please enter valid numbers');
        return;
    }

    const wallWidthMeters = convertToMeters(wallWidth, wallWidthUnit);
    const wallHeightMeters = convertToMeters(wallHeight, wallHeightUnit);
    const tileWidthMeters = convertToMeters(tileWidth, tileWidthUnit);
    const tileHeightMeters = convertToMeters(tileHeight, tileHeightUnit);

    const wallArea = wallWidthMeters * wallHeightMeters;
    const tileArea = tileWidthMeters * tileHeightMeters;
    const tilesNeeded = Math.ceil(wallArea / tileArea);

    document.getElementById('result').textContent = `You will need ${tilesNeeded} tiles to cover a subway of ${wallWidth} ${wallWidthUnit} by ${wallHeight} ${wallHeightUnit}. Each tile is ${tileWidth} ${tileWidthUnit} by ${tileHeight} ${tileHeightUnit}.`;
    document.getElementById('result').style.display = 'block'; // Show the result box
}
function calculatePlate() {
    const plateLength = parseFloat(document.getElementById('plateLength').value);
    const plateWidth = parseFloat(document.getElementById('plateWidth').value);
    const plateThickness = parseFloat(document.getElementById('plateThickness').value);

    const plateLengthUnit = document.getElementById('plateLengthUnit').value;
    const plateWidthUnit = document.getElementById('plateWidthUnit').value;
    const plateThicknessUnit = document.getElementById('plateThicknessUnit').value;

    if (isNaN(plateLength) || isNaN(plateWidth) || isNaN(plateThickness)) {
        alert('Please enter valid numbers');
        return;
    }

    const plateLengthMeters = convertToMeters(plateLength, plateLengthUnit);
    const plateWidthMeters = convertToMeters(plateWidth, plateWidthUnit);
    const plateThicknessMeters = convertToMeters(plateThickness, plateThicknessUnit);

    const plateVolume = plateLengthMeters * plateWidthMeters * plateThicknessMeters;

    document.getElementById('result').textContent = `The plate volume is ${plateVolume.toFixed(2)} cubic ${plateLengthUnit}.`;
    document.getElementById('result').style.display = 'block'; // Show the result box
}
function calculateJunctionBox() {
    const width = parseFloat(document.getElementById('width').value);
    const length = parseFloat(document.getElementById('length').value);
    const depth = parseFloat(document.getElementById('depth').value);

    const widthUnit = document.getElementById('widthUnit').value;
    const lengthUnit = document.getElementById('lengthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;

    if (isNaN(width) || isNaN(length) || isNaN(depth)) {
        alert('Please enter valid numbers for width, length, and depth.');
        return;
    }

    let convertedWidth = width;
    let convertedLength = length;
    let convertedDepth = depth;

    if (widthUnit === 'feet') {
        convertedWidth *= 12;
    } else if (widthUnit === 'meters') {
        convertedWidth *= 39.3701;
    }

    if (lengthUnit === 'feet') {
        convertedLength *= 12;
    } else if (lengthUnit === 'meters') {
        convertedLength *= 39.3701;
    }

    if (depthUnit === 'feet') {
        convertedDepth *= 12;
    } else if (depthUnit === 'meters') {
        convertedDepth *= 39.3701;
    }

    const volume = convertedWidth * convertedLength * convertedDepth;
    document.getElementById('result').textContent = `The volume of the junction box is ${volume.toFixed(2)} cubic inches.`;
    document.getElementById('result').style.display = 'block';
}
function calculateTransformer() {
    const primaryVoltage = parseFloat(document.getElementById('primaryVoltage').value);
    const secondaryVoltage = parseFloat(document.getElementById('secondaryVoltage').value);
    const current = parseFloat(document.getElementById('current').value);

    const primaryVoltageUnit = document.getElementById('primaryVoltageUnit').value;
    const secondaryVoltageUnit = document.getElementById('secondaryVoltageUnit').value;

    if (isNaN(primaryVoltage) || isNaN(secondaryVoltage) || isNaN(current)) {
        alert('Please enter valid numbers for primary voltage, secondary voltage, and current.');
        return;
    }

    let convertedPrimaryVoltage = primaryVoltage;
    let convertedSecondaryVoltage = secondaryVoltage;

    if (primaryVoltageUnit === 'kV') {
        convertedPrimaryVoltage *= 1000;
    }

    if (secondaryVoltageUnit === 'kV') {
        convertedSecondaryVoltage *= 1000;
    }

    const power = convertedPrimaryVoltage * current;
    const efficiency = (convertedSecondaryVoltage / convertedPrimaryVoltage) * 100;
    const resultText = `Power: ${power} watts, Efficiency: ${efficiency}%`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}
function calculatePondLinerSize() {
    const pondWidth = parseFloat(document.getElementById('pondWidth').value);
    const pondLength = parseFloat(document.getElementById('pondLength').value);
    const pondWidthUnit = document.getElementById('pondWidthUnit').value;
    const pondLengthUnit = document.getElementById('pondLengthUnit').value;

    if (isNaN(pondWidth) || isNaN(pondLength)) {
        alert('Please enter valid numbers for pond width and length.');
        return;
    }

    let widthInMeters = pondWidthUnit === 'meters' ? pondWidth : convertToMeters(pondWidth, pondWidthUnit);
    let lengthInMeters = pondLengthUnit === 'meters' ? pondLength : convertToMeters(pondLength, pondLengthUnit);

    const linerSizeInSquareMeters = widthInMeters * lengthInMeters;
    const linerSizeInSquareFeet = linerSizeInSquareMeters * 10.7639; // 1 square meter = 10.7639 square feet

    const resultText = `You will need approximately ${linerSizeInSquareMeters.toFixed(2)} square meters or ${linerSizeInSquareFeet.toFixed(2)} square feet of pond liner.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateRugSize() {
    const roomWidth = parseFloat(document.getElementById('roomWidth').value);
    const roomLength = parseFloat(document.getElementById('roomLength').value);

    const roomWidthUnit = document.getElementById('roomWidthUnit').value;
    const roomLengthUnit = document.getElementById('roomLengthUnit').value;

    if (isNaN(roomWidth) || isNaN(roomLength)) {
        alert('Please enter valid numbers for room width and length.');
        return;
    }

    let area = roomWidth * roomLength;

    if (roomWidthUnit === 'feet' && roomLengthUnit === 'meters') {
        area *= 10.7639; // Convert square feet to square meters
    } else if (roomWidthUnit === 'meters' && roomLengthUnit === 'feet') {
        area /= 10.7639; // Convert square meters to square feet
    }

    const resultText = `You will need a rug of approximately ${area.toFixed(2)} square ${roomWidthUnit === 'feet' ? 'feet' : 'meters'}.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}
function calculatePoolGallons() {
    const poolLength = parseFloat(document.getElementById('poolLength').value);
    const poolWidth = parseFloat(document.getElementById('poolWidth').value);
    const poolDepth = parseFloat(document.getElementById('poolDepth').value);

    const poolLengthUnit = document.getElementById('poolLengthUnit').value;
    const poolWidthUnit = document.getElementById('poolWidthUnit').value;
    const poolDepthUnit = document.getElementById('poolDepthUnit').value;

    if (isNaN(poolLength) || isNaN(poolWidth) || isNaN(poolDepth)) {
        alert('Please enter valid numbers for pool dimensions.');
        return;
    }

    let volume = poolLength * poolWidth * poolDepth;

    if (poolLengthUnit === 'feet' && poolWidthUnit === 'feet' && poolDepthUnit === 'feet') {
        volume *= 7.48052; // Convert cubic feet to gallons
    } else if (poolLengthUnit === 'meters' && poolWidthUnit === 'meters' && poolDepthUnit === 'meters') {
        volume *= 264.172; // Convert cubic meters to gallons
    } else {
        alert('Please ensure all dimensions are in the same unit (feet or meters).');
        return;
    }

    const resultText = `Your pool contains approximately ${volume.toFixed(2)} gallons of water.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateAsphalt() {
    const areaLength = parseFloat(document.getElementById('areaLength').value);
    const areaWidth = parseFloat(document.getElementById('areaWidth').value);
    const thickness = parseFloat(document.getElementById('thickness').value);

    const areaLengthUnit = document.getElementById('areaLengthUnit').value;
    const areaWidthUnit = document.getElementById('areaWidthUnit').value;
    const thicknessUnit = document.getElementById('thicknessUnit').value;
    const resultUnit = document.getElementById('resultUnit').value;

    if (isNaN(areaLength) || isNaN(areaWidth) || isNaN(thickness)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const lengthInInches = convertToInches(areaLength, areaLengthUnit);
    const widthInInches = convertToInches(areaWidth, areaWidthUnit);
    const thicknessInInches = thicknessUnit === 'inches' ? thickness : thickness / 2.54; // Convert centimeters to inches

    // Calculate the volume of asphalt
    let volume = lengthInInches * widthInInches * thicknessInInches;

    // Convert the volume to result unit
    if (resultUnit === 'cubicMeters') {
        volume *= 0.0000163871; // Convert cubic inches to cubic meters
    } else {
        volume *= 0.0000214335; // Convert cubic inches to cubic yards
    }

    const resultText = `You will need approximately ${volume.toFixed(2)} ${resultUnit}.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateStoneDust() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const depth = parseFloat(document.getElementById('depth').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;
    const resultFormat = document.getElementById('resultFormat').value;

    if (isNaN(length) || isNaN(width) || isNaN(depth)) {
        alert('Please enter valid numbers for dimensions.');
        return;
    }

    let volume;

    if (lengthUnit === 'feet' && widthUnit === 'feet' && depthUnit === 'feet') {
        volume = length * width * depth; // Cubic feet
    } else if (lengthUnit === 'inches' && widthUnit === 'inches' && depthUnit === 'inches') {
        volume = length * width * depth / 1728; // Convert cubic inches to cubic feet
    } else {
        // Convert dimensions to feet
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const depthInFeet = convertToFeet(depth, depthUnit);

        volume = lengthInFeet * widthInFeet * depthInFeet; // Cubic feet
    }

    let resultText;

    switch (resultFormat) {
        case 'yards':
            resultText = `You will need approximately ${volume / 27} cubic yards of stone dust.`;
            break;
        case 'meters':
            resultText = `You will need approximately ${volume * 0.0283168} cubic meters of stone dust.`;
            break;
        case 'feet':
            resultText = `You will need approximately ${volume} cubic feet of stone dust.`;
            break;
        case 'inches':
            resultText = `You will need approximately ${volume * 1728} cubic inches of stone dust.`;
            break;
    }

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateFencePostDepth() {
    const fenceHeight = parseFloat(document.getElementById('fenceHeight').value);
    const postSpacing = parseFloat(document.getElementById('postSpacing').value);
    const fenceHeightUnit = document.getElementById('fenceHeightUnit').value;
    const postSpacingUnit = document.getElementById('postSpacingUnit').value;

    if (isNaN(fenceHeight) || isNaN(postSpacing)) {
        alert('Please enter valid numbers for fence height and post spacing.');
        return;
    }

    let depth = fenceHeight; // Default depth in feet
    if (fenceHeightUnit === 'inches') {
        depth /= 12; // Convert inches to feet
    }

    let spacing = postSpacing; // Default spacing in feet
    if (postSpacingUnit === 'inches') {
        spacing /= 12; // Convert inches to feet
    }

    // Calculate depth based on standard rules (1/3 of the post height)
    depth = Math.ceil(depth / 3);

    // Adjust depth based on post spacing
    depth += Math.ceil(spacing / 2);

    const resultText = `For a fence with a height of ${fenceHeight} ${fenceHeightUnit} and post spacing of ${postSpacing} ${postSpacingUnit}, the recommended post depth is approximately ${depth} feet.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}
function calculateKFactor() {
    const flowRate = parseFloat(document.getElementById('flowRate').value);
    const pressureDrop = parseFloat(document.getElementById('pressureDrop').value);
    const flowRateUnit = document.getElementById('flowRateUnit').value;
    const pressureDropUnit = document.getElementById('pressureDropUnit').value;

    if (isNaN(flowRate) || isNaN(pressureDrop)) {
        alert('Please enter valid numbers for flow rate and pressure drop.');
        return;
    }

    let kFactor;

    if (flowRateUnit === 'gpm' && pressureDropUnit === 'psi') {
        kFactor = flowRate / Math.sqrt(pressureDrop); // Calculate K Factor
    } else if (flowRateUnit === 'lpm' && pressureDropUnit === 'bar') {
        kFactor = flowRate / Math.sqrt(pressureDrop * 14.5038); // Convert bar to psi and calculate K Factor
    } else {
        alert('Please select compatible units for flow rate and pressure drop (GPM and PSI or LPM and Bar).');
        return;
    }

    const resultText = `The K Factor is approximately ${kFactor.toFixed(2)}.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateGambrelRoof() {
    const roofWidth = parseFloat(document.getElementById('roofWidth').value);
    const roofHeight = parseFloat(document.getElementById('roofHeight').value);
    const roofWidthUnit = document.getElementById('roofWidthUnit').value;
    const roofHeightUnit = document.getElementById('roofHeightUnit').value;

    if (isNaN(roofWidth) || isNaN(roofHeight)) {
        alert('Please enter valid numbers');
        return;
    }

    let roofWidthFeet = roofWidth;
    let roofHeightFeet = roofHeight;

    if (roofWidthUnit === 'meters') {
        roofWidthFeet = roofWidth * 3.28084; // Convert meters to feet
    }
    if (roofHeightUnit === 'meters') {
        roofHeightFeet = roofHeight * 3.28084; // Convert meters to feet
    }

    const halfSpan = roofWidthFeet / 2;
    const pitchAngleRad = Math.atan(roofHeightFeet / halfSpan);
    const pitchAngleDeg = (pitchAngleRad * 180) / Math.PI;

    const trussHeight = roofHeightFeet / 2;

    const resultText = `To build a gambrel roof with a roof width of ${roofWidth} ${roofWidthUnit} and a roof height of ${roofHeight} ${roofHeightUnit}, each half of the roof should have a height of ${trussHeight.toFixed(2)} feet, and the pitch angle is approximately ${pitchAngleDeg.toFixed(2)} degrees.`;

    const resultElement = document.getElementById('result');
    resultElement.innerHTML = `<div>${resultText}</div>`;
    resultElement.style.display = 'block'; // Show the result box
}
function calculateRoadbase() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const depth = parseFloat(document.getElementById('depth').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;
    const resultFormat = document.getElementById('resultFormat').value;

    if (isNaN(length) || isNaN(width) || isNaN(depth)) {
        alert('Please enter valid numbers for dimensions.');
        return;
    }

    let volume;

    if (lengthUnit === 'feet' && widthUnit === 'feet' && depthUnit === 'feet') {
        volume = length * width * depth; // Cubic feet
    } else if (lengthUnit === 'meters' && widthUnit === 'meters' && depthUnit === 'meters') {
        volume = length * width * depth * 35.3147; // Convert cubic meters to cubic feet
    } else {
        // Convert dimensions to feet
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const depthInFeet = convertToFeet(depth, depthUnit);

        volume = lengthInFeet * widthInFeet * depthInFeet; // Cubic feet
    }

    const resultText = `You will need approximately ${volume.toFixed(2)} ${resultFormat} of roadbase.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}



function calculateGlassWeight() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const thickness = parseFloat(document.getElementById('thickness').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const thicknessUnit = document.getElementById('thicknessUnit').value;

    if (isNaN(length) || isNaN(width) || isNaN(thickness)) {
        alert('Please enter valid numbers for dimensions.');
        return;
    }

    // Convert all dimensions to meters
    const lengthInMeters = convertToMetersGlass(length, lengthUnit);
    const widthInMeters = convertToMetersGlass(width, widthUnit);
    const thicknessInMeters = convertToMetersGlass(thickness, thicknessUnit, true);

    // Calculate volume in cubic meters
    const volume = lengthInMeters * widthInMeters * thicknessInMeters; // cubic meters

    // Density of glass is approximately 2500 kg/m^3
    const glassDensity = 2500;

    // Calculate weight in kilograms
    const weight = volume * glassDensity; // weight in kilograms

    const resultText = `The weight of the glass is approximately ${weight.toFixed(2)} kilograms.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function convertToMetersGlass(value, unit, isThickness = false) {
    switch (unit) {
        case 'feet':
            return value * 0.3048; // Convert feet to meters
        case 'inches':
            return value * 0.0254; // Convert inches to meters (for thickness)
        case 'millimeters':
            return value / 1000; // Convert millimeters to meters (for thickness)
        default:
            return value; // Assume same unit as meters
    }
}


function calculateSegmentedBowl() {
    const diameter = parseFloat(document.getElementById('diameter').value);
    const height = parseFloat(document.getElementById('height').value);
    const segments = parseInt(document.getElementById('segments').value);
    const diameterUnit = document.getElementById('diameterUnit').value;
    const heightUnit = document.getElementById('heightUnit').value;

    if (isNaN(diameter) || isNaN(height) || isNaN(segments) || segments <= 0) {
        alert('Please enter valid numbers for dimensions and segments.');
        return;
    }

    // Convert dimensions to inches if necessary
    const diameterInInches = convertToInches(diameter, diameterUnit);
    const heightInInches = convertToInches(height, heightUnit);

    // Calculate the circumference of the bowl at its widest point
    const circumference = Math.PI * diameterInInches;

    // Calculate the width of each segment
    const segmentWidth = circumference / segments;

    // Calculate the angle of each segment
    const segmentAngle = 360 / segments;

    const resultText = `Each segment should be cut to a width of approximately ${segmentWidth.toFixed(2)} inches and an angle of ${segmentAngle.toFixed(2)} degrees.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateLimestone() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const depth = parseFloat(document.getElementById('depth').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;
    const resultFormat = document.getElementById('resultFormat').value;

    if (isNaN(length) || isNaN(width) || isNaN(depth)) {
        alert('Please enter valid numbers for dimensions.');
        return;
    }

    let volume;

    if (lengthUnit === 'feet' && widthUnit === 'feet' && depthUnit === 'feet') {
        volume = length * width * depth; // Cubic feet
    } else if (lengthUnit === 'meters' && widthUnit === 'meters' && depthUnit === 'meters') {
        volume = length * width * depth; // Cubic meters
    } else {
        // Convert dimensions to feet
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const depthInFeet = convertToFeet(depth, depthUnit);

        volume = lengthInFeet * widthInFeet * depthInFeet; // Cubic feet
    }

    let resultText;

    switch (resultFormat) {
        case 'cubic meters':
            const volumeInCubicMeters = lengthUnit === 'meters' ? volume : volume * 0.0283168;
            resultText = `You will need approximately ${volumeInCubicMeters.toFixed(2)} cubic meters of limestone.`;
            break;
        case 'tons':
            // Assuming limestone density of 2.5 tons per cubic meter
            const volumeInCubicMetersForTons = lengthUnit === 'meters' ? volume : volume * 0.0283168;
            const weightInTons = volumeInCubicMetersForTons * 2.5;
            resultText = `You will need approximately ${weightInTons.toFixed(2)} tons of limestone.`;
            break;
        default:
            resultText = `You will need approximately ${volume.toFixed(2)} cubic feet of limestone.`;
            break;
    }

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateBoardAndBatten() {
    const wallHeight = parseFloat(document.getElementById('wallHeight').value);
    const wallWidth = parseFloat(document.getElementById('wallWidth').value);
    const boardWidth = parseFloat(document.getElementById('boardWidth').value);
    const battenWidth = parseFloat(document.getElementById('battenWidth').value);
    const spacing = parseFloat(document.getElementById('spacing').value);

    const wallHeightUnit = document.getElementById('wallHeightUnit').value;
    const wallWidthUnit = document.getElementById('wallWidthUnit').value;
    const boardWidthUnit = document.getElementById('boardWidthUnit').value;
    const battenWidthUnit = document.getElementById('battenWidthUnit').value;
    const spacingUnit = document.getElementById('spacingUnit').value;

    if (isNaN(wallHeight) || isNaN(wallWidth) || isNaN(boardWidth) || isNaN(battenWidth) || isNaN(spacing)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const wallHeightInInches = convertToInches(wallHeight, wallHeightUnit);
    const wallWidthInInches = convertToInches(wallWidth, wallWidthUnit);
    const boardWidthInInches = convertToInches(boardWidth, boardWidthUnit);
    const battenWidthInInches = convertToInches(battenWidth, battenWidthUnit);
    const spacingInInches = convertToInches(spacing, spacingUnit);

    // Calculate the number of boards and battens needed
    const numberOfBoards = Math.ceil(wallWidthInInches / (boardWidthInInches + spacingInInches));
    const totalBoardWidth = numberOfBoards * boardWidthInInches;
    const remainingWidth = wallWidthInInches - totalBoardWidth;
    const numberOfBattens = Math.ceil(remainingWidth / battenWidthInInches);

    const resultText = `You will need approximately ${numberOfBoards} boards and ${numberOfBattens} battens.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateRipRap() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const depth = parseFloat(document.getElementById('depth').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;
    const resultFormat = document.getElementById('resultFormat').value;

    if (isNaN(length) || isNaN(width) || isNaN(depth)) {
        alert('Please enter valid numbers for dimensions.');
        return;
    }

    // Convert dimensions to feet if necessary
    const lengthInFeet = convertToFeet(length, lengthUnit);
    const widthInFeet = convertToFeet(width, widthUnit);
    const depthInFeet = convertToFeet(depth, depthUnit);

    // Calculate volume in cubic feet
    const volume = lengthInFeet * widthInFeet * depthInFeet; // Cubic feet

    let resultText;

    switch (resultFormat) {
        case 'cubic meters':
            const volumeInCubicMeters = volume * 0.0283168;
            resultText = `You will need approximately ${volumeInCubicMeters.toFixed(2)} cubic meters of rip rap.`;
            break;
        case 'tons':
            // Assuming rip rap density of 1.4 tons per cubic yard (approx. 1.85 tons per cubic meter)
            const volumeInCubicYards = volume / 27; // Convert cubic feet to cubic yards
            const weightInTons = volumeInCubicYards * 1.4;
            resultText = `You will need approximately ${weightInTons.toFixed(2)} tons of rip rap.`;
            break;
        default:
            resultText = `You will need approximately ${volume.toFixed(2)} cubic feet of rip rap.`;
            break;
    }

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateBoxFill() {
    const boxVolume = parseFloat(document.getElementById('boxVolume').value);
    const numberOfConductors = parseInt(document.getElementById('numberOfConductors').value);
    const numberOfDevices = parseInt(document.getElementById('numberOfDevices').value);
    const groundWire = document.getElementById('groundWire').value;
    const boxVolumeUnit = document.getElementById('boxVolumeUnit').value;

    if (isNaN(boxVolume) || isNaN(numberOfConductors) || isNaN(numberOfDevices)) {
        alert('Please enter valid numbers for box volume, conductors, and devices.');
        return;
    }

    // Convert box volume to cubic inches if necessary
    const boxVolumeInCubicInches = boxVolumeUnit === 'cubic centimeters' ? boxVolume * 0.0610237 : boxVolume;

    // Calculate box fill capacity
    const conductorVolume = numberOfConductors * 2;
    const deviceVolume = numberOfDevices * 2;
    const groundWireVolume = groundWire === 'yes' ? 1 : 0;
    const totalVolume = conductorVolume + deviceVolume + groundWireVolume;

    let resultText;

    if (totalVolume <= boxVolumeInCubicInches) {
        resultText = `The box fill is within the allowable capacity. Total volume used: ${totalVolume.toFixed(2)} cubic inches. Box volume: ${boxVolumeInCubicInches.toFixed(2)} cubic inches.`;
    } else {
        resultText = `The box fill exceeds the allowable capacity. Total volume used: ${totalVolume.toFixed(2)} cubic inches. Box volume: ${boxVolumeInCubicInches.toFixed(2)} cubic inches.`;
    }

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateSonotubeConcrete() {
    const diameter = parseFloat(document.getElementById('diameter').value);
    const height = parseFloat(document.getElementById('height').value);
    const diameterUnit = document.getElementById('diameterUnit').value;
    const heightUnit = document.getElementById('heightUnit').value;

    if (isNaN(diameter) || isNaN(height)) {
        alert('Please enter valid numbers for diameter and height.');
        return;
    }

    // Convert dimensions to feet if necessary
    const diameterInInches = convertToInches(diameter, diameterUnit);
    const heightInFeet = convertToFeet(height, heightUnit);

    // Calculate the volume of the sonotube in cubic feet
    const radiusInFeet = diameterInInches / 24; // Convert diameter in inches to radius in feet
    const volumeInCubicFeet = Math.PI * Math.pow(radiusInFeet, 2) * heightInFeet;

    // Display the result
    const resultText = `You will need approximately ${volumeInCubicFeet.toFixed(2)} cubic feet of concrete.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateRiverRock() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const depth = parseFloat(document.getElementById('depth').value);
    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const depthUnit = document.getElementById('depthUnit').value;

    if (isNaN(length) || isNaN(width) || isNaN(depth)) {
        alert('Please enter valid numbers for length, width, and depth.');
        return;
    }

    // Convert dimensions to feet if necessary
    const lengthInFeet = convertToFeet1(length, lengthUnit);
    const widthInFeet = convertToFeet1(width, widthUnit);
    const depthInFeet = convertToFeet1(depth, depthUnit, true); // depth is given in inches or centimeters

    // Calculate the volume in cubic feet
    const volumeInCubicFeet = lengthInFeet * widthInFeet * depthInFeet;

    // Assuming river rock has an average weight of 100 lbs per cubic foot
    const weightInPounds = volumeInCubicFeet * 100;
    const weightInTons = weightInPounds / 2000;

    // Display the result
    const resultText = `You will need approximately ${volumeInCubicFeet.toFixed(2)} cubic feet of river rock, which is approximately ${weightInPounds.toFixed(2)} pounds or ${weightInTons.toFixed(2)} tons.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function convertToFeet1(value, unit, isDepth = false) {
    switch (unit) {
        case 'meters':
            return value * 3.28084; // Convert meters to feet
        case 'centimeters':
            return value * 0.0328084; // Convert centimeters to feet
        case 'inches':
            return isDepth ? value / 12 : value * 0.0833333; // Convert inches to feet
        default:
            return value; // Assume same unit as feet
    }
}

function calculateSand() {
    const areaLength = parseFloat(document.getElementById('areaLength').value);
    const areaWidth = parseFloat(document.getElementById('areaWidth').value);
    const sandDepth = parseFloat(document.getElementById('sandDepth').value);

    const areaLengthUnit = document.getElementById('areaLengthUnit').value;
    const areaWidthUnit = document.getElementById('areaWidthUnit').value;
    const sandDepthUnit = document.getElementById('sandDepthUnit').value;

    if (isNaN(areaLength) || isNaN(areaWidth) || isNaN(sandDepth)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const areaLengthInInches = convertToInches(areaLength, areaLengthUnit);
    const areaWidthInInches = convertToInches(areaWidth, areaWidthUnit);
    const sandDepthInInches = convertToInches(sandDepth, sandDepthUnit);

    // Calculate the volume of sand
    const volume = areaLengthInInches * areaWidthInInches * sandDepthInInches;

    const resultText = `You will need approximately ${volume.toFixed(2)} cubic inches of sand.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateStuds() {
    const wallLength = parseFloat(document.getElementById('wallLength').value);
    const spacing = parseFloat(document.getElementById('spacing').value);

    const wallLengthUnit = document.getElementById('wallLengthUnit').value;
    const spacingUnit = document.getElementById('spacingUnit').value;

    if (isNaN(wallLength) || isNaN(spacing)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const wallLengthInInches = convertToInches(wallLength, wallLengthUnit);
    const spacingInInches = convertToInches(spacing, spacingUnit);

    // Calculate the number of studs needed
    const numberOfStuds = Math.ceil(wallLengthInInches / spacingInInches);

    const resultText = `You will need approximately ${numberOfStuds} studs. Please consider additional studs for spacing and wastage.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}

function calculateRebars() {
    const slabLength = parseFloat(document.getElementById('slabLength').value);
    const slabWidth = parseFloat(document.getElementById('slabWidth').value);
    const rebarDiameter = parseFloat(document.getElementById('rebarDiameter').value);
    const spacing = parseFloat(document.getElementById('spacing').value);

    const slabLengthUnit = document.getElementById('slabLengthUnit').value;
    const slabWidthUnit = document.getElementById('slabWidthUnit').value;
    const rebarDiameterUnit = document.getElementById('rebarDiameterUnit').value;
    const spacingUnit = document.getElementById('spacingUnit').value;

    if (isNaN(slabLength) || isNaN(slabWidth) || isNaN(rebarDiameter) || isNaN(spacing)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const slabLengthInInches = convertToInches(slabLength, slabLengthUnit);
    const slabWidthInInches = convertToInches(slabWidth, slabWidthUnit);
    const rebarDiameterInInches = convertToInches(rebarDiameter, rebarDiameterUnit);
    const spacingInInches = convertToInches(spacing, spacingUnit);

    // Calculate the number of rebars needed
    const totalSlabArea = slabLengthInInches * slabWidthInInches;
    const rebarArea = Math.PI * Math.pow(rebarDiameterInInches / 2, 2);
    const numberOfRebars = Math.ceil(totalSlabArea / (rebarArea + spacingInInches));

    const resultText = `You will need approximately ${numberOfRebars} rebars. Please consider additional rebars for spacing and wastage.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateBoardFoot() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const thickness = parseFloat(document.getElementById('thickness').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const thicknessUnit = document.getElementById('thicknessUnit').value;

    if (isNaN(length) || isNaN(width) || isNaN(thickness)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const lengthInInches = convertToInches(length, lengthUnit);
    const widthInInches = convertToInches(width, widthUnit);
    const thicknessInInches = convertToInches(thickness, thicknessUnit);

    // Calculate board feet
    const volume = (lengthInInches * widthInInches * thicknessInInches) / 144; // 144 cubic inches in a board foot

    const resultText = `The volume is approximately ${volume.toFixed(2)} board feet.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateBricks() {
    const wallLength = parseFloat(document.getElementById('wallLength').value);
    const wallHeight = parseFloat(document.getElementById('wallHeight').value);
    const brickLength = parseFloat(document.getElementById('brickLength').value);
    const brickWidth = parseFloat(document.getElementById('brickWidth').value);
    const spacing = parseFloat(document.getElementById('spacing').value);

    const wallLengthUnit = document.getElementById('wallLengthUnit').value;
    const wallHeightUnit = document.getElementById('wallHeightUnit').value;
    const brickLengthUnit = document.getElementById('brickLengthUnit').value;
    const brickWidthUnit = document.getElementById('brickWidthUnit').value;
    const spacingUnit = document.getElementById('spacingUnit').value;

    if (isNaN(wallLength) || isNaN(wallHeight) || isNaN(brickLength) || isNaN(brickWidth) || isNaN(spacing)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const wallLengthInInches = convertToInches(wallLength, wallLengthUnit);
    const wallHeightInInches = convertToInches(wallHeight, wallHeightUnit);
    const brickLengthInInches = convertToInches(brickLength, brickLengthUnit);
    const brickWidthInInches = convertToInches(brickWidth, brickWidthUnit);
    const spacingInInches = convertToInches(spacing, spacingUnit);

    // Calculate the number of bricks needed
    const totalBrickArea = (brickLengthInInches + spacingInInches) * (brickWidthInInches + spacingInInches);
    const totalWallArea = wallLengthInInches * wallHeightInInches;
    const numberOfBricks = Math.ceil(totalWallArea / totalBrickArea);

    const resultText = `You will need approximately ${numberOfBricks} bricks. Please consider additional bricks for spacing and wastage.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}


function calculateFloorTiles() {
    const floorLength = parseFloat(document.getElementById('floorLength').value);
    const floorWidth = parseFloat(document.getElementById('floorWidth').value);
    const tileLength = parseFloat(document.getElementById('tileLength').value);
    const tileWidth = parseFloat(document.getElementById('tileWidth').value);
    const spacing = parseFloat(document.getElementById('spacing').value);

    const floorLengthUnit = document.getElementById('floorLengthUnit').value;
    const floorWidthUnit = document.getElementById('floorWidthUnit').value;
    const tileLengthUnit = document.getElementById('tileLengthUnit').value;
    const tileWidthUnit = document.getElementById('tileWidthUnit').value;
    const spacingUnit = document.getElementById('spacingUnit').value;

    if (isNaN(floorLength) || isNaN(floorWidth) || isNaN(tileLength) || isNaN(tileWidth) || isNaN(spacing)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to inches
    const floorLengthInInches = convertToInches(floorLength, floorLengthUnit);
    const floorWidthInInches = convertToInches(floorWidth, floorWidthUnit);
    const tileLengthInInches = convertToInches(tileLength, tileLengthUnit);
    const tileWidthInInches = convertToInches(tileWidth, tileWidthUnit);
    const spacingInInches = convertToInches(spacing, spacingUnit);

    // Calculate the number of tiles needed
    const totalTileArea = (tileLengthInInches + spacingInInches) * (tileWidthInInches + spacingInInches);
    const totalFloorArea = floorLengthInInches * floorWidthInInches;
    const numberOfTiles = Math.ceil(totalFloorArea / totalTileArea);

    const resultText = `You will need approximately ${numberOfTiles} tiles. Please consider additional tiles for wastage and cutting.`;

    document.getElementById('result').textContent = resultText;
    document.getElementById('result').style.display = 'block';
}






