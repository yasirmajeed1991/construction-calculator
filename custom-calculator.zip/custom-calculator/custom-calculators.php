<?php
/*
Plugin Name: Builder Calculators
Description: A plugin to display various calculators using shortcodes.
Version: 1.0
Author: Yasir Majeed (MSCS, LLM)
*/

// Enqueue Styles and Scripts
function cc_enqueue_styles_and_scripts() {
    wp_enqueue_style('cc-styles', plugin_dir_url(__FILE__) . 'css/styles.css');
    wp_enqueue_script('cc-scripts', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), null, true);
}

add_action('wp_enqueue_scripts', 'cc_enqueue_styles_and_scripts');


// Add a menu item to the WordPress admin dashboard
function add_shortcodes_menu() {
    add_menu_page(
        'Shortcodes List', // Page title
        'Builder Calculator Shortcodes', // Menu title
        'manage_options', // Capability
        'shortcodes-list', // Menu slug
        'display_shortcodes_list', // Callback function
        'dashicons-list-view', // Icon
        6 // Position
    );
}
add_action('admin_menu', 'add_shortcodes_menu');

// Function to display the shortcodes list with status
function display_shortcodes_list() {
    global $wpdb;
    ?>
    <div class="wrap">
        <h1>Available Shortcodes</h1>
        <style>
            .shortcodes-table {
                width: 100%;
                border-collapse: collapse;
                font-family: Arial, sans-serif;
                font-size: 18px;
            }
            .shortcodes-table th, .shortcodes-table td {
                border: 1px solid #ddd;
                padding: 12px;
                text-align: left;
            }
            .shortcodes-table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            .shortcodes-table tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            .shortcodes-table tr:hover {
                background-color: #f1f1f1;
            }
            .shortcodes-table th, {
                font-size: 18px;
                font-family: Arial, sans-serif;
            }
			.shortcodes-table td {
				font-size: 14px;
                font-family: Arial, sans-serif;
			}
        </style>
        <table class="shortcodes-table">
            <thead>
                <tr>
                    <th id="serial" class="manage-column column-serial" scope="col">#</th>
                    <th id="shortcode" class="manage-column column-shortcode" scope="col">Shortcode</th>
                    <th id="description" class="manage-column column-description" scope="col">Description</th>
                    <th id="status" class="manage-column column-status" scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
// Array of shortcodes and their descriptions
$shortcodes = array(
    '[roadbase_calculator]' => 'Roadbase Calculator',
    '[glass_weight_calculator]' => 'Glass Weight Calculator',
    '[segmented_bowl_calculator]' => 'Segmented Bowl Calculator',
    '[limestone_calculator]' => 'Limestone Calculator',
    '[board_and_batten_calculator]' => 'Board and Batten Calculator',
    '[rip_rap_calculator]' => 'Rip Rap Calculator',
    '[box_fill_calculator]' => 'Box Fill Calculator',
    '[sonutube_concrete_calculator]' => 'Sonutube Concrete Calculator',
    '[river_rock_calculator]' => 'River Rock Calculator',
    '[sand_calculator]' => 'Sand Calculator',
    '[stud_calculator]' => 'Stud Calculator',
    '[rebar_calculator]' => 'Rebar Calculator',
    '[board_foot_calculator]' => 'Board Foot Calculator',
    '[brick_calculator]' => 'Brick Calculator',
    '[floor_tile_calculator]' => 'Tile Calculator',
    '[paver_calculator]' => 'Paver Calculator',
    '[tile_layout_calculator]' => 'Tile Layout Calculator',
    '[gambrel_truss_calculator]' => 'Gambrel Truss Calculator',
    '[subway_tile_calculator]' => 'Subway Tile Calculator',
    '[plate_calculator]' => 'Plate Calculator',
    '[junction_box_calculator]' => 'Junction Box Calculator',
    '[transformer_calculator]' => 'Transformer Calculator',
    '[pond_liner_calculator]' => 'Pond Liner Calculator',
    '[rug_size_calculator]' => 'Rug Size Calculator',
    '[pool_gallons_calculator]' => 'Pool Gallons Calculator',
    '[asphalt_calculator]' => 'Asphalt Calculator',
    '[stone_dust_calculator]' => 'Stone Dust Calculator',
    '[fence_post_depth_calculator]' => 'Fence Post Depth Calculator',
    '[k_factor_calculator]' => 'K Factor Calculator',
    '[gambrel_roof_calculator]' => 'Gambrel Roof Calculator',
    '[cubic_yards_calculator]' => 'Cubic Yards Calculator',
    '[square_footage_calculator]' => 'Square Footage Calculator',
    '[square_yards_calculator]' => 'Square Yards Calculator',
    '[sealant_calculator]' => 'Sealant Calculator',
    '[pipe_weight_calculator]' => 'Pipe Weight Calculator',
    '[spiral_staircase_calculator]' => 'Spiral Staircase Calculator',
    '[wainscoting_calculator]' => 'Wainscoting Calculator',
    '[stair_carpet_calculator]' => 'Stair Carpet Calculator',
    '[plywood_calculator]' => 'Plywood Calculator',
    '[furnace_size_calculator]' => 'Furnace Size Calculator',
    '[siding_calculator]' => 'Siding Calculator',
    '[deck_stain_calculator]' => 'Deck Stain Calculator',
    '[heat_loss_calculator]' => 'Heat Loss Calculator',
    '[ladder_angle_calculator]' => 'Ladder Angle Calculator',
    '[epoxy_calculator]' => 'Epoxy Calculator',
    '[hoop_house_calculator]' => 'Hoop House Calculator',
    '[clearance_hole_calculator]' => 'Clearance Hole Calculator',
    '[ramp_calculator]' => 'Ramp Calculator',
    '[chicken_coop_calculator]' => 'Chicken Coop Calculator',
    '[ach_calculator]' => 'ACH Calculator',
    '[shiplap_calculator]' => 'Shiplap Calculator',
    '[grout_calculator]' => 'Grout Calculator',
    '[hole_volume_calculator]' => 'Hole Volume Calculator',
    '[concrete_stairs_calculator]' => 'Concrete Stairs Calculator',
    '[diy_shed_cost_calculator]' => 'DIY Shed Calculator',
    '[spindle_spacing_calculator]' => 'Spindle Spacing Calculator',
    '[aluminum_weight_calculator]' => 'Aluminum Weight Calculator',
    '[vinyl_fence_calculator]' => 'Vinyl Fence Calculator',
    '[lumber_calculator]' => 'Lumber Calculator',
    '[tonnage_calculator]' => 'Tonnage Calculator',
    '[french_drain_calculator]' => 'French Drain Calculator',
    '[fire_glass_calculator]' => 'Fire Glass Calculator',
);

// Sort the shortcodes array by keys (shortcode) in ascending order
ksort($shortcodes);

// Loop through the shortcodes array and display each shortcode, its description, and its status
$serial_number = 1;
foreach ($shortcodes as $shortcode => $description) {
    // Query the database to check if the shortcode is used on any page
    $shortcode_used = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_type = 'page' AND post_status = 'publish'",
            '%' . $wpdb->esc_like($shortcode) . '%'
        )
    );

    $status = $shortcode_used > 0 ? 'Used' : 'Not Used';

    echo '<tr>';
    echo '<td>' . esc_html($serial_number) . '</td>';
    echo '<td>' . esc_html($shortcode) . '</td>';
    echo '<td>' . esc_html($description) . '</td>';
    echo '<td>' . esc_html($status) . '</td>';
    echo '</tr>';
    $serial_number++;
}
?>
            </tbody>
        </table>
    </div>
    <?php
}

// Shortcode for Paver Calculator   1. paver_calculator
function paver_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Paver Calculator</h1>
            <form id="paverForm">
                <div class="form-group">
                    <label for="areaWidth" class="form-label">Area Width:</label>
                    <input type="number" id="areaWidth" class="form-input" required>
                    <select id="areaWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="areaLength" class="form-label">Area Length:</label>
                    <input type="number" id="areaLength" class="form-input" required>
                    <select id="areaLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="paverWidth" class="form-label">Paver Width:</label>
                    <input type="number" id="paverWidth" class="form-input" required>
                    <select id="paverWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="paverLength" class="form-label">Paver Length:</label>
                    <input type="number" id="paverLength" class="form-input" required>
                    <select id="paverLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePavers()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('paver_calculator', 'paver_calculator_shortcode');

// Shortcode for Tile Calculator 2. tile_layout_calculator
function tile_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Tile Layout Calculator</h1>
            <form id="tileForm">
                <div class="form-group">
                    <label for="roomWidth" class="form-label">Room Width:</label>
                    <input type="number" id="roomWidth" class="form-input" required>
                    <select id="roomWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roomLength" class="form-label">Room Length:</label>
                    <input type="number" id="roomLength" class="form-input" required>
                    <select id="roomLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileWidth" class="form-label">Tile Width:</label>
                    <input type="number" id="tileWidth" class="form-input" required>
                    <select id="tileWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileLength" class="form-label">Tile Length:</label>
                    <input type="number" id="tileLength" class="form-input" required>
                    <select id="tileLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateTiles()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('tile_layout_calculator', 'tile_calculator_shortcode');

// Shortcode 3.gambrel_truss_calculator
function gambrel_truss_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gambrel Truss Calculator</h1>
            <form id="trussForm">
                <div class="form-group">
                    <label for="roofWidth" class="form-label">Roof Width:</label>
                    <input type="number" id="roofWidth" class="form-input" required>
                    <select id="roofWidthUnit" class="form-select">
                    <option value="meters">Meters</option> <!-- Added meters option -->
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofHeight" class="form-label">Roof Height:</label>
                    <input type="number" id="roofHeight" class="form-input" required>
                    <select id="roofHeightUnit" class="form-select">
                    <option value="meters">Meters</option> <!-- Added meters option -->
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                       
                    </select>
                </div>
                <button type="button" onclick="calculateTruss()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('gambrel_truss_calculator', 'gambrel_truss_calculator_shortcode');

// Shortcode 4.subway_tile_calculator
function subway_tile_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Subway Tile Calculator</h1>
            <form id="tileForm">
                <div class="form-group">
                    <label for="wallWidth" class="form-label">Wall Width:</label>
                    <input type="number" id="wallWidth" class="form-input" required>
                    <select id="wallWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallHeight" class="form-label">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileWidth" class="form-label">Tile Width:</label>
                    <input type="number" id="tileWidth" class="form-input" required>
                    <select id="tileWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileHeight" class="form-label">Tile Height:</label>
                    <input type="number" id="tileHeight" class="form-input" required>
                    <select id="tileHeightUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSubwayTiles()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('subway_tile_calculator', 'subway_tile_calculator_shortcode');

// Shortcode for Plate Calculator 5.plate_calculator

function plate_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Plate Calculator</h1>
            <form id="plateForm">
                <div class="form-group">
                    <label for="plateLength" class="form-label">Plate Length:</label>
                    <input type="number" id="plateLength" class="form-input" required>
                    <select id="plateLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="plateWidth" class="form-label">Plate Width:</label>
                    <input type="number" id="plateWidth" class="form-input" required>
                    <select id="plateWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="plateThickness" class="form-label">Plate Thickness:</label>
                    <input type="number" id="plateThickness" class="form-input" required>
                    <select id="plateThicknessUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePlate()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('plate_calculator', 'plate_calculator_shortcode');

// Shortcode for Junction Box Calculator with Measuring Units 6.junction_box_calculator
function junction_box_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Junction Box Calculator</h1>
            <form id="junctionBoxForm">
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depth" class="form-label">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateJunctionBox()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('junction_box_calculator', 'junction_box_calculator_shortcode');

// Shortcode for Transformer Calculator with Measuring Units 7.transformer_calculator
function transformer_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Transformer Calculator</h1>
            <form id="transformerForm">
                <div class="form-group">
                    <label for="primaryVoltage" class="form-label">Primary Voltage:</label>
                    <input type="number" id="primaryVoltage" class="form-input" required>
                    <select id="primaryVoltageUnit" class="form-select">
                        <option value="kV">kV</option>
                        <option value="V">V</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="secondaryVoltage" class="form-label">Secondary Voltage:</label>
                    <input type="number" id="secondaryVoltage" class="form-input" required>
                    <select id="secondaryVoltageUnit" class="form-select">
                        <option value="kV">kV</option>
                        <option value="V">V</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="current" class="form-label">Current (Amps):</label>
                    <input type="number" id="current" class="form-input" required>
                </div>
                <button type="button" onclick="calculateTransformer()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('transformer_calculator', 'transformer_calculator_shortcode');

// Shortcode for Pond Liner Size Calculator 8.pond_liner_calculator
// Shortcode for Pond Liner Size Calculator
function pond_liner_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Pond Liner Size Calculator</h1>
            <form id="pondLinerForm">
                <div class="form-group">
                    <label for="pondWidth" class="form-label">Pond Width:</label>
                    <input type="number" id="pondWidth" class="form-input" required>
                    <select id="pondWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pondLength" class="form-label">Pond Length:</label>
                    <input type="number" id="pondLength" class="form-input" required>
                    <select id="pondLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePondLinerSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('pond_liner_calculator', 'pond_liner_calculator_shortcode');


// Shortcode for Rug Size Calculator 9.rug_size_calculator
function rug_size_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Rug Size Calculator</h1>
            <form id="rugSizeForm">
                <div class="form-group">
                    <label for="roomWidth" class="form-label">Room Width:</label>
                    <input type="number" id="roomWidth" class="form-input" required>
                    <select id="roomWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roomLength" class="form-label">Room Length:</label>
                    <input type="number" id="roomLength" class="form-input" required>
                    <select id="roomLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRugSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('rug_size_calculator', 'rug_size_calculator_shortcode');

// Shortcode for Pool Gallons Calculator 10.pool_gallons_calculator
function pool_gallons_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Pool Gallons Calculator</h1>
            <form id="poolGallonsForm">
                <div class="form-group">
                    <label for="poolLength" class="form-label">Pool Length:</label>
                    <input type="number" id="poolLength" class="form-input" required>
                    <select id="poolLengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="poolWidth" class="form-label">Pool Width:</label>
                    <input type="number" id="poolWidth" class="form-input" required>
                    <select id="poolWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="poolDepth" class="form-label">Pool Depth:</label>
                    <input type="number" id="poolDepth" class="form-input" required>
                    <select id="poolDepthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePoolGallons()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('pool_gallons_calculator', 'pool_gallons_calculator_shortcode');

// Shortcode for Asphalt Calculator 11.asphalt_calculator
// Shortcode for Asphalt Calculator
function asphalt_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Asphalt Calculator</h1>
            <form id="asphaltForm">
                <div class="form-group">
                    <label for="areaLength" class="form-label">Area Length:</label>
                    <input type="number" id="areaLength" class="form-input" required>
                    <select id="areaLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="areaWidth" class="form-label">Area Width:</label>
                    <input type="number" id="areaWidth" class="form-input" required>
                    <select id="areaWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Asphalt Thickness:</label>
                    <input type="number" id="thickness" class="form-input" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit" class="form-label">Result Unit:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="cubicYards">Cubic Yards</option>
                        <option value="cubicMeters">Cubic Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateAsphalt()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('asphalt_calculator', 'asphalt_calculator_shortcode');


// Shortcode for Stone Dust Calculator 12.stone_dust_calculator

// Shortcode for Stone Dust Calculator
function stone_dust_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Stone Dust Calculator</h1>
            <form id="stoneDustForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depth" class="form-label">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultFormat" class="form-label">Result Format:</label>
                    <select id="resultFormat" class="form-select">
                        <option value="yards">Cubic Yards</option>
                        <option value="meters">Cubic Meters</option>
                        <option value="feet">Cubic Feet</option>
                        <option value="inches">Cubic Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateStoneDust()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('stone_dust_calculator', 'stone_dust_calculator_shortcode');


// Shortcode for Fence Post Depth Calculator 13.fence_post_depth_calculator
function fence_post_depth_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Fence Post Depth Calculator</h1>
            <form id="fencePostDepthForm">
                <div class="form-group">
                    <label for="fenceHeight" class="form-label">Fence Height:</label>
                    <input type="number" id="fenceHeight" class="form-input" required>
                    <select id="fenceHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="postSpacing" class="form-label">Post Spacing:</label>
                    <input type="number" id="postSpacing" class="form-input" required>
                    <select id="postSpacingUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateFencePostDepth()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('fence_post_depth_calculator', 'fence_post_depth_calculator_shortcode');


// Shortcode for K Factor Calculator 14.k_factor_calculator
// Shortcode for K Factor Calculator
function k_factor_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>K Factor Calculator</h1>
            <form id="kFactorForm">
                <div class="form-group">
                    <label for="flowRate" class="form-label">Flow Rate:</label>
                    <input type="number" id="flowRate" class="form-input" step="0.01" required>
                    <select id="flowRateUnit" class="form-select">
                        <option value="gpm">GPM</option>
                        <option value="lpm">LPM</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pressureDrop" class="form-label">Pressure Drop:</label>
                    <input type="number" id="pressureDrop" class="form-input" step="0.01" required>
                    <select id="pressureDropUnit" class="form-select">
                        <option value="psi">PSI</option>
                        <option value="bar">Bar</option>
                    </select>
                </div>
                <button type="button" onclick="calculateKFactor()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('k_factor_calculator', 'k_factor_calculator_shortcode');


// Shortcode for Gambrel Roof Calculator 15.gambrel_roof_calculator
function gambrel_roof_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gambrel Roof Calculator</h1>
            <form id="roofForm">
                <div class="form-group">
                    <label for="roofWidth" class="form-label">Roof Width:</label>
                    <input type="number" id="roofWidth" class="form-input" required>
                    <select id="roofWidthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofHeight" class="form-label">Roof Height:</label>
                    <input type="number" id="roofHeight" class="form-input" required>
                    <select id="roofHeightUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGambrelRoof()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('gambrel_roof_calculator', 'gambrel_roof_calculator_shortcode');

// Shortcode for Roadbase Calculator 16.roadbase_calculator
function roadbase_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
    <div class="calculator">
        <h1>Roadbase Calculator</h1>
        <form id="roadbaseForm">
            <div class="form-group">
                <label for="length" class="form-label">Length:</label>
                <input type="number" id="length" class="form-input" required>
                <select id="lengthUnit" class="form-select">
                    <option value="meters">Meters</option>
                    <option value="feet">Feet</option>
                </select>
            </div>
            <div class="form-group">
                <label for="width" class="form-label">Width:</label>
                <input type="number" id="width" class="form-input" required>
                <select id="widthUnit" class="form-select">
                    <option value="meters">Meters</option>
                    <option value="feet">Feet</option>
                </select>
            </div>
            <div class="form-group">
                <label for="depth" class="form-label">Depth:</label>
                <input type="number" id="depth" class="form-input" required>
                <select id="depthUnit" class="form-select">
                    <option value="meters">Meters</option>
                    <option value="feet">Feet</option>
                </select>
            </div>
            <div class="form-group">
                <label for="resultFormat" class="form-label">Result Format:</label>
                <select id="resultFormat" class="form-select">
                    <option value="cubic feet">Cubic Feet</option>
                    <option value="cubic meters">Cubic Meters</option>
                </select>
            </div>
            <button type="button" onclick="calculateRoadbase()" class="form-button">Calculate</button>
        </form>
        <div id="result" class="result-text"></div>
    </div>
</div>

    <?php
    return ob_get_clean();
}

add_shortcode('roadbase_calculator', 'roadbase_calculator_shortcode');

// Shortcode for Glass Weight Calculator 17.glass_weight_calculator
function glass_weight_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Glass Weight Calculator</h1>
            <form id="glassWeightForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Thickness:</label>
                    <input type="number" id="thickness" class="form-input" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="millimeters">mm</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGlassWeight()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('glass_weight_calculator', 'glass_weight_calculator_shortcode');

// Shortcode for Segmented Bowl Calculator 18.segmented_bowl_calculator
function segmented_bowl_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Segmented Bowl Calculator</h1>
            <form id="segmentedBowlForm">
                <div class="form-group">
                    <label for="diameter" class="form-label">Diameter:</label>
                    <input type="number" id="diameter" class="form-input" required>
                    <select id="diameterUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="height" class="form-label">Height:</label>
                    <input type="number" id="height" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="segments" class="form-label">Number of Segments:</label>
                    <input type="number" id="segments" class="form-input" required>
                </div>
                <button type="button" onclick="calculateSegmentedBowl()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('segmented_bowl_calculator', 'segmented_bowl_calculator_shortcode');


// Shortcode for Limestone Calculator  19.limestone_calculator
function limestone_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Limestone Calculator</h1>
            <form id="limestoneForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depth" class="form-label">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultFormat" class="form-label">Result Format:</label>
                    <select id="resultFormat" class="form-select">
                        <option value="cubic feet">Cubic Feet</option>
                        <option value="cubic meters">Cubic Meters</option>
                        <option value="tons">Tons</option>
                    </select>
                </div>
                <button type="button" onclick="calculateLimestone()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('limestone_calculator', 'limestone_calculator_shortcode');

// Shortcode for Board and Batten Calculator
function board_and_batten_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Board and Batten Calculator</h1>
            <form id="boardAndBattenForm">
                <div class="form-group">
                    <label for="wallHeight" class="form-label">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallWidth" class="form-label">Wall Width:</label>
                    <input type="number" id="wallWidth" class="form-input" required>
                    <select id="wallWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="boardWidth" class="form-label">Board Width:</label>
                    <input type="number" id="boardWidth" class="form-input" required>
                    <select id="boardWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="battenWidth" class="form-label">Batten Width:</label>
                    <input type="number" id="battenWidth" class="form-input" required>
                    <select id="battenWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Boards:</label>
                    <input type="number" id="spacing" class="form-input" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateBoardAndBatten()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('board_and_batten_calculator', 'board_and_batten_calculator_shortcode');


// Shortcode for Rip Rap Calculator 21.rip_rap_calculator
function rip_rap_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Rip Rap Calculator</h1>
            <form id="ripRapForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depth" class="form-label">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultFormat" class="form-label">Result Format:</label>
                    <select id="resultFormat" class="form-select">
                        <option value="cubic feet">Cubic Feet</option>
                        <option value="cubic meters">Cubic Meters</option>
                        <option value="tons">Tons</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRipRap()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('rip_rap_calculator', 'rip_rap_calculator_shortcode');

// Shortcode for Box Fill Calculator 22.box_fill_calculator
function box_fill_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Box Fill Calculator</h1>
            <form id="boxFillForm">
                <div class="form-group">
                    <label for="boxVolume" class="form-label">Box Volume:</label>
                    <input type="number" id="boxVolume" class="form-input" required>
                    <select id="boxVolumeUnit" class="form-select">
                        <option value="cubic inches">Cubic In</option>
                        <option value="cubic centimeters">Cubic Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="numberOfConductors" class="form-label">Number of Conductors:</label>
                    <input type="number" id="numberOfConductors" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="numberOfDevices" class="form-label">Number of Devices:</label>
                    <input type="number" id="numberOfDevices" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="groundWire" class="form-label">Ground Wire:</label>
                    <select id="groundWire" class="form-select">
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                    </select>
                </div>
                <button type="button" onclick="calculateBoxFill()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('box_fill_calculator', 'box_fill_calculator_shortcode');

// Shortcode for Sonotube Concrete Calculator 23.sonotube_concrete_calculator
function sonotube_concrete_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Sonotube Concrete Calculator</h1>
            <form id="sonotubeForm">
                <div class="form-group">
                    <label for="diameter" class="form-label">Diameter:</label>
                    <input type="number" id="diameter" class="form-input" required>
                    <select id="diameterUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="height" class="form-label">Height:</label>
                    <input type="number" id="height" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSonotubeConcrete()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('sonotube_concrete_calculator', 'sonotube_concrete_calculator_shortcode');


// Shortcode for River Rock Calculator 24.river_rock_calculator
function river_rock_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>River Rock Calculator</h1>
            <form id="riverRockForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="depth" class="form-label">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">Cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRiverRock()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('river_rock_calculator', 'river_rock_calculator_shortcode');


// Shortcode for Sand Calculator 25.sand_calculator
// Shortcode for Sand Calculator
function sand_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Sand Calculator</h1>
            <form id="sandForm">
                <div class="form-group">
                    <label for="areaLength" class="form-label">Area Length:</label>
                    <input type="number" id="areaLength" class="form-input" required>
                    <select id="areaLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="areaWidth" class="form-label">Area Width:</label>
                    <input type="number" id="areaWidth" class="form-input" required>
                    <select id="areaWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="sandDepth" class="form-label">Sand Depth:</label>
                    <input type="number" id="sandDepth" class="form-input" required>
                    <select id="sandDepthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSand()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('sand_calculator', 'sand_calculator_shortcode');



// Shortcode for Stud Calculator 26.stud_calculator
// Shortcode for Stud Calculator
function stud_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Stud Calculator</h1>
            <form id="studForm">
                <div class="form-group">
                    <label for="wallLength" class="form-label">Wall Length:</label>
                    <input type="number" id="wallLength" class="form-input" required>
                    <select id="wallLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Studs:</label>
                    <input type="number" id="spacing" class="form-input" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateStuds()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('stud_calculator', 'stud_calculator_shortcode');


// Shortcode for Rebar Calculator 27.rebar_calculator
// Shortcode for Rebar Calculator
function rebar_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Rebar Calculator</h1>
            <form id="rebarForm">
                <div class="form-group">
                    <label for="slabLength" class="form-label">Slab Length:</label>
                    <input type="number" id="slabLength" class="form-input" required>
                    <select id="slabLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="slabWidth" class="form-label">Slab Width:</label>
                    <input type="number" id="slabWidth" class="form-input" required>
                    <select id="slabWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="rebarDiameter" class="form-label">Rebar Diameter:</label>
                    <input type="number" id="rebarDiameter" class="form-input" required>
                    <select id="rebarDiameterUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Rebars:</label>
                    <input type="number" id="spacing" class="form-input" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRebars()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('rebar_calculator', 'rebar_calculator_shortcode');


// Shortcode for Board Foot Calculator 28.board_foot_calculator
// Shortcode for Board Foot Calculator
function board_foot_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Board Foot Calculator</h1>
            <form id="boardFootForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Thickness:</label>
                    <input type="number" id="thickness" class="form-input" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="cm">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateBoardFoot()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('board_foot_calculator', 'board_foot_calculator_shortcode');


// Shortcode for Brick Calculator 29.brick_calculator

function brick_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Brick Calculator</h1>
            <form id="brickForm">
                <div class="form-group">
                    <label for="wallLength" class="form-label">Wall Length:</label>
                    <input type="number" id="wallLength" class="form-input" required>
                    <select id="wallLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallHeight" class="form-label">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="brickLength" class="form-label">Brick Length:</label>
                    <input type="number" id="brickLength" class="form-input" required>
                    <select id="brickLengthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="brickWidth" class="form-label">Brick Width:</label>
                    <input type="number" id="brickWidth" class="form-input" required>
                    <select id="brickWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Bricks:</label>
                    <input type="number" id="spacing" class="form-input" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateBricks()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('brick_calculator', 'brick_calculator_shortcode');


// Shortcode for Tile Calculator 30.tile_calculator
// Shortcode for Tile Calculator
function floor_tile_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Tile Calculator</h1>
            <form id="tileForm">
                <div class="form-group">
                    <label for="floorLength" class="form-label">Floor Length:</label>
                    <input type="number" id="floorLength" class="form-input" required>
                    <select id="floorLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="floorWidth" class="form-label">Floor Width:</label>
                    <input type="number" id="floorWidth" class="form-input" required>
                    <select id="floorWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileLength" class="form-label">Tile Length:</label>
                    <input type="number" id="tileLength" class="form-input" required>
                    <select id="tileLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileWidth" class="form-label">Tile Width:</label>
                    <input type="number" id="tileWidth" class="form-input" required>
                    <select id="tileWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Tiles:</label>
                    <input type="number" id="spacing" class="form-input" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateFloorTiles()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('floor_tile_calculator', 'floor_tile_calculator_shortcode');

//Cubic Yard Calculator
function cubic_yards_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Cubic Yards Calculator</h1>
            <form id="cubicYardsForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="height" class="form-label">Height:</label>
                    <input type="number" id="height" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateCubicYards()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
	function calculateCubicYards() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const height = parseFloat(document.getElementById('height').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const heightUnit = document.getElementById('heightUnit').value;

    if (isNaN(length) || isNaN(width) || isNaN(height)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to yards
    const lengthInYards = convertToYards(length, lengthUnit);
    const widthInYards = convertToYards(width, widthUnit);
    const heightInYards = convertToYards(height, heightUnit);

    // Calculate the volume in cubic yards
    const cubicYards = lengthInYards * widthInYards * heightInYards;

    const resultText = `
        To calculate the volume in cubic yards, we performed the following steps:
        <br><br>
        1. Converted the dimensions to yards:
        <ul>
            <li>Length: ${length} ${lengthUnit} = ${lengthInYards.toFixed(2)} yards</li>
            <li>Width: ${width} ${widthUnit} = ${widthInYards.toFixed(2)} yards</li>
            <li>Height: ${height} ${heightUnit} = ${heightInYards.toFixed(2)} yards</li>
        </ul>
        2. Multiplied the converted dimensions to find the volume:
        <br>
        Volume = ${lengthInYards.toFixed(2)} yards (length) × ${widthInYards.toFixed(2)} yards (width) × ${heightInYards.toFixed(2)} yards (height)
        <br><br>
        Therefore, the volume is approximately ${cubicYards.toFixed(2)} cubic yards.
    `;

    document.getElementById('result').innerHTML = resultText;
    document.getElementById('result').style.display = 'block';
}

function convertToYards(value, unit) {
    switch (unit) {
        case 'feet':
            return value / 3;
        case 'meters':
            return value * 1.09361;
        case 'inches':
            return value / 36;
        case 'centimeters':
            return value / 91.44;
        default:
            return value;
    }
}

</script>
    <?php
    return ob_get_clean();
}

add_shortcode('cubic_yards_calculator', 'cubic_yards_calculator_shortcode');

//Square Footage Calculator
function square_footage_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Square Footage Calculator</h1>
            <form id="squareFootageForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSquareFootage()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
	
function calculateSquareFootage() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;

    if (isNaN(length) || isNaN(width)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to feet
    const lengthInFeet = convertToFeet(length, lengthUnit);
    const widthInFeet = convertToFeet(width, widthUnit);

    // Calculate the area in square feet
    const squareFootage = lengthInFeet * widthInFeet;

    const resultText = `
        To calculate the square footage, we performed the following steps:
        <br><br>
        1. Converted the dimensions to feet:
        <ul>
            <li>Length: ${length} ${lengthUnit} = ${lengthInFeet.toFixed(2)} feet</li>
            <li>Width: ${width} ${widthUnit} = ${widthInFeet.toFixed(2)} feet</li>
        </ul>
        2. Multiplied the converted dimensions to find the area:
        <br>
        Area = ${lengthInFeet.toFixed(2)} feet (length) × ${widthInFeet.toFixed(2)} feet (width)
        <br><br>
        Therefore, the area is approximately ${squareFootage.toFixed(2)} square feet.
    `;

    document.getElementById('result').innerHTML = resultText;
    document.getElementById('result').style.display = 'block';
}

</script>
    <?php
    return ob_get_clean();
}

add_shortcode('square_footage_calculator', 'square_footage_calculator_shortcode');

//Square Yards Calculator
function square_yards_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Square Yards Calculator</h1>
            <form id="squareYardsForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="yards">Yards</option>
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="yards">Yards</option>
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSquareYards()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
function calculateSquareYards() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;

    if (isNaN(length) || isNaN(width)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to yards
    const lengthInYards = convertToYards(length, lengthUnit);
    const widthInYards = convertToYards(width, widthUnit);

    // Calculate the area in square yards
    const squareYardage = lengthInYards * widthInYards;

    const resultText = `
        To calculate the square yardage, we performed the following steps:
        <br><br>
        1. Converted the dimensions to yards:
        <ul>
            <li>Length: ${length} ${lengthUnit} = ${lengthInYards.toFixed(2)} yards</li>
            <li>Width: ${width} ${widthUnit} = ${widthInYards.toFixed(2)} yards</li>
        </ul>
        2. Multiplied the converted dimensions to find the area:
        <br>
        Area = ${lengthInYards.toFixed(2)} yards (length) × ${widthInYards.toFixed(2)} yards (width)
        <br><br>
        Therefore, the area is approximately ${squareYardage.toFixed(2)} square yards.
    `;

    document.getElementById('result').innerHTML = resultText;
    document.getElementById('result').style.display = 'block';
}

function convertToYards(value, unit) {
    switch (unit) {
        case 'feet':
            return value / 3;
        case 'meters':
            return value * 1.09361;
        case 'inches':
            return value / 36;
        case 'centimeters':
            return value / 91.44;
        case 'yards':
        default:
            return value;
    }
}

</script>	

    <?php
    return ob_get_clean();
}

add_shortcode('square_yards_calculator', 'square_yards_calculator_shortcode');

function sealant_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Sealant Calculator</h1>
            <form id="sealantForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length of the Area to be Sealed:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width of the Area to be Sealed:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="coverage" class="form-label">Coverage of Sealant per Unit:</label>
                    <input type="number" id="coverage" class="form-input" required>
                    <select id="coverageUnit" class="form-select">
                        <option value="square feet">Sq Foot</option>
                        <option value="square meters">Sq Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSealant()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
function calculateSealant() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const coverage = parseFloat(document.getElementById('coverage').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const widthUnit = document.getElementById('widthUnit').value;
    const coverageUnit = document.getElementById('coverageUnit').value;

    if (isNaN(length) || isNaN(width) || isNaN(coverage)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert length and width to feet
    const lengthInFeet = convertToFeet(length, lengthUnit);
    const widthInFeet = convertToFeet(width, widthUnit);

    // Calculate the area in square feet
    const areaInSquareFeet = lengthInFeet * widthInFeet;

    // Convert coverage to square feet if necessary
    let coverageInSquareFeet;
    if (coverageUnit === 'square meters') {
        coverageInSquareFeet = coverage * 10.7639;
    } else {
        coverageInSquareFeet = coverage;
    }

    // Calculate the amount of sealant needed
    const sealantNeeded = areaInSquareFeet / coverageInSquareFeet;

    const resultText = `
        To calculate the amount of sealant needed, we performed the following steps:
        <br><br>
        1. Converted the dimensions to feet:
        <ul>
            <li>Length: ${length} ${lengthUnit} = ${lengthInFeet.toFixed(2)} feet</li>
            <li>Width: ${width} ${widthUnit} = ${widthInFeet.toFixed(2)} feet</li>
        </ul>
        2. Calculated the area:
        <br>
        Area = ${lengthInFeet.toFixed(2)} feet (length) × ${widthInFeet.toFixed(2)} feet (width) = ${areaInSquareFeet.toFixed(2)} square feet
        <br><br>
        3. Converted the coverage to square feet if necessary:
        <br>
        Coverage = ${coverage} ${coverageUnit} = ${coverageInSquareFeet.toFixed(2)} square feet
        <br><br>
        4. Divided the area by the coverage to find the amount of sealant needed:
        <br>
        Sealant Needed = ${areaInSquareFeet.toFixed(2)} square feet / ${coverageInSquareFeet.toFixed(2)} square feet per unit = ${sealantNeeded.toFixed(2)} units
        <br><br>
        Therefore, you will need approximately ${sealantNeeded.toFixed(2)} units of sealant.
    `;

    document.getElementById('result').innerHTML = resultText;
    document.getElementById('result').style.display = 'block';
}
	function convertToFeet(value, unit) {
    switch (unit) {
        case 'meters':
            return value * 3.28084;
        case 'inches':
            return value / 12;
        case 'centimeters':
            return value / 30.48;
        case 'feet':
        default:
            return value;
    }
}
</script>
    <?php
    return ob_get_clean();
}

add_shortcode('sealant_calculator', 'sealant_calculator_shortcode');

//Spiral staircase calculator
function spiral_staircase_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Spiral Staircase Calculator</h1>
            <form id="spiralStaircaseForm">
                <div class="form-group">
                    <label for="totalHeight" class="form-label">Total Height:</label>
                    <input type="number" id="totalHeight" class="form-input" required>
                    <select id="totalHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="stepHeight" class="form-label">Step Height:</label>
                    <input type="number" id="stepHeight" class="form-input" required>
                    <select id="stepHeightUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSpiralStaircase()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
    function calculateSpiralStaircase() {
        const totalHeight = parseFloat(document.getElementById('totalHeight').value);
        const stepHeight = parseFloat(document.getElementById('stepHeight').value);

        const totalHeightUnit = document.getElementById('totalHeightUnit').value;
        const stepHeightUnit = document.getElementById('stepHeightUnit').value;

        if (isNaN(totalHeight) || isNaN(stepHeight)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert all measurements to inches
        const totalHeightInInches = convertToInches(totalHeight, totalHeightUnit);
        const stepHeightInInches = convertToInches(stepHeight, stepHeightUnit);

        // Calculate the number of steps
        const numberOfSteps = Math.ceil(totalHeightInInches / stepHeightInInches);

        const resultText = `
            To calculate the dimensions for your spiral staircase, we performed the following steps:
            <br><br>
            1. Converted the total height and step height to inches:
            <ul>
                <li>Total Height: ${totalHeight} ${totalHeightUnit} = ${totalHeightInInches.toFixed(2)} inches</li>
                <li>Step Height: ${stepHeight} ${stepHeightUnit} = ${stepHeightInInches.toFixed(2)} inches</li>
            </ul>
            2. Divided the total height by the step height to determine the number of steps:
            <br>
            Number of Steps = Total Height / Step Height
            <br>
            Number of Steps = ${totalHeightInInches.toFixed(2)} inches / ${stepHeightInInches.toFixed(2)} inches
            <br>
            Number of Steps = ${numberOfSteps} steps
            <br><br>
            Therefore, you will need approximately ${numberOfSteps} steps for your spiral staircase.
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 12;
            case 'meters':
                return value * 39.3701;
            case 'centimeters':
                return value * 0.393701;
            case 'inches':
            default:
                return value;
        }
    }
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('spiral_staircase_calculator', 'spiral_staircase_calculator_shortcode');

function pipe_weight_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Pipe Weight Calculator</h1>
            <form id="pipeWeightForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="meters">Meters</option>
                        <option value="feet">Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="outerDiameter" class="form-label">Outer Diameter:</label>
                    <input type="number" id="outerDiameter" class="form-input" required>
                    <select id="outerDiameterUnit" class="form-select">
                        <option value="centimeters">Centimeters</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Wall Thickness:</label>
                    <input type="number" id="thickness" class="form-input" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="centimeters">Centimeters</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="materialDensity" class="form-label">Material Density:</label>
                    <input type="number" id="materialDensity" class="form-input" required>
                    <select id="materialDensityUnit" class="form-select">
                        <option value="kg/m3">kg/m³</option>
                        <option value="lb/ft3">lb/ft³</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePipeWeight()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
        </div>
    </div>
<script>
	function calculatePipeWeight() {
    const length = parseFloat(document.getElementById('length').value);
    const outerDiameter = parseFloat(document.getElementById('outerDiameter').value);
    const thickness = parseFloat(document.getElementById('thickness').value);
    const materialDensity = parseFloat(document.getElementById('materialDensity').value);

    const lengthUnit = document.getElementById('lengthUnit').value;
    const outerDiameterUnit = document.getElementById('outerDiameterUnit').value;
    const thicknessUnit = document.getElementById('thicknessUnit').value;
    const materialDensityUnit = document.getElementById('materialDensityUnit').value;

    if (isNaN(length) || isNaN(outerDiameter) || isNaN(thickness) || isNaN(materialDensity)) {
        alert('Please enter valid numbers for all fields.');
        return;
    }

    // Convert all measurements to meters and centimeters where necessary
    const lengthInMeters = convertToMeters(length, lengthUnit);
    const outerDiameterInCm = convertToCentimeters(outerDiameter, outerDiameterUnit);
    const thicknessInCm = convertToCentimeters(thickness, thicknessUnit);

    // Convert material density to kg/m³ if necessary
    const densityInKgPerM3 = convertToKgPerM3(materialDensity, materialDensityUnit);

    // Calculate the volume of the pipe material in cubic meters
    const outerRadiusInMeters = outerDiameterInCm / 200;
    const innerRadiusInMeters = (outerDiameterInCm - 2 * thicknessInCm) / 200;
    const volume = Math.PI * lengthInMeters * (outerRadiusInMeters**2 - innerRadiusInMeters**2);

    // Calculate the weight of the pipe
    const weight = volume * densityInKgPerM3;

    const resultText = `
        To calculate the weight of the pipe, we performed the following steps:
        <br><br>
        1. Converted the dimensions to meters and centimeters:
        <ul>
            <li>Length: ${length} ${lengthUnit} = ${lengthInMeters.toFixed(2)} meters</li>
            <li>Outer Diameter: ${outerDiameter} ${outerDiameterUnit} = ${outerDiameterInCm.toFixed(2)} centimeters</li>
            <li>Wall Thickness: ${thickness} ${thicknessUnit} = ${thicknessInCm.toFixed(2)} centimeters</li>
        </ul>
        2. Converted the material density to kg/m³ if necessary:
        <br>
        Material Density = ${materialDensity} ${materialDensityUnit} = ${densityInKgPerM3.toFixed(2)} kg/m³
        <br><br>
        3. Calculated the volume of the pipe material:
        <br>
        Volume = π × Length × (Outer Radius² - Inner Radius²)
        <br>
        Volume = π × ${lengthInMeters.toFixed(2)} meters × (${outerRadiusInMeters.toFixed(2)} meters² - ${innerRadiusInMeters.toFixed(2)} meters²)
        <br>
        Volume = ${volume.toFixed(4)} cubic meters
        <br><br>
        4. Multiplied the volume by the material density to find the weight:
        <br>
        Weight = ${volume.toFixed(4)} cubic meters × ${densityInKgPerM3.toFixed(2)} kg/m³
        <br><br>
        Therefore, the weight of the pipe is approximately ${weight.toFixed(2)} kg.
    `;

    document.getElementById('result').innerHTML = resultText;
    document.getElementById('result').style.display = 'block';
}

function convertToMeters(value, unit) {
    switch (unit) {
        case 'feet':
            return value * 0.3048;
        case 'meters':
        default:
            return value;
    }
}

function convertToCentimeters(value, unit) {
    switch (unit) {
        case 'inches':
            return value * 2.54;
        case 'centimeters':
        default:
            return value;
    }
}

function convertToKgPerM3(value, unit) {
    switch (unit) {
        case 'lb/ft3':
            return value * 16.0185;
        case 'kg/m3':
        default:
            return value;
    }
}

</script>
    <?php
    return ob_get_clean();
}

add_shortcode('pipe_weight_calculator', 'pipe_weight_calculator_shortcode');

function french_drain_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>French Drain Calculator</h1>
            <form id="frenchDrainForm">
                <div class="form-group">
                    <label for="drainLength" class="form-label">Drain Length:</label>
                    <input type="number" id="drainLength" class="form-input" required>
                    <select id="drainLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="drainWidth" class="form-label">Drain Width:</label>
                    <input type="number" id="drainWidth" class="form-input" required>
                    <select id="drainWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="drainDepth" class="form-label">Drain Depth:</label>
                    <input type="number" id="drainDepth" class="form-input" required>
                    <select id="drainDepthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pipeDiameter" class="form-label">Pipe Diameter:</label>
                    <input type="number" id="pipeDiameter" class="form-input" required>
                    <select id="pipeDiameterUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateFrenchDrain()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateFrenchDrain() {
        const drainLength = parseFloat(document.getElementById('drainLength').value);
        const drainWidth = parseFloat(document.getElementById('drainWidth').value);
        const drainDepth = parseFloat(document.getElementById('drainDepth').value);
        const pipeDiameter = parseFloat(document.getElementById('pipeDiameter').value);

        const drainLengthUnit = document.getElementById('drainLengthUnit').value;
        const drainWidthUnit = document.getElementById('drainWidthUnit').value;
        const drainDepthUnit = document.getElementById('drainDepthUnit').value;
        const pipeDiameterUnit = document.getElementById('pipeDiameterUnit').value;

        if (isNaN(drainLength) || isNaN(drainWidth) || isNaN(drainDepth) || isNaN(pipeDiameter)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert all measurements to meters
        const drainLengthInMeters = convertToMeters(drainLength, drainLengthUnit);
        const drainWidthInMeters = convertToMeters(drainWidth, drainWidthUnit);
        const drainDepthInMeters = convertToMeters(drainDepth, drainDepthUnit);
        const pipeDiameterInMeters = convertToMeters(pipeDiameter, pipeDiameterUnit);

        // Calculate the volume of the drain in cubic meters
        const drainVolume = drainLengthInMeters * drainWidthInMeters * drainDepthInMeters;

        // Calculate the amount of gravel needed
        const gravelVolume = drainVolume - (Math.PI * (pipeDiameterInMeters / 2) ** 2 * drainLengthInMeters);

        // Calculate the length of pipe needed
        const pipeLength = drainLengthInMeters;

        const resultText = `
            You will need approximately ${gravelVolume.toFixed(2)} cubic meters of gravel and ${pipeLength.toFixed(2)} meters of pipe for your French drain.
        `;

        const explanationText = `
             <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements to Meters:</h3>
            <ul>
                <li>Drain Length: ${drainLength} ${drainLengthUnit} = ${drainLengthInMeters.toFixed(2)} meters</li>
                <li>Drain Width: ${drainWidth} ${drainWidthUnit} = ${drainWidthInMeters.toFixed(2)} meters</li>
                <li>Drain Depth: ${drainDepth} ${drainDepthUnit} = ${drainDepthInMeters.toFixed(2)} meters</li>
                <li>Pipe Diameter: ${pipeDiameter} ${pipeDiameterUnit} = ${pipeDiameterInMeters.toFixed(2)} meters</li>
            </ul>
            <h3>Drain Volume Calculation:</h3>
            <p>Drain Volume = Length × Width × Depth</p>
            <p>Drain Volume = ${drainLengthInMeters.toFixed(2)} meters × ${drainWidthInMeters.toFixed(2)} meters × ${drainDepthInMeters.toFixed(2)} meters</p>
            <p>Drain Volume = ${drainVolume.toFixed(2)} cubic meters</p>
            <h3>Gravel Volume Calculation:</h3>
            <p>Gravel Volume = Drain Volume - Pipe Volume</p>
            <p>Gravel Volume = ${drainVolume.toFixed(2)} cubic meters - π × (Diameter/2)² × Length</p>
            <p>Gravel Volume = ${gravelVolume.toFixed(2)} cubic meters</p>
            <h3>Pipe Length Calculation:</h3>
            <p>The length of pipe needed is the same as the drain length:</p>
            <p>Pipe Length = ${pipeLength.toFixed(2)} meters</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToMeters(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 0.3048;
            case 'inches':
                return value * 0.0254;
            case 'centimeters':
                return value * 0.01;
            case 'meters':
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('french_drain_calculator', 'french_drain_calculator_shortcode');

function tonnage_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Tonnage Calculator</h1>
            <form id="tonnageForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="height" class="form-label">Height:</label>
                    <input type="number" id="height" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="density" class="form-label">Material Density (lbs/ft³):</label>
                    <input type="number" id="density" class="form-input" required>
                </div>
                <button type="button" onclick="calculateTonnage()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateTonnage() {
        const length = parseFloat(document.getElementById('length').value);
        const width = parseFloat(document.getElementById('width').value);
        const height = parseFloat(document.getElementById('height').value);
        const density = parseFloat(document.getElementById('density').value);

        const lengthUnit = document.getElementById('lengthUnit').value;
        const widthUnit = document.getElementById('widthUnit').value;
        const heightUnit = document.getElementById('heightUnit').value;

        if (isNaN(length) || isNaN(width) || isNaN(height) || isNaN(density)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);

        const volumeInCubicFeet = lengthInFeet * widthInFeet * heightInFeet;
        const weightInPounds = volumeInCubicFeet * density;
        const tonnage = (weightInPounds / 2000).toFixed(2);

        const resultText = `You will need approximately ${tonnage} tons of material.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements to Feet:</h3>
            <ul>
                <li>Length: ${length} ${lengthUnit} = ${lengthInFeet.toFixed(2)} feet</li>
                <li>Width: ${width} ${widthUnit} = ${widthInFeet.toFixed(2)} feet</li>
                <li>Height: ${height} ${heightUnit} = ${heightInFeet.toFixed(2)} feet</li>
            </ul>
            <h3>Volume Calculation:</h3>
            <p>Volume = Length × Width × Height</p>
            <p>Volume = ${lengthInFeet.toFixed(2)} feet × ${widthInFeet.toFixed(2)} feet × ${heightInFeet.toFixed(2)} feet</p>
            <p>Volume = ${volumeInCubicFeet.toFixed(2)} cubic feet</p>
            <h3>Weight Calculation:</h3>
            <p>Weight = Volume × Density</p>
            <p>Weight = ${volumeInCubicFeet.toFixed(2)} cubic feet × ${density} lbs/ft³</p>
            <p>Weight = ${weightInPounds.toFixed(2)} pounds</p>
            <h3>Tonnage Calculation:</h3>
            <p>Tonnage = Weight / 2000</p>
            <p>Tonnage = ${weightInPounds.toFixed(2)} pounds / 2000</p>
            <p>Tonnage = ${tonnage} tons</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('tonnage_calculator', 'tonnage_calculator_shortcode');

function lumber_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Lumber Calculator</h1>
            <form id="lumberForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Thickness:</label>
                    <input type="number" id="thickness" class="form-input" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="quantity" class="form-label">Quantity:</label>
                    <input type="number" id="quantity" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="boardLength" class="form-label">Available Board Length (feet):</label>
                    <select id="boardLength" class="form-select">
                        <option value="8">8</option>
                        <option value="10">10</option>
                        <option value="12">12</option>
                        <option value="14">14</option>
                        <option value="16">16</option>
                    </select>
                </div>
                <button type="button" onclick="calculateLumber()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateLumber() {
        const length = parseFloat(document.getElementById('length').value);
        const width = parseFloat(document.getElementById('width').value);
        const thickness = parseFloat(document.getElementById('thickness').value);
        const quantity = parseFloat(document.getElementById('quantity').value);
        const boardLength = parseFloat(document.getElementById('boardLength').value);

        const lengthUnit = document.getElementById('lengthUnit').value;
        const widthUnit = document.getElementById('widthUnit').value;
        const thicknessUnit = document.getElementById('thicknessUnit').value;

        if (isNaN(length) || isNaN(width) || isNaN(thickness) || isNaN(quantity) || isNaN(boardLength)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const lengthInFeet = convertToFeet(length, lengthUnit);
        const boardLengthInFeet = boardLength;

        const areaPerBoard = lengthInFeet * width * (thickness / 12); // Convert thickness to feet

        const totalAreaNeeded = lengthInFeet * width * (thickness / 12) * quantity; // Total area needed

        const boardsNeeded = Math.ceil(totalAreaNeeded / areaPerBoard); // Round up to the nearest whole number

        const resultText = `You will need approximately ${boardsNeeded} boards of ${boardLength} feet each.`;
        const explanationText = `
             <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements to Feet:</h3>
            <ul>
                <li>Length: ${length} ${lengthUnit} = ${lengthInFeet.toFixed(2)} feet</li>
                <li>Width: ${width} ${widthUnit} = ${width} inches</li>
                <li>Thickness: ${thickness} ${thicknessUnit} = ${thickness} inches</li>
            </ul>
            <h3>Board Area Calculation:</h3>
            <p>Area per Board = Length × Width × (Thickness / 12)</p>
            <p>Area per Board = ${lengthInFeet.toFixed(2)} feet × ${width} inches × (${thickness} inches / 12)</p>
            <p>Area per Board = ${areaPerBoard.toFixed(2)} square feet</p>
            <h3>Total Area Needed:</h3>
            <p>Total Area Needed = Area per Board × Quantity</p>
            <p>Total Area Needed = ${areaPerBoard.toFixed(2)} square feet × ${quantity}</p>
            <p>Total Area Needed = ${totalAreaNeeded.toFixed(2)} square feet</p>
            <h3>Boards Needed:</h3>
            <p>Boards Needed = Total Area Needed / Area per Board</p>
            <p>Boards Needed = ${totalAreaNeeded.toFixed(2)} square feet / ${areaPerBoard.toFixed(2)} square feet per board</p>
            <p>Boards Needed ≈ ${boardsNeeded} boards</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('lumber_calculator', 'lumber_calculator_shortcode');

function vinyl_fence_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Vinyl Fence Calculator</h1>
            <form id="vinylFenceForm">
                <div class="form-group">
                    <label for="fenceLength" class="form-label">Fence Length:</label>
                    <input type="number" id="fenceLength" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="fenceHeight" class="form-label">Fence Height:</label>
                    <select id="fenceHeight" class="form-select">
                        <option value="3">3 Feet</option>
                        <option value="4">4 Feet</option>
                        <option value="5">5 Feet</option>
                        <option value="6">6 Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="panelWidth" class="form-label">Panel Width:</label>
                    <select id="panelWidth" class="form-select">
                        <option value="6">6 Feet</option>
                        <option value="8">8 Feet</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="postDistance" class="form-label">Distance Between Posts:</label>
                    <input type="number" id="postDistance" class="form-input" required>
                    <select id="distanceUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateVinylFence()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateVinylFence() {
        const fenceLength = parseFloat(document.getElementById('fenceLength').value);
        const fenceHeight = parseInt(document.getElementById('fenceHeight').value);
        const panelWidth = parseInt(document.getElementById('panelWidth').value);
        const postDistance = parseFloat(document.getElementById('postDistance').value);

        const lengthUnit = document.getElementById('lengthUnit').value;
        const distanceUnit = document.getElementById('distanceUnit').value;

        if (isNaN(fenceLength) || isNaN(postDistance)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const fenceLengthInFeet = convertToFeet(fenceLength, lengthUnit);
        const postDistanceInFeet = convertToFeet(postDistance, distanceUnit);

        const panelsNeeded = Math.ceil(fenceLengthInFeet / panelWidth);
        const postsNeeded = Math.ceil(fenceLengthInFeet / postDistanceInFeet);

        const resultText = `You will need ${panelsNeeded} panels and ${postsNeeded} posts for a ${fenceLength} ${lengthUnit} long vinyl fence at ${fenceHeight} feet high.`;
        const explanationText = `
          <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements to Feet:</h3>
            <ul>
                <li>Fence Length: ${fenceLength} ${lengthUnit} = ${fenceLengthInFeet.toFixed(2)} feet</li>
                <li>Distance Between Posts: ${postDistance} ${distanceUnit} = ${postDistanceInFeet.toFixed(2)} feet</li>
            </ul>
            <h3>Number of Panels Calculation:</h3>
            <p>Number of Panels = Ceiling(Fence Length / Panel Width)</p>
            <p>Number of Panels = Ceiling(${fenceLengthInFeet.toFixed(2)} / ${panelWidth})</p>
            <p>Number of Panels = ${panelsNeeded}</p>
            <h3>Number of Posts Calculation:</h3>
            <p>Number of Posts = Ceiling(Fence Length / Distance Between Posts)</p>
            <p>Number of Posts = Ceiling(${fenceLengthInFeet.toFixed(2)} / ${postDistanceInFeet.toFixed(2)})</p>
            <p>Number of Posts = ${postsNeeded}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('vinyl_fence_calculator', 'vinyl_fence_calculator_shortcode');


function aluminum_weight_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Aluminum Weight Calculator</h1>
            <form id="aluminumWeightForm">
                <div class="form-group">
                    <label for="length" class="form-label">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width" class="form-label">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="thickness" class="form-label">Thickness:</label>
                    <input type="number" id="thickness" class="form-input" step="0.01" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="millimeters">Millimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="density" class="form-label">Density (lbs/in³):</label>
                    <input type="number" id="density" class="form-input" step="0.001" required>
                </div>
                <button type="button" onclick="calculateAluminumWeight()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateAluminumWeight() {
        const length = parseFloat(document.getElementById('length').value);
        const width = parseFloat(document.getElementById('width').value);
        const thickness = parseFloat(document.getElementById('thickness').value);
        const density = parseFloat(document.getElementById('density').value);

        const lengthUnit = document.getElementById('lengthUnit').value;
        const widthUnit = document.getElementById('widthUnit').value;
        const thicknessUnit = document.getElementById('thicknessUnit').value;

        if (isNaN(length) || isNaN(width) || isNaN(thickness) || isNaN(density)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const area = calculateArea(length, width, lengthUnit, widthUnit);
        const volume = calculateVolume(area, thickness, thicknessUnit);

        const weight = volume * density;

        const resultText = `The weight of the aluminum plate is approximately ${weight.toFixed(2)} pounds.`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Area Calculation:</h3>
            <p>Area = Length × Width</p>
            <p>Area = ${length} ${lengthUnit} × ${width} ${widthUnit} = ${area.toFixed(2)} square inches</p>
            <h3>Volume Calculation:</h3>
            <p>Volume = Area × Thickness</p>
            <p>Volume = ${area.toFixed(2)} square inches × ${thickness} ${thicknessUnit} = ${volume.toFixed(2)} cubic inches</p>
            <h3>Weight Calculation:</h3>
            <p>Weight = Volume × Density</p>
            <p>Weight = ${volume.toFixed(2)} cubic inches × ${density} lbs/in³ = ${weight.toFixed(2)} pounds</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateArea(length, width, lengthUnit, widthUnit) {
        const lengthInInches = convertToInches(length, lengthUnit);
        const widthInInches = convertToInches(width, widthUnit);
        return lengthInInches * widthInInches;
    }

    function calculateVolume(area, thickness, thicknessUnit) {
        const thicknessInInches = convertToInches(thickness, thicknessUnit);
        return area * thicknessInInches;
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 12;
            case 'centimeters':
                return value / 2.54;
            case 'millimeters':
                return value / 25.4;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('aluminum_weight_calculator', 'aluminum_weight_calculator_shortcode');

function spindle_spacing_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Spindle Spacing Calculator</h1>
            <form id="spindleSpacingForm">
                <div class="form-group">
                    <label for="railingLength" class="form-label">Railing Length:</label>
                    <input type="number" id="railingLength" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spacing" class="form-label">Spacing Between Spindles:</label>
                    <input type="number" id="spacing" class="form-input" step="0.01" required>
                    <select id="spacingUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateSpindleSpacing()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateSpindleSpacing() {
        const railingLength = parseFloat(document.getElementById('railingLength').value);
        const spacing = parseFloat(document.getElementById('spacing').value);
        
        const lengthUnit = document.getElementById('lengthUnit').value;
        const spacingUnit = document.getElementById('spacingUnit').value;

        if (isNaN(railingLength) || isNaN(spacing)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const railingLengthInInches = convertToInches(railingLength, lengthUnit);
        const spacingInInches = convertToInches(spacing, spacingUnit);

        const numberOfSpindles = Math.ceil(railingLengthInInches / spacingInInches);
        const actualSpacing = railingLengthInInches / numberOfSpindles;

        const resultText = `You will need approximately ${numberOfSpindles} spindles with a spacing of ${actualSpacing.toFixed(2)} inches (${spacing} ${spacingUnit}) apart.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements to Inches:</h3>
            <ul>
                <li>Railing Length: ${railingLength} ${lengthUnit} = ${railingLengthInInches.toFixed(2)} inches</li>
                <li>Spacing Between Spindles: ${spacing} ${spacingUnit} = ${spacingInInches.toFixed(2)} inches</li>
            </ul>
            <h3>Number of Spindles Calculation:</h3>
            <p>Number of Spindles = Ceiling(Railing Length / Spacing)</p>
            <p>Number of Spindles = Ceiling(${railingLengthInInches.toFixed(2)} / ${spacingInInches.toFixed(2)})</p>
            <p>Number of Spindles = ${numberOfSpindles}</p>
            <h3>Actual Spacing Calculation:</h3>
            <p>Actual Spacing = Railing Length / Number of Spindles</p>
            <p>Actual Spacing = ${railingLengthInInches.toFixed(2)} inches / ${numberOfSpindles}</p>
            <p>Actual Spacing = ${actualSpacing.toFixed(2)} inches</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 12;
            case 'centimeters':
                return value / 2.54;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('spindle_spacing_calculator', 'spindle_spacing_calculator_shortcode');

function diy_shed_cost_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>DIY Shed Cost Calculator</h1>
            <form id="diyShedCostForm">
                <div class="form-group">
                    <label for="shedLength" class="form-label">Shed Length:</label>
                    <input type="number" id="shedLength" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shedWidth" class="form-label">Shed Width:</label>
                    <input type="number" id="shedWidth" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shedHeight" class="form-label">Shed Height:</label>
                    <input type="number" id="shedHeight" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="materialCost" class="form-label">Material Cost per Square Foot:</label>
                    <input type="number" id="materialCost" class="form-input" step="0.01" required>
                    <select id="currencyUnit" class="form-select">
                        <option value="usd">USD</option>
                        <option value="eur">EUR</option>
                        <option value="gbp">GBP</option>
                    </select>
                </div>
                <button type="button" onclick="calculateShedCost()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateShedCost() {
        const shedLength = parseFloat(document.getElementById('shedLength').value);
        const shedWidth = parseFloat(document.getElementById('shedWidth').value);
        const shedHeight = parseFloat(document.getElementById('shedHeight').value);
        const materialCost = parseFloat(document.getElementById('materialCost').value);

        const lengthUnit = document.getElementById('lengthUnit').value;
        const widthUnit = document.getElementById('widthUnit').value;
        const heightUnit = document.getElementById('heightUnit').value;
        const currencyUnit = document.getElementById('currencyUnit').value;

        if (isNaN(shedLength) || isNaN(shedWidth) || isNaN(shedHeight) || isNaN(materialCost)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const shedArea = calculateArea(shedLength, shedWidth, shedHeight, lengthUnit, widthUnit, heightUnit);
        const materialCostTotal = shedArea * materialCost;

        const resultText = `Estimated Cost for the DIY Shed: ${materialCostTotal.toFixed(2)} ${currencyUnit.toUpperCase()}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements:</h3>
            <ul>
                <li>Shed Length: ${shedLength} ${lengthUnit} = ${convertToFeet(shedLength, lengthUnit).toFixed(2)} feet</li>
                <li>Shed Width: ${shedWidth} ${widthUnit} = ${convertToFeet(shedWidth, widthUnit).toFixed(2)} feet</li>
                <li>Shed Height: ${shedHeight} ${heightUnit} = ${convertToFeet(shedHeight, heightUnit).toFixed(2)} feet</li>
            </ul>
            <h3>Area Calculation:</h3>
            <p>Shed Area = Length × Width × Height</p>
            <p>Shed Area = ${convertToFeet(shedLength, lengthUnit).toFixed(2)} feet × ${convertToFeet(shedWidth, widthUnit).toFixed(2)} feet × ${convertToFeet(shedHeight, heightUnit).toFixed(2)} feet = ${shedArea.toFixed(2)} square feet</p>
            <h3>Material Cost Calculation:</h3>
            <p>Material Cost Total = Shed Area × Material Cost per Square Foot</p>
            <p>Material Cost Total = ${shedArea.toFixed(2)} square feet × ${materialCost} ${currencyUnit.toUpperCase()} = ${materialCostTotal.toFixed(2)} ${currencyUnit.toUpperCase()}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateArea(length, width, height, lengthUnit, widthUnit, heightUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);
        return lengthInFeet * widthInFeet * heightInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('diy_shed_cost_calculator', 'diy_shed_cost_calculator_shortcode');


function concrete_stairs_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Concrete Stairs Calculator</h1>
            <form id="concreteStairsForm">
                <div class="form-group">
                    <label for="stairsWidth" class="form-label">Stairs Width:</label>
                    <input type="number" id="stairsWidth" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="stairsHeight" class="form-label">Stairs Height:</label>
                    <input type="number" id="stairsHeight" class="form-input" required>
                    <select id="heightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="stairsDepth" class="form-label">Stairs Depth:</label>
                    <input type="number" id="stairsDepth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="concreteThickness" class="form-label">Concrete Thickness:</label>
                    <input type="number" id="concreteThickness" class="form-input" step="0.01" required>
                    <select id="thicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateConcreteStairs()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateConcreteStairs() {
        const stairsWidth = parseFloat(document.getElementById('stairsWidth').value);
        const stairsHeight = parseFloat(document.getElementById('stairsHeight').value);
        const stairsDepth = parseFloat(document.getElementById('stairsDepth').value);
        const concreteThickness = parseFloat(document.getElementById('concreteThickness').value);

        const widthUnit = document.getElementById('widthUnit').value;
        const heightUnit = document.getElementById('heightUnit').value;
        const depthUnit = document.getElementById('depthUnit').value;
        const thicknessUnit = document.getElementById('thicknessUnit').value;

        if (isNaN(stairsWidth) || isNaN(stairsHeight) || isNaN(stairsDepth) || isNaN(concreteThickness)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const stairsArea = calculateArea(stairsWidth, stairsHeight, stairsDepth, widthUnit, heightUnit, depthUnit);
        const concreteVolume = calculateConcreteVolume(stairsArea, concreteThickness, thicknessUnit);

        const resultText = `Estimated Concrete Needed: ${concreteVolume.toFixed(2)} cubic ${thicknessUnit}`;
        const explanationText = `
           
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <ul>
                <li>Stairs Width: ${stairsWidth} ${widthUnit} = ${convertToFeet(stairsWidth, widthUnit).toFixed(2)} feet</li>
                <li>Stairs Height: ${stairsHeight} ${heightUnit} = ${convertToFeet(stairsHeight, heightUnit).toFixed(2)} feet</li>
                <li>Stairs Depth: ${stairsDepth} ${depthUnit} = ${convertToFeet(stairsDepth, depthUnit).toFixed(2)} feet</li>
                <li>Concrete Thickness: ${concreteThickness} ${thicknessUnit} = ${convertToFeet(concreteThickness, thicknessUnit).toFixed(2)} feet</li>
            </ul>
            <h3>Area Calculation:</h3>
            <p>Stairs Area = Width × Height × Depth</p>
            <p>Stairs Area = ${convertToFeet(stairsWidth, widthUnit).toFixed(2)} feet × ${convertToFeet(stairsHeight, heightUnit).toFixed(2)} feet × ${convertToFeet(stairsDepth, depthUnit).toFixed(2)} feet = ${stairsArea.toFixed(2)} cubic feet</p>
            <h3>Concrete Volume Calculation:</h3>
            <p>Concrete Volume = Stairs Area × Concrete Thickness</p>
            <p>Concrete Volume = ${stairsArea.toFixed(2)} cubic feet × ${convertToFeet(concreteThickness, thicknessUnit).toFixed(2)} feet = ${concreteVolume.toFixed(2)} cubic ${thicknessUnit}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateArea(width, height, depth, widthUnit, heightUnit, depthUnit) {
        const widthInFeet = convertToFeet(width, widthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);
        const depthInFeet = convertToFeet(depth, depthUnit);
        return widthInFeet * heightInFeet * depthInFeet;
    }

    function calculateConcreteVolume(area, thickness, thicknessUnit) {
        const thicknessInFeet = convertToFeet(thickness, thicknessUnit);
        return area * thicknessInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('concrete_stairs_calculator', 'concrete_stairs_calculator_shortcode');

function hole_volume_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Hole Volume Calculator</h1>
            <form id="holeVolumeForm">
                <div class="form-group">
                    <label for="holeDiameter" class="form-label">Hole Diameter:</label>
                    <input type="number" id="holeDiameter" class="form-input" step="0.01" required>
                    <select id="diameterUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="holeDepth" class="form-label">Hole Depth:</label>
                    <input type="number" id="holeDepth" class="form-input" step="0.01" required>
                    <select id="depthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateHoleVolume()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateHoleVolume() {
        const holeDiameter = parseFloat(document.getElementById('holeDiameter').value);
        const holeDepth = parseFloat(document.getElementById('holeDepth').value);

        const diameterUnit = document.getElementById('diameterUnit').value;
        const depthUnit = document.getElementById('depthUnit').value;

        if (isNaN(holeDiameter) || isNaN(holeDepth)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const holeVolume = calculateVolume(holeDiameter, holeDepth, diameterUnit, depthUnit);

        const resultText = `Estimated Volume of the Hole: ${holeVolume.toFixed(2)} cubic ${depthUnit}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements:</h3>
            <ul>
                <li>Hole Diameter: ${holeDiameter} ${diameterUnit} = ${convertToFeet(holeDiameter, diameterUnit).toFixed(2)} feet</li>
                <li>Hole Depth: ${holeDepth} ${depthUnit} = ${convertToFeet(holeDepth, depthUnit).toFixed(2)} feet</li>
            </ul>
            <h3>Volume Calculation:</h3>
            <p>Hole Volume = π × (Diameter / 2)^2 × Depth</p>
            <p>Hole Volume = π × (${convertToFeet(holeDiameter, diameterUnit) / 2} feet)^2 × ${convertToFeet(holeDepth, depthUnit).toFixed(2)} feet</p>
            <p>Hole Volume ≈ ${holeVolume.toFixed(2)} cubic ${depthUnit}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateVolume(diameter, depth, diameterUnit, depthUnit) {
        const radius = convertToFeet(diameter / 2, diameterUnit);
        const depthInFeet = convertToFeet(depth, depthUnit);
        return Math.PI * Math.pow(radius, 2) * depthInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('hole_volume_calculator', 'hole_volume_calculator_shortcode');

function grout_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Grout Calculator</h1>
            <form id="groutCalculatorForm">
                <div class="form-group">
                    <label for="tileLength" class="form-label">Tile Length:</label>
                    <input type="number" id="tileLength" class="form-input" step="0.01" required>
                    <select id="tileLengthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileWidth" class="form-label">Tile Width:</label>
                    <input type="number" id="tileWidth" class="form-input" step="0.01" required>
                    <select id="tileWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileThickness" class="form-label">Tile Thickness:</label>
                    <input type="number" id="tileThickness" class="form-input" step="0.01" required>
                    <select id="tileThicknessUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="groutWidth" class="form-label">Grout Width:</label>
                    <input type="number" id="groutWidth" class="form-input" step="0.01" required>
                    <select id="groutWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tileArea" class="form-label">Tile Area (Optional):</label>
                    <input type="number" id="tileArea" class="form-input" step="0.01">
                    <select id="tileAreaUnit" class="form-select">
                        <option value="square_inches">Sq Inches</option>
                        <option value="square_feet">Sq Feet</option>
                        <option value="square_centimeters">Sq Cm</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGrout()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateGrout() {
        const tileLength = parseFloat(document.getElementById('tileLength').value);
        const tileWidth = parseFloat(document.getElementById('tileWidth').value);
        const tileThickness = parseFloat(document.getElementById('tileThickness').value);
        const groutWidth = parseFloat(document.getElementById('groutWidth').value);
        const tileArea = parseFloat(document.getElementById('tileArea').value) || calculateTileArea(tileLength, tileWidth, tileThickness);
        
        const tileLengthUnit = document.getElementById('tileLengthUnit').value;
        const tileWidthUnit = document.getElementById('tileWidthUnit').value;
        const tileThicknessUnit = document.getElementById('tileThicknessUnit').value;
        const groutWidthUnit = document.getElementById('groutWidthUnit').value;
        const tileAreaUnit = document.getElementById('tileAreaUnit').value;

        if (isNaN(tileLength) || isNaN(tileWidth) || isNaN(tileThickness) || isNaN(groutWidth)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const groutVolume = calculateGroutVolume(tileLength, tileWidth, tileThickness, groutWidth, tileArea, tileLengthUnit, tileWidthUnit, tileThicknessUnit, groutWidthUnit, tileAreaUnit);

        const resultText = `Estimated Grout Needed: ${groutVolume.toFixed(2)} cubic ${groutWidthUnit}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements:</h3>
            <ul>
                <li>Tile Length: ${tileLength} ${tileLengthUnit} = ${convertToFeet(tileLength, tileLengthUnit).toFixed(2)} feet</li>
                <li>Tile Width: ${tileWidth} ${tileWidthUnit} = ${convertToFeet(tileWidth, tileWidthUnit).toFixed(2)} feet</li>
                <li>Tile Thickness: ${tileThickness} ${tileThicknessUnit} = ${convertToFeet(tileThickness, tileThicknessUnit).toFixed(2)} feet</li>
                <li>Grout Width: ${groutWidth} ${groutWidthUnit} = ${convertToFeet(groutWidth, groutWidthUnit).toFixed(2)} feet</li>
            </ul>
            <h3>Tile Area Calculation:</h3>
            <p>Tile Area = Tile Length × Tile Width × Tile Thickness</p>
            <p>Tile Area = ${convertToFeet(tileLength, tileLengthUnit).toFixed(2)} feet × ${convertToFeet(tileWidth, tileWidthUnit).toFixed(2)} feet × ${convertToFeet(tileThickness, tileThicknessUnit).toFixed(2)} feet = ${tileArea.toFixed(2)} ${tileAreaUnit}</p>
            <h3>Grout Volume Calculation:</h3>
            <p>Grout Volume = Tile Area × Grout Width</p>
            <p>Grout Volume = ${tileArea.toFixed(2)} ${tileAreaUnit} × ${convertToFeet(groutWidth, groutWidthUnit).toFixed(2)} feet = ${groutVolume.toFixed(2)} cubic ${groutWidthUnit}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateTileArea(length, width, thickness) {
        return length * width * thickness;
    }

    function calculateGroutVolume(length, width, thickness, groutWidth, area, lengthUnit, widthUnit, thicknessUnit, groutWidthUnit, areaUnit) {
        const tileAreaInFeet = convertToFeet(area, areaUnit);
        const groutWidthInFeet = convertToFeet(groutWidth, groutWidthUnit);
        return tileAreaInFeet * groutWidthInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            case 'square_feet':
                return value;
            case 'square_inches':
                return value / 144;
            case 'square_centimeters':
                return value / 929;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('grout_calculator', 'grout_calculator_shortcode');

function shiplap_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Shiplap Calculator</h1>
            <form id="shiplapCalculatorForm">
                <div class="form-group">
                    <label for="wallWidth" class="form-label">Wall Width:</label>
                    <input type="number" id="wallWidth" class="form-input" step="0.01" required>
                    <select id="wallWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallHeight" class="form-label">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" step="0.01" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shiplapWidth" class="form-label">Shiplap Board Width:</label>
                    <input type="number" id="shiplapWidth" class="form-input" step="0.01" required>
                    <select id="shiplapWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shiplapLength" class="form-label">Shiplap Board Length:</label>
                    <input type="number" id="shiplapLength" class="form-input" step="0.01" required>
                    <select id="shiplapLengthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateShiplap()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateShiplap() {
        const wallWidth = parseFloat(document.getElementById('wallWidth').value);
        const wallHeight = parseFloat(document.getElementById('wallHeight').value);
        const shiplapWidth = parseFloat(document.getElementById('shiplapWidth').value);
        const shiplapLength = parseFloat(document.getElementById('shiplapLength').value);
        
        const wallWidthUnit = document.getElementById('wallWidthUnit').value;
        const wallHeightUnit = document.getElementById('wallHeightUnit').value;
        const shiplapWidthUnit = document.getElementById('shiplapWidthUnit').value;
        const shiplapLengthUnit = document.getElementById('shiplapLengthUnit').value;

        if (isNaN(wallWidth) || isNaN(wallHeight) || isNaN(shiplapWidth) || isNaN(shiplapLength)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const shiplapNeeded = calculateShiplapNeeded(wallWidth, wallHeight, shiplapWidth, shiplapLength, wallWidthUnit, wallHeightUnit, shiplapWidthUnit, shiplapLengthUnit);

        const resultText = `Shiplap Boards Needed: ${shiplapNeeded.quantity.toFixed(2)}`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Converted Measurements:</h3>
            <ul>
                <li>Wall Width: ${wallWidth} ${wallWidthUnit} = ${convertToFeet(wallWidth, wallWidthUnit).toFixed(2)} feet</li>
                <li>Wall Height: ${wallHeight} ${wallHeightUnit} = ${convertToFeet(wallHeight, wallHeightUnit).toFixed(2)} feet</li>
                <li>Shiplap Board Width: ${shiplapWidth} ${shiplapWidthUnit} = ${convertToFeet(shiplapWidth, shiplapWidthUnit).toFixed(2)} feet</li>
                <li>Shiplap Board Length: ${shiplapLength} ${shiplapLengthUnit} = ${convertToFeet(shiplapLength, shiplapLengthUnit).toFixed(2)} feet</li>
            </ul>
            <h3>Shiplap Needed Calculation:</h3>
            <p>Shiplap Boards Needed = (Wall Width × Wall Height) / (Shiplap Board Width × Shiplap Board Length)</p>
            <p>Shiplap Boards Needed = (${convertToFeet(wallWidth, wallWidthUnit).toFixed(2)} feet × ${convertToFeet(wallHeight, wallHeightUnit).toFixed(2)} feet) / (${convertToFeet(shiplapWidth, shiplapWidthUnit).toFixed(2)} feet × ${convertToFeet(shiplapLength, shiplapLengthUnit).toFixed(2)} feet) = ${shiplapNeeded.quantity.toFixed(2)}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateShiplapNeeded(wallWidth, wallHeight, shiplapWidth, shiplapLength, wallWidthUnit, wallHeightUnit, shiplapWidthUnit, shiplapLengthUnit) {
        const wallWidthInFeet = convertToFeet(wallWidth, wallWidthUnit);
        const wallHeightInFeet = convertToFeet(wallHeight, wallHeightUnit);
        const shiplapWidthInFeet = convertToFeet(shiplapWidth, shiplapWidthUnit);
        const shiplapLengthInFeet = convertToFeet(shiplapLength, shiplapLengthUnit);
        const areaToCover = wallWidthInFeet * wallHeightInFeet;
        const shiplapArea = shiplapWidthInFeet * shiplapLengthInFeet;
        const boardsNeeded = areaToCover / shiplapArea;
        return { quantity: boardsNeeded };
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12;
            case 'centimeters':
                return value / 30.48;
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('shiplap_calculator', 'shiplap_calculator_shortcode');

function ach_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Air Changes per Hour (ACH) Calculator</h1>
            <form id="achCalculatorForm">
                <div class="form-group">
                    <label for="roomLength" class="form-label">Room Length:</label>
                    <input type="number" id="roomLength" class="form-input" step="0.01" required>
                    <select id="roomLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roomWidth" class="form-label">Room Width:</label>
                    <input type="number" id="roomWidth" class="form-input" step="0.01" required>
                    <select id="roomWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roomHeight" class="form-label">Room Height:</label>
                    <input type="number" id="roomHeight" class="form-input" step="0.01" required>
                    <select id="roomHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="airflowRate" class="form-label">Airflow Rate (CFM):</label>
                    <input type="number" id="airflowRate" class="form-input" step="0.01" required>
                </div>
                <button type="button" onclick="calculateACH()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateACH() {
        const roomLength = parseFloat(document.getElementById('roomLength').value);
        const roomWidth = parseFloat(document.getElementById('roomWidth').value);
        const roomHeight = parseFloat(document.getElementById('roomHeight').value);
        const airflowRate = parseFloat(document.getElementById('airflowRate').value);

        const roomLengthUnit = document.getElementById('roomLengthUnit').value;
        const roomWidthUnit = document.getElementById('roomWidthUnit').value;
        const roomHeightUnit = document.getElementById('roomHeightUnit').value;

        if (isNaN(roomLength) || isNaN(roomWidth) || isNaN(roomHeight) || isNaN(airflowRate)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const roomVolume = calculateRoomVolume(roomLength, roomWidth, roomHeight, roomLengthUnit, roomWidthUnit, roomHeightUnit);
        const ach = calculateAirChangesPerHour(roomVolume, airflowRate);

        const resultText = `Air Changes per Hour (ACH): ${ach.toFixed(2)}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Room Volume Calculation:</h3>
            <p>Room Volume = Room Length × Room Width × Room Height</p>
            <p>Room Volume = ${roomVolume.toFixed(2)} cubic feet</p>
            <h3>Air Changes per Hour (ACH) Calculation:</h3>
            <p>ACH = (Airflow Rate × 60) / Room Volume</p>
            <p>ACH = (${airflowRate} CFM × 60) / ${roomVolume.toFixed(2)} cubic feet = ${ach.toFixed(2)}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateRoomVolume(length, width, height, lengthUnit, widthUnit, heightUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);
        return lengthInFeet * widthInFeet * heightInFeet;
    }

    function calculateAirChangesPerHour(volume, airflowRate) {
        return (airflowRate * 60) / volume;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('ach_calculator', 'ach_calculator_shortcode');


function chicken_coop_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Chicken Coop Size Calculator</h1>
            <form id="chickenCoopCalculatorForm">
                <div class="form-group">
                    <label for="numChickens" class="form-label">Number of Chickens:</label>
                    <input type="number" id="numChickens" class="form-input" min="1" required>
                </div>
                <button type="button" onclick="calculateChickenCoopSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateChickenCoopSize() {
        const numChickens = parseInt(document.getElementById('numChickens').value);

        if (isNaN(numChickens) || numChickens < 1) {
            alert('Please enter a valid number of chickens (minimum 1).');
            return;
        }

        const coopSize = calculateCoopSize(numChickens);
        const resultText = `Minimum Chicken Coop Size Needed: ${coopSize.width.toFixed(2)} feet wide by ${coopSize.length.toFixed(2)} feet long`;
        const explanationText = `
             <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Based on industry standards, each chicken requires approximately 2-4 square feet of space inside the coop.</p>
            <p>Therefore, for ${numChickens} chickens:</p>
            <ul>
                <li>Width needed: ${coopSize.width.toFixed(2)} feet (${coopSize.width * 12} inches)</li>
                <li>Length needed: ${coopSize.length.toFixed(2)} feet (${coopSize.length * 12} inches)</li>
            </ul>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateCoopSize(numChickens) {
        // Calculate based on 2.5 square feet per chicken as a guideline
        const squareFeetPerChicken = 2.5;
        const totalSquareFeetNeeded = numChickens * squareFeetPerChicken;
        
        // Assume a rectangular coop shape with reasonable dimensions
        // Adjust as per practical requirements
        const width = Math.sqrt(totalSquareFeetNeeded); // Square root gives a reasonable width
        const length = totalSquareFeetNeeded / width;   // Length adjusted accordingly

        return { width, length };
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('chicken_coop_calculator', 'chicken_coop_calculator_shortcode');

function ramp_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Ramp Calculator</h1>
            <form id="rampCalculatorForm">
                <div class="form-group">
                    <label for="rampLength" class="form-label">Ramp Length:</label>
                    <input type="number" id="rampLength" class="form-input" step="0.01" required>
                    <select id="rampLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="rampHeight" class="form-label">Ramp Height:</label>
                    <input type="number" id="rampHeight" class="form-input" step="0.01" required>
                    <select id="rampHeightUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="rampSlope" class="form-label">Ramp Slope:</label>
                    <input type="text" id="rampSlope" class="form-input" readonly>
                    <span id="slopeUnit">%</span>
                </div>
                <button type="button" onclick="calculateRamp()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRamp() {
        const rampLength = parseFloat(document.getElementById('rampLength').value);
        const rampHeight = parseFloat(document.getElementById('rampHeight').value);
        
        const rampLengthUnit = document.getElementById('rampLengthUnit').value;
        const rampHeightUnit = document.getElementById('rampHeightUnit').value;

        if (isNaN(rampLength) || isNaN(rampHeight)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        const slope = calculateRampSlope(rampLength, rampHeight, rampLengthUnit, rampHeightUnit);

        document.getElementById('rampSlope').value = slope.toFixed(2);
        
        const resultText = `Ramp Slope: ${slope.toFixed(2)}%`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <h3>Ramp Slope Calculation:</h3>
            <p>Ramp Slope = (Ramp Height / Ramp Length) × 100</p>
            <p>Ramp Slope = (${rampHeight} ${rampHeightUnit} / ${rampLength} ${rampLengthUnit}) × 100 = ${slope.toFixed(2)}%</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateRampSlope(length, height, lengthUnit, heightUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);
        return (heightInFeet / lengthInFeet) * 100;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            case 'inches':
                return value / 12; // 12 inches = 1 foot
            default:
                return value;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('ramp_calculator', 'ramp_calculator_shortcode');


function clearance_hole_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Clearance Hole Calculator</h1>
            <form id="clearanceHoleCalculatorForm">
                <div class="form-group">
                    <label for="boltSize">Bolt Size:</label>
                    <select id="boltSize" class="form-select">
                        <option value="M3">M3</option>
                        <option value="M4">M4</option>
                        <option value="M5">M5</option>
                        <option value="M6">M6</option>
                        <option value="M8">M8</option>
                        <option value="M10">M10</option>
                        <option value="M12">M12</option>
                        <option value="M16">M16</option>
                        <option value="M20">M20</option>
                        <option value="M24">M24</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="toleranceClass">Tolerance Class:</label>
                    <select id="toleranceClass" class="form-select">
                        <option value="6g">6g</option>
                        <option value="6h">6h</option>
                        <option value="5g6g">5g6g</option>
                        <option value="5h6h">5h6h</option>
                        <option value="4g6g">4g6g</option>
                        <option value="4h6h">4h6h</option>
                    </select>
                </div>
                <button type="button" onclick="calculateClearanceHole()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateClearanceHole() {
        const boltSize = document.getElementById('boltSize').value;
        const toleranceClass = document.getElementById('toleranceClass').value;

        const clearanceHole = calculateClearanceHoleDiameter(boltSize, toleranceClass);

        const resultText = `Recommended Clearance Hole Diameter for ${boltSize} (${toleranceClass}): ${clearanceHole.toFixed(2)} mm`;
        const explanationText = `
             <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The recommended clearance hole diameter is determined based on the bolt size and tolerance class.</p>
            <p>For ${boltSize} (${toleranceClass}), the recommended clearance hole diameter is ${clearanceHole.toFixed(2)} mm.</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateClearanceHoleDiameter(boltSize, toleranceClass) {
        // Define clearance hole diameters for each bolt size and tolerance class
        const clearanceHoleSizes = {
            "M3": {
                "6g": 3.4, // Example values, adjust as needed
                "6h": 3.2,
                "5g6g": 3.6,
                "5h6h": 3.4,
                "4g6g": 3.8,
                "4h6h": 3.6
            },
            "M4": {
                "6g": 4.5,
                "6h": 4.3,
                "5g6g": 4.7,
                "5h6h": 4.5,
                "4g6g": 4.9,
                "4h6h": 4.7
            },
            "M5": {
                "6g": 5.5,
                "6h": 5.3,
                "5g6g": 5.7,
                "5h6h": 5.5,
                "4g6g": 5.9,
                "4h6h": 5.7
            },
            "M6": {
                "6g": 6.6,
                "6h": 6.4,
                "5g6g": 6.8,
                "5h6h": 6.6,
                "4g6g": 7.0,
                "4h6h": 6.8
            },
            "M8": {
                "6g": 8.8,
                "6h": 8.6,
                "5g6g": 9.0,
                "5h6h": 8.8,
                "4g6g": 9.2,
                "4h6h": 9.0
            },
            "M10": {
                "6g": 11.0,
                "6h": 10.7,
                "5g6g": 11.2,
                "5h6h": 10.9,
                "4g6g": 11.4,
                "4h6h": 11.1
            },
            "M12": {
                "6g": 13.0,
                "6h": 12.7,
                "5g6g": 13.2,
                "5h6h": 12.9,
                "4g6g": 13.4,
                "4h6h": 13.1
            },
            "M16": {
                "6g": 17.6,
                "6h": 17.2,
                "5g6g": 17.8,
                "5h6h": 17.4,
                "4g6g": 18.0,
                "4h6h": 17.6
            },
            "M20": {
                "6g": 22.0,
                "6h": 21.5,
                "5g6g": 22.2,
                "5h6h": 21.7,
                "4g6g": 22.4,
                "4h6h": 21.9
            },
            "M24": {
                "6g": 26.0,
                "6h": 25.5,
                "5g6g": 26.2,
                "5h6h": 25.7,
                "4g6g": 26.4,
                "4h6h": 25.9
            }
        };

        // Get the clearance hole diameter based on bolt size and tolerance class
        return clearanceHoleSizes[boltSize][toleranceClass];
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('clearance_hole_calculator', 'clearance_hole_calculator_shortcode');


function hoop_house_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Hoop House Calculator</h1>
            <form id="hoopHouseCalculatorForm">
                <div class="form-group">
                    <label for="widthFeet">Width:</label>
                    <input type="number" id="widthFeet" class="form-input" placeholder="Feet" required>
                    <input type="number" id="widthInches" class="form-input" placeholder="Inches">
                </div>
                <div class="form-group">
                    <label for="lengthFeet">Length:</label>
                    <input type="number" id="lengthFeet" class="form-input" placeholder="Feet" required>
                    <input type="number" id="lengthInches" class="form-input" placeholder="Inches">
                </div>
                <div class="form-group">
                    <label for="heightFeet">Height:</label>
                    <input type="number" id="heightFeet" class="form-input" placeholder="Feet" required>
                    <input type="number" id="heightInches" class="form-input" placeholder="Inches">
                </div>
                <div class="form-group">
                    <label for="materialCost">Material Cost per Square Foot ($):</label>
                    <input type="number" id="materialCost" class="form-input" step="0.01" required>
                </div>
                <button type="button" onclick="calculateHoopHouse()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateHoopHouse() {
        const widthFeet = parseFloat(document.getElementById('widthFeet').value);
        const widthInches = parseFloat(document.getElementById('widthInches').value || 0);
        const lengthFeet = parseFloat(document.getElementById('lengthFeet').value);
        const lengthInches = parseFloat(document.getElementById('lengthInches').value || 0);
        const heightFeet = parseFloat(document.getElementById('heightFeet').value);
        const heightInches = parseFloat(document.getElementById('heightInches').value || 0);
        const materialCost = parseFloat(document.getElementById('materialCost').value);

        // Convert dimensions to feet for calculation
        const width = widthFeet + (widthInches / 12);
        const length = lengthFeet + (lengthInches / 12);
        const height = heightFeet + (heightInches / 12);

        // Calculate area
        const area = width * length;

        // Calculate perimeter (for door calculations, etc.)
        const perimeter = 2 * (width + length);

        // Calculate total cost based on area and material cost
        const totalCost = area * materialCost;

        // Prepare result and explanation text
        const resultText = `Total Cost for Hoop House: $${totalCost.toFixed(2)}`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Dimensions: ${widthFeet} feet ${widthInches} inches (width) x ${lengthFeet} feet ${lengthInches} inches (length) x ${heightFeet} feet ${heightInches} inches (height)</p>
            <p>Material Cost per Square Foot: $${materialCost.toFixed(2)}</p>
            <p>Area: ${area.toFixed(2)} square feet</p>
            <p>Total Cost Calculation: ${area.toFixed(2)} sq.ft. x $${materialCost.toFixed(2)}/sq.ft. = $${totalCost.toFixed(2)}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('hoop_house_calculator', 'hoop_house_calculator_shortcode');



function epoxy_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Epoxy Calculator</h1>
            <form id="epoxyCalculatorForm">
                <div class="form-group">
                    <label for="projectLength">Project Length:</label>
                    <input type="number" id="projectLength" class="form-input" required>
                    <select id="projectLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="projectWidth">Project Width:</label>
                    <input type="number" id="projectWidth" class="form-input" required>
                    <select id="projectWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="epoxyThickness">Epoxy Thickness:</label>
                    <input type="number" id="epoxyThickness" class="form-input" required>
                    <select id="epoxyThicknessUnit" class="form-select">
                        <option value="mil">Mil</option>
                        <option value="inch">Inch</option>
                        <option value="cm">Centimeter</option>
                        <option value="mm">Millimeter</option>
                    </select>
                </div>
                <button type="button" onclick="calculateEpoxy()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateEpoxy() {
        const projectLength = parseFloat(document.getElementById('projectLength').value);
        const projectWidth = parseFloat(document.getElementById('projectWidth').value);
        const epoxyThickness = parseFloat(document.getElementById('epoxyThickness').value);

        const projectLengthUnit = document.getElementById('projectLengthUnit').value;
        const projectWidthUnit = document.getElementById('projectWidthUnit').value;
        const epoxyThicknessUnit = document.getElementById('epoxyThicknessUnit').value;

        if (isNaN(projectLength) || isNaN(projectWidth) || isNaN(epoxyThickness)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert dimensions to inches
        const projectAreaInSquareInches = convertToSquareInches(projectLength, projectLengthUnit) *
                                          convertToSquareInches(projectWidth, projectWidthUnit);

        // Convert thickness to inches
        const epoxyThicknessInInches = convertToInches(epoxyThickness, epoxyThicknessUnit);

        // Calculate volume of epoxy needed
        const epoxyVolumeInCubicInches = projectAreaInSquareInches * epoxyThicknessInInches;

        // Convert volume to liters (standard epoxy calculation: 231 cubic inches = 1 gallon)
        const epoxyVolumeInLiters = epoxyVolumeInCubicInches / 231;

        const resultText = `You will need approximately ${epoxyVolumeInLiters.toFixed(2)} liters of epoxy resin and hardener.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The epoxy volume calculation is based on the project dimensions and desired epoxy thickness.</p>
            <p>Project Area: ${projectAreaInSquareInches.toFixed(2)} square inches</p>
            <p>Epoxy Thickness: ${epoxyThicknessInInches.toFixed(2)} inches</p>
            <p>Epoxy Volume Required: ${epoxyVolumeInLiters.toFixed(2)} liters</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareInches(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 144; // 1 sq ft = 144 sq inches
            case 'inches':
                return value;
            case 'centimeters':
                return value * 0.155; // Approximate conversion
            case 'meters':
                return value * 1550; // Approximate conversion
            default:
                return 0;
        }
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'mil':
                return value / 1000; // 1 mil = 0.001 inch
            case 'inch':
                return value;
            case 'cm':
                return value / 2.54; // 1 inch = 2.54 cm
            case 'mm':
                return value / 25.4; // 1 inch = 25.4 mm
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('epoxy_calculator', 'epoxy_calculator_shortcode');


function ladder_angle_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Ladder Angle Calculator</h1>
            <form id="ladderAngleCalculatorForm">
                <div class="form-group">
                    <label for="ladderHeight">Ladder Height:</label>
                    <input type="number" id="ladderHeight" class="form-input" required>
                    <select id="ladderHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="safetyAngle">Safety Angle:</label>
                    <input type="number" id="safetyAngle" class="form-input" value="75" min="70" max="80" required>
                    <span>&deg;</span>
                </div>
                <button type="button" onclick="calculateLadderAngle()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateLadderAngle() {
        const ladderHeight = parseFloat(document.getElementById('ladderHeight').value);
        const safetyAngle = parseFloat(document.getElementById('safetyAngle').value);

        const ladderHeightUnit = document.getElementById('ladderHeightUnit').value;

        if (isNaN(ladderHeight) || isNaN(safetyAngle)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert ladder height to inches for calculation
        const ladderHeightInInches = convertToInches(ladderHeight, ladderHeightUnit);

        // Calculate the required ladder angle in radians
        const ladderAngleInRadians = calculateLadderAngleRadians(ladderHeightInInches, safetyAngle);

        // Convert radians to degrees for display
        const ladderAngleInDegrees = radiansToDegrees(ladderAngleInRadians);

        const resultText = `Recommended Ladder Angle: ${ladderAngleInDegrees.toFixed(2)}&deg;`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The recommended ladder angle is calculated based on the ladder height and safety angle.</p>
            <p>Ladder Height: ${ladderHeightInInches.toFixed(2)} inches</p>
            <p>Safety Angle: ${safetyAngle}&deg;</p>
            <p>Recommended Ladder Angle: ${ladderAngleInDegrees.toFixed(2)}&deg;</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'inches':
                return value;
            case 'centimeters':
                return value * 0.393701; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function calculateLadderAngleRadians(heightInInches, safetyAngle) {
        // Calculate the ladder angle in radians
        const radians = Math.atan(heightInInches / (Math.cos(degreesToRadians(90 - safetyAngle))));
        return radians;
    }

    function degreesToRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    function radiansToDegrees(radians) {
        return radians * (180 / Math.PI);
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('ladder_angle_calculator', 'ladder_angle_calculator_shortcode');

function heat_loss_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Heat Loss Calculator</h1>
            <form id="heatLossCalculatorForm">
                <div class="form-group">
                    <label for="roomWidth">Room Width:</label>
                    <input type="number" id="roomWidth" class="form-input" required>
                    <select id="roomWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roomLength">Room Length:</label>
                    <input type="number" id="roomLength" class="form-input" required>
                    <select id="roomLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="ceilingHeight">Ceiling Height:</label>
                    <input type="number" id="ceilingHeight" class="form-input" required>
                    <select id="ceilingHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="uValue">Overall U-Value (W/m²K):</label>
                    <input type="number" id="uValue" class="form-input" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="temperatureDifference">Temperature Difference (Indoor-Outdoor):</label>
                    <input type="number" id="temperatureDifference" class="form-input" required>
                    <select id="temperatureDifferenceUnit" class="form-select">
                        <option value="celsius">Celsius</option>
                        <option value="fahrenheit">Fahrenheit</option>
                    </select>
                </div>
                <button type="button" onclick="calculateHeatLoss()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateHeatLoss() {
        const roomWidth = parseFloat(document.getElementById('roomWidth').value);
        const roomLength = parseFloat(document.getElementById('roomLength').value);
        const ceilingHeight = parseFloat(document.getElementById('ceilingHeight').value);
        const uValue = parseFloat(document.getElementById('uValue').value);
        const temperatureDifference = parseFloat(document.getElementById('temperatureDifference').value);

        const roomWidthUnit = document.getElementById('roomWidthUnit').value;
        const roomLengthUnit = document.getElementById('roomLengthUnit').value;
        const ceilingHeightUnit = document.getElementById('ceilingHeightUnit').value;
        const temperatureDifferenceUnit = document.getElementById('temperatureDifferenceUnit').value;

        if (isNaN(roomWidth) || isNaN(roomLength) || isNaN(ceilingHeight) || isNaN(uValue) || isNaN(temperatureDifference)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert dimensions to meters
        const roomWidthInMeters = convertToMeters(roomWidth, roomWidthUnit);
        const roomLengthInMeters = convertToMeters(roomLength, roomLengthUnit);
        const ceilingHeightInMeters = convertToMeters(ceilingHeight, ceilingHeightUnit);

        // Calculate room volume in cubic meters
        const roomVolumeInCubicMeters = roomWidthInMeters * roomLengthInMeters * ceilingHeightInMeters;

        // Calculate heat loss in watts
        const heatLoss = roomVolumeInCubicMeters * uValue * temperatureDifference;

        const resultText = `Estimated Heat Loss: ${heatLoss.toFixed(2)} Watts`;
        const explanationText = `
             <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The estimated heat loss is based on the room dimensions, overall U-value, and temperature difference.</p>
            <p>Room Volume: ${roomVolumeInCubicMeters.toFixed(2)} cubic meters</p>
            <p>Overall U-Value: ${uValue} W/m²K</p>
            <p>Temperature Difference: ${temperatureDifference} ${temperatureDifferenceUnit}</p>
            <p>Estimated Heat Loss: ${heatLoss.toFixed(2)} Watts</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToMeters(value, unit) {
        switch (unit) {
            case 'feet':
                return value * 0.3048; // 1 foot = 0.3048 meters
            case 'inches':
                return value * 0.0254; // 1 inch = 0.0254 meters
            case 'centimeters':
                return value * 0.01; // 1 centimeter = 0.01 meters
            case 'meters':
                return value;
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('heat_loss_calculator', 'heat_loss_calculator_shortcode');


function deck_stain_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Deck Stain Calculator</h1>
            <form id="deckStainCalculatorForm">
                <div class="form-group">
                    <label for="deckLength">Deck Length:</label>
                    <input type="number" id="deckLength" class="form-input" required>
                    <select id="deckLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="deckWidth">Deck Width:</label>
                    <input type="number" id="deckWidth" class="form-input" required>
                    <select id="deckWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="stainCoverage">Stain Coverage (sq.ft/Liter):</label>
                    <input type="number" id="stainCoverage" class="form-input" step="0.01" required>
                </div>
                <button type="button" onclick="calculateDeckStain()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateDeckStain() {
        const deckLength = parseFloat(document.getElementById('deckLength').value);
        const deckWidth = parseFloat(document.getElementById('deckWidth').value);
        const stainCoverage = parseFloat(document.getElementById('stainCoverage').value);

        const deckLengthUnit = document.getElementById('deckLengthUnit').value;
        const deckWidthUnit = document.getElementById('deckWidthUnit').value;

        if (isNaN(deckLength) || isNaN(deckWidth) || isNaN(stainCoverage)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert dimensions to square feet
        const deckAreaInSquareFeet = convertToSquareFeet(deckLength, deckWidth, deckLengthUnit, deckWidthUnit);

        // Calculate amount of stain needed in liters
        const litersOfStainNeeded = deckAreaInSquareFeet / stainCoverage;

        const resultText = `Stain Needed: ${litersOfStainNeeded.toFixed(2)} Liters`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The amount of stain required is based on the deck dimensions and stain coverage per liter.</p>
            <p>Deck Area: ${deckAreaInSquareFeet.toFixed(2)} square feet</p>
            <p>Stain Coverage: ${stainCoverage.toFixed(2)} sq.ft/Liter</p>
            <p>Stain Needed: ${litersOfStainNeeded.toFixed(2)} Liters</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(length, width, lengthUnit, widthUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        return lengthInFeet * widthInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 inch = 1/12 feet
            case 'centimeters':
                return value / 30.48; // 1 centimeter = 1/30.48 feet
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('deck_stain_calculator', 'deck_stain_calculator_shortcode');

function siding_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Siding Calculator</h1>
            <form id="sidingCalculatorForm">
                <div class="form-group">
                    <label for="wallLength">Wall Length:</label>
                    <input type="number" id="wallLength" class="form-input" required>
                    <select id="wallLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallHeight">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="sidingCoverage">Siding Coverage (sq.ft/piece):</label>
                    <input type="number" id="sidingCoverage" class="form-input" step="0.01" required>
                </div>
                <button type="button" onclick="calculateSiding()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateSiding() {
        const wallLength = parseFloat(document.getElementById('wallLength').value);
        const wallHeight = parseFloat(document.getElementById('wallHeight').value);
        const sidingCoverage = parseFloat(document.getElementById('sidingCoverage').value);

        const wallLengthUnit = document.getElementById('wallLengthUnit').value;
        const wallHeightUnit = document.getElementById('wallHeightUnit').value;

        if (isNaN(wallLength) || isNaN(wallHeight) || isNaN(sidingCoverage)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert dimensions to square feet
        const wallAreaInSquareFeet = convertToSquareFeet(wallLength, wallHeight, wallLengthUnit, wallHeightUnit);

        // Calculate number of siding pieces needed
        const numberOfSidingPieces = wallAreaInSquareFeet / sidingCoverage;

        const resultText = `Siding Pieces Needed: ${numberOfSidingPieces.toFixed(2)}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The number of siding pieces required is based on the wall dimensions and siding coverage per piece.</p>
            <p>Wall Area: ${wallAreaInSquareFeet.toFixed(2)} square feet</p>
            <p>Siding Coverage: ${sidingCoverage.toFixed(2)} sq.ft/piece</p>
            <p>Siding Pieces Needed: ${numberOfSidingPieces.toFixed(2)}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(length, height, lengthUnit, heightUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const heightInFeet = convertToFeet(height, heightUnit);
        return lengthInFeet * heightInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 inch = 1/12 feet
            case 'centimeters':
                return value / 30.48; // 1 centimeter = 1/30.48 feet
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('siding_calculator', 'siding_calculator_shortcode');

function furnace_size_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Furnace Size Calculator</h1>
            <form id="furnaceSizeCalculatorForm">
                <div class="form-group">
                    <label for="areaToHeat">Area to Heat:</label>
                    <input type="number" id="areaToHeat" class="form-input" required>
                    <select id="areaToHeatUnit" class="form-select">
                        <option value="square_feet">Square Feet</option>
                        <option value="square_meters">Square Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="insulationFactor">Insulation Factor:</label>
                    <select id="insulationFactor" class="form-select">
                        <option value="poor">Poor (little to no insulation)</option>
                        <option value="average">Average (some insulation)</option>
                        <option value="good">Good (well-insulated)</option>
                    </select>
                </div>
                <button type="button" onclick="calculateFurnaceSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateFurnaceSize() {
        const areaToHeat = parseFloat(document.getElementById('areaToHeat').value);
        const areaToHeatUnit = document.getElementById('areaToHeatUnit').value;
        const insulationFactor = document.getElementById('insulationFactor').value;

        if (isNaN(areaToHeat)) {
            alert('Please enter a valid number for the area to heat.');
            return;
        }

        // Convert area to square feet if necessary
        let areaInSquareFeet = areaToHeat;
        if (areaToHeatUnit === 'square_meters') {
            areaInSquareFeet = areaToHeat * 10.7639; // 1 square meter = 10.7639 square feet
        }

        // Determine heating factor based on insulation
        let heatingFactor = 25; // Default heating factor in BTU per square foot
        switch (insulationFactor) {
            case 'poor':
                heatingFactor = 35; // BTU per square foot for poor insulation
                break;
            case 'average':
                heatingFactor = 30; // BTU per square foot for average insulation
                break;
            case 'good':
                heatingFactor = 25; // BTU per square foot for good insulation
                break;
        }

        // Calculate furnace size in BTU
        const furnaceSizeInBTU = areaInSquareFeet * heatingFactor;

        // Convert BTU to tons (1 ton = 12000 BTU)
        const furnaceSizeInTons = furnaceSizeInBTU / 12000;

        const resultText = `Recommended Furnace Size: ${furnaceSizeInTons.toFixed(2)} Tons`;
        const explanationText = `
              <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The recommended furnace size is based on the area to be heated and the insulation factor selected.</p>
            <p>Area to Heat: ${areaToHeat} ${areaToHeatUnit}</p>
            <p>Insulation Factor: ${insulationFactor}</p>
            <p>Heating Factor: ${heatingFactor} BTU per square foot</p>
            <p>Recommended Furnace Size: ${furnaceSizeInTons.toFixed(2)} Tons (${furnaceSizeInBTU} BTU)</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('furnace_size_calculator', 'furnace_size_calculator_shortcode');

function plywood_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Plywood Calculator</h1>
            <form id="plywoodCalculatorForm">
                <div class="form-group">
                    <label for="projectLength">Project Length:</label>
                    <input type="number" id="projectLength" class="form-input" required>
                    <select id="projectLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="projectWidth">Project Width:</label>
                    <input type="number" id="projectWidth" class="form-input" required>
                    <select id="projectWidthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="plywoodSize">Plywood Sheet Size:</label>
                    <select id="plywoodSize" class="form-select">
                        <option value="4x8">4 ft x 8 ft</option>
                        <option value="4x10">4 ft x 10 ft</option>
                        <option value="4x12">4 ft x 12 ft</option>
                        <option value="other">Custom Size</option>
                    </select>
                </div>
                <div id="customPlywoodSize" class="form-group" style="display: none;">
                    <label for="customPlywoodWidth">Custom Plywood Width:</label>
                    <input type="number" id="customPlywoodWidth" class="form-input">
                    <label for="customPlywoodLength">Custom Plywood Length:</label>
                    <input type="number" id="customPlywoodLength" class="form-input">
                </div>
                <button type="button" onclick="calculatePlywood()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculatePlywood() {
        const projectLength = parseFloat(document.getElementById('projectLength').value);
        const projectWidth = parseFloat(document.getElementById('projectWidth').value);
        const plywoodSize = document.getElementById('plywoodSize').value;
        let plywoodWidth, plywoodLength;

        if (plywoodSize === 'other') {
            plywoodWidth = parseFloat(document.getElementById('customPlywoodWidth').value);
            plywoodLength = parseFloat(document.getElementById('customPlywoodLength').value);

            if (isNaN(plywoodWidth) || isNaN(plywoodLength)) {
                alert('Please enter valid numbers for custom plywood size.');
                return;
            }
        } else {
            // Standard plywood sizes
            switch (plywoodSize) {
                case '4x8':
                    plywoodWidth = 4;
                    plywoodLength = 8;
                    break;
                case '4x10':
                    plywoodWidth = 4;
                    plywoodLength = 10;
                    break;
                case '4x12':
                    plywoodWidth = 4;
                    plywoodLength = 12;
                    break;
            }
        }

        const projectLengthUnit = document.getElementById('projectLengthUnit').value;
        const projectWidthUnit = document.getElementById('projectWidthUnit').value;

        if (isNaN(projectLength) || isNaN(projectWidth)) {
            alert('Please enter valid numbers for project dimensions.');
            return;
        }

        // Convert project dimensions to feet if necessary
        const projectAreaInSquareFeet = convertToSquareFeet(projectLength, projectWidth, projectLengthUnit, projectWidthUnit);

        // Calculate number of plywood sheets needed
        const plywoodArea = plywoodWidth * plywoodLength;
        const numberOfSheets = Math.ceil(projectAreaInSquareFeet / plywoodArea);

        const resultText = `Plywood Sheets Needed: ${numberOfSheets}`;
        const explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The number of plywood sheets required is based on the project dimensions and selected plywood sheet size.</p>
            <p>Project Area: ${projectAreaInSquareFeet.toFixed(2)} square feet</p>
            <p>Plywood Sheet Size: ${plywoodWidth} ft x ${plywoodLength} ft</p>
            <p>Plywood Sheets Needed: ${numberOfSheets}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(length, width, lengthUnit, widthUnit) {
        const lengthInFeet = convertToFeet(length, lengthUnit);
        const widthInFeet = convertToFeet(width, widthUnit);
        return lengthInFeet * widthInFeet;
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 inch = 1/12 feet
            case 'centimeters':
                return value / 30.48; // 1 centimeter = 1/30.48 feet
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return 0;
        }
    }

    document.getElementById('plywoodSize').addEventListener('change', function() {
        const customPlywoodSize = document.getElementById('customPlywoodSize');
        if (this.value === 'other') {
            customPlywoodSize.style.display = 'block';
        } else {
            customPlywoodSize.style.display = 'none';
        }
    });
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('plywood_calculator', 'plywood_calculator_shortcode');

function stair_carpet_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Stair Carpet Calculator</h1>
            <form id="stairCarpetCalculatorForm">
                <div class="form-group">
                    <label for="totalSteps">Number of Steps:</label>
                    <input type="number" id="totalSteps" class="form-input" required>
                </div>
                <div class="form-group">
                    <label for="stepWidth">Step Width:</label>
                    <input type="number" id="stepWidth" class="form-input" required>
                    <select id="stepWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="stepDepth">Step Depth:</label>
                    <input type="number" id="stepDepth" class="form-input" required>
                    <select id="stepDepthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="carpetWidth">Carpet Roll Width:</label>
                    <input type="number" id="carpetWidth" class="form-input" required>
                    <select id="carpetWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="carpetLength">Carpet Roll Length:</label>
                    <input type="number" id="carpetLength" class="form-input" required>
                    <select id="carpetLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="yards">Yards</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateStairCarpet()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateStairCarpet() {
        const totalSteps = parseInt(document.getElementById('totalSteps').value);
        const stepWidth = parseFloat(document.getElementById('stepWidth').value);
        const stepWidthUnit = document.getElementById('stepWidthUnit').value;
        const stepDepth = parseFloat(document.getElementById('stepDepth').value);
        const stepDepthUnit = document.getElementById('stepDepthUnit').value;
        const carpetWidth = parseFloat(document.getElementById('carpetWidth').value);
        const carpetWidthUnit = document.getElementById('carpetWidthUnit').value;
        const carpetLength = parseFloat(document.getElementById('carpetLength').value);
        const carpetLengthUnit = document.getElementById('carpetLengthUnit').value;

        if (isNaN(totalSteps) || isNaN(stepWidth) || isNaN(stepDepth) || isNaN(carpetWidth) || isNaN(carpetLength)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert step dimensions to inches
        const stepWidthInInches = convertToInches(stepWidth, stepWidthUnit);
        const stepDepthInInches = convertToInches(stepDepth, stepDepthUnit);

        // Calculate total area to be covered by carpet
        const totalAreaInSquareInches = totalSteps * stepWidthInInches * stepDepthInInches;

        // Convert carpet dimensions to square inches
        const carpetWidthInInches = convertToInches(carpetWidth, carpetWidthUnit);
        const carpetLengthInInches = convertToInches(carpetLength, carpetLengthUnit);

        // Calculate area of one carpet roll in square inches
        const carpetAreaInSquareInches = carpetWidthInInches * carpetLengthInInches;

        // Calculate number of carpet rolls needed
        const numberOfCarpetRolls = Math.ceil(totalAreaInSquareInches / carpetAreaInSquareInches);

        const resultText = `Carpet Rolls Needed: ${numberOfCarpetRolls}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The number of carpet rolls required is based on the dimensions of each step and the selected carpet roll size.</p>
            <p>Total Steps: ${totalSteps}</p>
            <p>Step Width: ${stepWidth} ${stepWidthUnit}</p>
            <p>Step Depth: ${stepDepth} ${stepDepthUnit}</p>
            <p>Carpet Roll Size: ${carpetWidth} ${carpetWidthUnit} x ${carpetLength} ${carpetLengthUnit}</p>
            <p>Carpet Rolls Needed: ${numberOfCarpetRolls}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('stair_carpet_calculator', 'stair_carpet_calculator_shortcode');


function wainscoting_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Wainscoting Calculator</h1>
            <form id="wainscotingCalculatorForm">
                <div class="form-group">
                    <label for="wallLength">Wall Length:</label>
                    <input type="number" id="wallLength" class="form-input" required>
                    <select id="wallLengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wallHeight">Wall Height:</label>
                    <input type="number" id="wallHeight" class="form-input" required>
                    <select id="wallHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="panelWidth">Panel Width:</label>
                    <input type="number" id="panelWidth" class="form-input" required>
                    <select id="panelWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="panelHeight">Panel Height:</label>
                    <input type="number" id="panelHeight" class="form-input" required>
                    <select id="panelHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateWainscoting()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateWainscoting() {
        const wallLength = parseFloat(document.getElementById('wallLength').value);
        const wallLengthUnit = document.getElementById('wallLengthUnit').value;
        const wallHeight = parseFloat(document.getElementById('wallHeight').value);
        const wallHeightUnit = document.getElementById('wallHeightUnit').value;
        const panelWidth = parseFloat(document.getElementById('panelWidth').value);
        const panelWidthUnit = document.getElementById('panelWidthUnit').value;
        const panelHeight = parseFloat(document.getElementById('panelHeight').value);
        const panelHeightUnit = document.getElementById('panelHeightUnit').value;

        if (isNaN(wallLength) || isNaN(wallHeight) || isNaN(panelWidth) || isNaN(panelHeight)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert wall dimensions to inches
        const wallLengthInInches = convertToInches(wallLength, wallLengthUnit);
        const wallHeightInInches = convertToInches(wallHeight, wallHeightUnit);

        // Convert panel dimensions to square inches
        const panelWidthInInches = convertToInches(panelWidth, panelWidthUnit);
        const panelHeightInInches = convertToInches(panelHeight, panelHeightUnit);

        // Calculate total area of the wall to be covered
        const totalAreaInSquareInches = wallLengthInInches * wallHeightInInches;

        // Calculate area of one panel in square inches
        const panelAreaInSquareInches = panelWidthInInches * panelHeightInInches;

        // Calculate number of panels needed
        const numberOfPanels = Math.ceil(totalAreaInSquareInches / panelAreaInSquareInches);

        const resultText = `Panels Needed: ${numberOfPanels}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The number of panels required is based on the dimensions of the wall and the selected panel size.</p>
            <p>Wall Length: ${wallLength} ${wallLengthUnit}</p>
            <p>Wall Height: ${wallHeight} ${wallHeightUnit}</p>
            <p>Panel Size: ${panelWidth} ${panelWidthUnit} x ${panelHeight} ${panelHeightUnit}</p>
            <p>Panels Needed: ${numberOfPanels}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('wainscoting_calculator', 'wainscoting_calculator_shortcode');


function fire_glass_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Fire Glass Calculator</h1>
            <form id="fireGlassCalculatorForm">
                <div class="form-group">
                    <label for="shape">Select Shape:</label>
                    <select id="shape" class="form-select" onchange="toggleShapeInputs()">
                        <option value="rectangular">Rectangular</option>
                        <option value="circular">Circular</option>
                    </select>
                </div>
                <div id="rectangularInputs">
                    <div class="form-group">
                        <label for="length">Length:</label>
                        <input type="number" id="length" class="form-input" required>
                        <select id="lengthUnit" class="form-select">
                            <option value="feet">Feet</option>
                            <option value="inches">Inches</option>
                            <option value="meters">Meters</option>
                            <option value="centimeters">Centimeters</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="width">Width:</label>
                        <input type="number" id="width" class="form-input" required>
                        <select id="widthUnit" class="form-select">
                            <option value="feet">Feet</option>
                            <option value="inches">Inches</option>
                            <option value="meters">Meters</option>
                            <option value="centimeters">Centimeters</option>
                        </select>
                    </div>
                </div>
                <div id="circularInputs" style="display: none;">
                    <div class="form-group">
                        <label for="diameter">Diameter:</label>
                        <input type="number" id="diameter" class="form-input">
                        <select id="diameterUnit" class="form-select">
                            <option value="feet">Feet</option>
                            <option value="inches">Inches</option>
                            <option value="meters">Meters</option>
                            <option value="centimeters">Centimeters</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="depth">Depth:</label>
                    <input type="number" id="depth" class="form-input" required>
                    <select id="depthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateFireGlass()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

  
     <script>
    function toggleShapeInputs() {
        const shape = document.getElementById('shape').value;
        if (shape === 'rectangular') {
            document.getElementById('rectangularInputs').style.display = 'block';
            document.getElementById('circularInputs').style.display = 'none';
        } else if (shape === 'circular') {
            document.getElementById('rectangularInputs').style.display = 'none';
            document.getElementById('circularInputs').style.display = 'block';
        }
    }

    function calculateFireGlass() {
        const shape = document.getElementById('shape').value;
        let area, length, width, diameter;

        if (shape === 'rectangular') {
            length = parseFloat(document.getElementById('length').value);
            const lengthUnit = document.getElementById('lengthUnit').value;
            width = parseFloat(document.getElementById('width').value);
            const widthUnit = document.getElementById('widthUnit').value;

            if (isNaN(length) || isNaN(width)) {
                alert('Please enter valid numbers for length and width.');
                return;
            }

            const lengthInInches = convertToInches(length, lengthUnit);
            const widthInInches = convertToInches(width, widthUnit);

            area = lengthInInches * widthInInches;

        } else if (shape === 'circular') {
            diameter = parseFloat(document.getElementById('diameter').value);
            const diameterUnit = document.getElementById('diameterUnit').value;

            if (isNaN(diameter)) {
                alert('Please enter a valid number for diameter.');
                return;
            }

            const diameterInInches = convertToInches(diameter, diameterUnit);
            const radiusInInches = diameterInInches / 2;

            area = Math.PI * Math.pow(radiusInInches, 2);
        }

        const depth = parseFloat(document.getElementById('depth').value);
        const depthUnit = document.getElementById('depthUnit').value;

        if (isNaN(depth)) {
            alert('Please enter a valid number for depth.');
            return;
        }

        const depthInInches = convertToInches(depth, depthUnit);

        const volumeInCubicInches = area * depthInInches;
        const volumeInCubicFeet = volumeInCubicInches / 1728; // 1 cubic foot = 1728 cubic inches

        let resultText = `You will need approximately ${volumeInCubicFeet.toFixed(2)} cubic feet of fire glass.`;
        let explanationText = `
           <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Shape: ${shape.charAt(0).toUpperCase() + shape.slice(1)}</p>
            <p>Depth: ${depth} ${depthUnit}</p>
        `;

        if (shape === 'rectangular') {
            explanationText += `<p>Length: ${length} ${document.getElementById('lengthUnit').options[document.getElementById('lengthUnit').selectedIndex].text}</p>`;
            explanationText += `<p>Width: ${width} ${document.getElementById('widthUnit').options[document.getElementById('widthUnit').selectedIndex].text}</p>`;
        } else if (shape === 'circular') {
            explanationText += `<p>Diameter: ${diameter} ${document.getElementById('diameterUnit').options[document.getElementById('diameterUnit').selectedIndex].text}</p>`;
        }

        explanationText += `
            <p>Area in square inches: ${area.toFixed(2)}</p>
            <p>Volume in cubic inches: ${volumeInCubicInches.toFixed(2)}</p>
            <p>Volume in cubic feet: ${volumeInCubicFeet.toFixed(2)}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('result').style.display = 'block';
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('fire_glass_calculator', 'fire_glass_calculator_shortcode');

// Calculators Creaetd 07-07-2024

function barn_roof_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Barn Roof Calculator</h1>
            <form id="barnRoofCalculatorForm">
                <div class="form-group">
                    <label for="length">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Square Feet</option>
                        <option value="inches">Square Inches</option>
                        <option value="meters">Square Meters</option>
                        <option value="centimeters">Square Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateBarnRoof()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateBarnRoof() {
        const length = parseFloat(document.getElementById('length').value);
        const lengthUnit = document.getElementById('lengthUnit').value;
        const width = parseFloat(document.getElementById('width').value);
        const widthUnit = document.getElementById('widthUnit').value;
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(length) || isNaN(width)) {
            alert('Please enter valid numbers for length and width.');
            return;
        }

        const lengthInInches = convertToInches(length, lengthUnit);
        const widthInInches = convertToInches(width, widthUnit);

        // Example calculation:
        const roofAreaInSquareInches = calculateRoofArea(lengthInInches, widthInInches);
        const roofAreaInSquareFeet = roofAreaInSquareInches / 144;
        const roofAreaInSquareMeters = roofAreaInSquareInches * 0.00064516;
        const roofAreaInSquareCentimeters = roofAreaInSquareInches * 6.4516;

        let roofArea, unit;
        switch (resultUnit) {
            case 'feet':
                roofArea = roofAreaInSquareFeet;
                unit = 'square feet';
                break;
            case 'inches':
                roofArea = roofAreaInSquareInches;
                unit = 'square inches';
                break;
            case 'meters':
                roofArea = roofAreaInSquareMeters;
                unit = 'square meters';
                break;
            case 'centimeters':
                roofArea = roofAreaInSquareCentimeters;
                unit = 'square centimeters';
                break;
        }

        const resultText = `Your barn roof calculations result: ${roofArea.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>The barn roof area is calculated based on the provided length and width.</p>
            <p>Length: ${length} ${lengthUnit}</p>
            <p>Width: ${width} ${widthUnit}</p>
            <p>Converted Length: ${lengthInInches.toFixed(2)} inches</p>
            <p>Converted Width: ${widthInInches.toFixed(2)} inches</p>
            <p>Roof Area: ${roofArea.toFixed(2)} ${unit}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function calculateRoofArea(lengthInInches, widthInInches) {
        // Example calculation for roof area (customize based on actual formula)
        const area = lengthInInches * widthInInches;
        return area;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('barn_roof_calculator', 'barn_roof_calculator_shortcode');











function gambrel_rafter_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gambrel Rafter Calculator</h1>
            <form id="gambrelRafterCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGambrelRafter()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateGambrelRafter() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        let pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(span) || isNaN(pitch)) {
            alert('Please enter valid numbers for span and pitch.');
            return;
        }

        let spanInInches = convertToInches(span, spanUnit);

        if (pitchUnit === 'degrees') {
            // Convert degrees pitch to in/12 pitch
            pitch = degreesToPitch(pitch);
        }

        // Example calculation:
        const rafterLengthInInches = calculateRafterLength(spanInInches, pitch);
        const rafterLengthInFeet = rafterLengthInInches / 12;
        const rafterLengthInMeters = rafterLengthInInches * 0.0254;
        const rafterLengthInCentimeters = rafterLengthInInches * 2.54;

        let rafterLength, unit;
        switch (resultUnit) {
            case 'feet':
                rafterLength = rafterLengthInFeet;
                unit = 'feet';
                break;
            case 'inches':
                rafterLength = rafterLengthInInches;
                unit = 'inches';
                break;
            case 'meters':
                rafterLength = rafterLengthInMeters;
                unit = 'meters';
                break;
            case 'centimeters':
                rafterLength = rafterLengthInCentimeters;
                unit = 'centimeters';
                break;
        }

        const resultText = `Your gambrel rafter calculations result: ${rafterLength.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch.toFixed(2)} ${pitchUnit}</p>
            <p>Rafter Length: ${rafterLength.toFixed(2)} ${unit}</p>
        `;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('explanation').innerHTML = explanationText;
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function degreesToPitch(degrees) {
        // Convert degrees pitch to in/12 pitch (example conversion, adjust as needed)
        return Math.tan(degrees * (Math.PI / 180)) * 12;
    }

    function calculateRafterLength(spanInInches, pitch) {
        // Example calculation for rafter length (customize based on actual formula)
        const length = Math.sqrt(Math.pow(spanInInches / 2, 2) + Math.pow((spanInInches / 2) * pitch / 12, 2));
        return length;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('gambrel_rafter_calculator', 'gambrel_rafter_calculator_shortcode');


function gambrel_shingles_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gambrel Roof Shingles Calculator</h1>
            <form id="gambrelShinglesCalculatorForm">
                <div class="form-group">
                    <label for="length">Length:</label>
                    <input type="number" id="length" class="form-input" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width">Width:</label>
                    <input type="number" id="width" class="form-input" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Roof Pitch (in degrees):</label>
                    <input type="number" id="pitch" class="form-input" required>
                </div>
                <button type="button" onclick="calculateShingles()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateShingles() {
        const length = parseFloat(document.getElementById('length').value);
        const lengthUnit = document.getElementById('lengthUnit').value;
        const width = parseFloat(document.getElementById('width').value);
        const widthUnit = document.getElementById('widthUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);

        if (isNaN(length) || isNaN(width) || isNaN(pitch)) {
            alert('Please enter valid numbers for length, width, and roof pitch.');
            return;
        }

        // Convert dimensions to inches for calculation
        const lengthInInches = convertToInches(length, lengthUnit);
        const widthInInches = convertToInches(width, widthUnit);

        // Example calculation for shingles (customize based on requirements)
        const area = lengthInInches * widthInInches;
        const shinglesNeeded = calculateShinglesByArea(area, pitch);

        const resultText = `Shingles Needed: ${shinglesNeeded.toFixed(2)}`;

        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        // Prepare explanation text
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Length: ${length} ${lengthUnit}</p>
            <p>Width: ${width} ${widthUnit}</p>
            <p>Roof Pitch: ${pitch} degrees</p>
           
        `;
        
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateShinglesByArea(area, pitch) {
        // Example formula for shingles calculation based on area and roof pitch
        const shinglesPerSquareFoot = 3; // Adjust according to shingle specifications
        const pitchFactor = Math.tan((pitch * Math.PI) / 180); // Convert pitch to radians

        // Example calculation (customize based on roof shingle coverage and pitch)
        const shinglesNeeded = (area * pitchFactor) / shinglesPerSquareFoot;

        return shinglesNeeded;
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('gambrel_shingles_calculator', 'gambrel_shingles_calculator_shortcode');


function purlin_size_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Purlin Size Calculator</h1>
            <form id="purlinSizeCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofLoad">Roof Load:</label>
                    <input type="number" id="roofLoad" class="form-input" step="any" required>
                    <select id="roofLoadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg/Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="steel">Steel</option>
                        <option value="wood">Wood</option>
                        <option value="aluminum">Aluminum</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculatePurlinSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculatePurlinSize() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const roofLoad = parseFloat(document.getElementById('roofLoad').value);
        const roofLoadUnit = document.getElementById('roofLoadUnit').value;
        const material = document.getElementById('material').value;
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(span) || isNaN(roofLoad)) {
            alert('Please enter valid numbers for span and roof load.');
            return;
        }

        // Convert span and roof load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const roofLoadInPSF = convertToPSF(roofLoad, roofLoadUnit);

        // Calculate purlin size based on material properties
        let purlinSizeInInches;

        if (material === 'steel') {
            // Example calculation for steel purlins
            purlinSizeInInches = calculateSteelPurlinSize(spanInFeet, roofLoadInPSF);
        } else if (material === 'wood') {
            // Example calculation for wood purlins
            purlinSizeInInches = calculateWoodPurlinSize(spanInFeet, roofLoadInPSF);
        } else if (material === 'aluminum') {
            // Example calculation for aluminum purlins
            purlinSizeInInches = calculateAluminumPurlinSize(spanInFeet, roofLoadInPSF);
        }

        // Convert purlin size to selected unit
        let purlinSize, unit;
        switch (resultUnit) {
            case 'feet':
                purlinSize = purlinSizeInInches / 12;
                unit = 'feet';
                break;
            case 'inches':
                purlinSize = purlinSizeInInches;
                unit = 'inches';
                break;
            case 'meters':
                purlinSize = purlinSizeInInches * 0.0254;
                unit = 'meters';
                break;
            case 'centimeters':
                purlinSize = purlinSizeInInches * 2.54;
                unit = 'centimeters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Recommended Purlin Size: ${purlinSize.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Roof Load: ${roofLoad} ${roofLoadUnit}</p>
            <p>Material: ${material}</p>
            <p>Recommended Purlin Size: ${purlinSize.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function calculateSteelPurlinSize(spanInFeet, roofLoadInPSF) {
        // Example calculation for steel purlins
        // Replace with actual calculation logic based on engineering standards
        const purlinSize = 6 * 2.5; // Example: 6 inches x 2.5 inches
        return purlinSize;
    }

    function calculateWoodPurlinSize(spanInFeet, roofLoadInPSF) {
        // Example calculation for wood purlins
        // Replace with actual calculation logic based on engineering standards
        const purlinSize = 4 * 2; // Example: 4 inches x 2 inches
        return purlinSize;
    }

    function calculateAluminumPurlinSize(spanInFeet, roofLoadInPSF) {
        // Example calculation for aluminum purlins
        // Replace with actual calculation logic based on engineering standards
        const purlinSize = 8 * 3; // Example: 8 inches x 3 inches
        return purlinSize;
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert roof load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 0.2048; // 1 kg/m² ≈ 0.2048 psf
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('purlin_size_calculator', 'purlin_size_calculator_shortcode');

function gable_roof_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gable Roof Calculator</h1>
            <form id="gableRoofCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGableRoof()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateGableRoof() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        let pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(span) || isNaN(pitch)) {
            alert('Please enter valid numbers for span and pitch.');
            return;
        }

        let spanInInches = convertToInches(span, spanUnit);

        if (pitchUnit === 'degrees') {
            // Convert degrees pitch to in/12 pitch
            pitch = degreesToPitch(pitch);
        }

        // Calculate the rafter length
        const rafterLengthInInches = calculateRafterLength(spanInInches, pitch);

        // Convert rafter length to selected unit
        let rafterLength, unit;
        switch (resultUnit) {
            case 'feet':
                rafterLength = rafterLengthInInches / 12;
                unit = 'feet';
                break;
            case 'inches':
                rafterLength = rafterLengthInInches;
                unit = 'inches';
                break;
            case 'meters':
                rafterLength = rafterLengthInInches * 0.0254;
                unit = 'meters';
                break;
            case 'centimeters':
                rafterLength = rafterLengthInInches * 2.54;
                unit = 'centimeters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Required Rafter Length: ${rafterLength.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Rafter Length: ${rafterLength.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function degreesToPitch(degrees) {
        // Convert degrees pitch to in/12 pitch (example conversion, adjust as needed)
        return Math.tan(degrees * (Math.PI / 180)) * 12;
    }

    function calculateRafterLength(spanInInches, pitch) {
        // Example calculation for rafter length (customize based on actual formula)
        const rafterLength = Math.sqrt(Math.pow(spanInInches / 2, 2) + Math.pow(pitch, 2));
        return rafterLength;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('gable_roof_calculator', 'gable_roof_calculator_shortcode');


function rafter_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Rafter Calculator</h1>
            <form id="rafterCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="rise">Rise:</label>
                    <input type="number" id="rise" class="form-input" step="any" required>
                    <select id="riseUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRafter()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRafter() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const rise = parseFloat(document.getElementById('rise').value);
        const riseUnit = document.getElementById('riseUnit').value;
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(span) || isNaN(rise)) {
            alert('Please enter valid numbers for span and rise.');
            return;
        }

        let spanInInches = convertToInches(span, spanUnit);
        let riseInInches = convertToInches(rise, riseUnit);

        // Calculate the rafter length
        const rafterLengthInInches = calculateRafterLength(spanInInches, riseInInches);

        // Convert rafter length to selected unit
        let rafterLength, unit;
        switch (resultUnit) {
            case 'feet':
                rafterLength = rafterLengthInInches / 12;
                unit = 'feet';
                break;
            case 'inches':
                rafterLength = rafterLengthInInches;
                unit = 'inches';
                break;
            case 'meters':
                rafterLength = rafterLengthInInches * 0.0254;
                unit = 'meters';
                break;
            case 'centimeters':
                rafterLength = rafterLengthInInches * 2.54;
                unit = 'centimeters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Required Rafter Length: ${rafterLength.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Rise: ${rise} ${riseUnit}</p>
            <p>Rafter Length: ${rafterLength.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function calculateRafterLength(spanInInches, riseInInches) {
        // Use the Pythagorean theorem to calculate the length of the rafter
        const rafterLength = Math.sqrt(Math.pow(spanInInches / 2, 2) + Math.pow(riseInInches, 2));
        return rafterLength;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('rafter_calculator', 'rafter_calculator_shortcode');

function roof_waste_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Waste Calculator</h1>
            <form id="roofWasteCalculatorForm">
                <div class="form-group">
                    <label for="roofArea">Roof Area:</label>
                    <input type="number" id="roofArea" class="form-input" step="any" required>
                    <select id="roofAreaUnit" class="form-select">
                        <option value="squareFeet">Square Feet</option>
                        <option value="squareMeters">Square Meters</option>
                        <option value="squareInches">Square Inches</option>
                        <option value="squareCentimeters">Square Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="wastePercentage">Waste Percentage:</label>
                    <input type="number" id="wastePercentage" class="form-input" step="any" required>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="squareFeet">Square Feet</option>
                        <option value="squareMeters">Square Meters</option>
                        <option value="squareInches">Square Inches</option>
                        <option value="squareCentimeters">Square Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofWaste()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofWaste() {
        const roofArea = parseFloat(document.getElementById('roofArea').value);
        const roofAreaUnit = document.getElementById('roofAreaUnit').value;
        const wastePercentage = parseFloat(document.getElementById('wastePercentage').value);
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(roofArea) || isNaN(wastePercentage)) {
            alert('Please enter valid numbers for roof area and waste percentage.');
            return;
        }

        let roofAreaInSquareFeet = convertToSquareFeet(roofArea, roofAreaUnit);
        const wasteFactor = (100 + wastePercentage) / 100;
        let totalRoofAreaInSquareFeet = roofAreaInSquareFeet * wasteFactor;

        // Convert total roof area to the selected unit
        let totalRoofArea, unit;
        switch (resultUnit) {
            case 'squareFeet':
                totalRoofArea = totalRoofAreaInSquareFeet;
                unit = 'square feet';
                break;
            case 'squareMeters':
                totalRoofArea = totalRoofAreaInSquareFeet * 0.092903;
                unit = 'square meters';
                break;
            case 'squareInches':
                totalRoofArea = totalRoofAreaInSquareFeet * 144;
                unit = 'square inches';
                break;
            case 'squareCentimeters':
                totalRoofArea = totalRoofAreaInSquareFeet * 929.0304;
                unit = 'square centimeters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Total Roof Area Including Waste: ${totalRoofArea.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Roof Area: ${roofArea} ${roofAreaUnit}</p>
            <p>Waste Percentage: ${wastePercentage}%</p>
            <p>Total Roof Area Including Waste: ${totalRoofArea.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(value, unit) {
        switch (unit) {
            case 'squareFeet':
                return value;
            case 'squareMeters':
                return value * 10.7639; // 1 square meter = 10.7639 square feet
            case 'squareInches':
                return value / 144; // 1 square foot = 144 square inches
            case 'squareCentimeters':
                return value / 929.0304; // 1 square foot = 929.0304 square centimeters
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_waste_calculator', 'roof_waste_calculator_shortcode');


function roof_surface_area_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Surface Area Calculator</h1>
            <form id="roofSurfaceAreaCalculatorForm">
                <div class="form-group">
                    <label for="length">Length:</label>
                    <input type="number" id="length" class="form-input" step="any" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width">Width:</label>
                    <input type="number" id="width" class="form-input" step="any" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Roof Pitch (in degrees):</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="squareFeet">Square Feet</option>
                        <option value="squareMeters">Square Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofSurfaceArea()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofSurfaceArea() {
        const length = parseFloat(document.getElementById('length').value);
        const lengthUnit = document.getElementById('lengthUnit').value;
        const width = parseFloat(document.getElementById('width').value);
        const widthUnit = document.getElementById('widthUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(length) || isNaN(width) || isNaN(pitch)) {
            alert('Please enter valid numbers for length, width, and pitch.');
            return;
        }

        let lengthInFeet = convertToFeet(length, lengthUnit);
        let widthInFeet = convertToFeet(width, widthUnit);

        let roofSurfaceAreaInSquareFeet = calculateSurfaceArea(lengthInFeet, widthInFeet, pitch);

        // Convert total roof area to the selected unit
        let totalRoofArea, unit;
        switch (resultUnit) {
            case 'squareFeet':
                totalRoofArea = roofSurfaceAreaInSquareFeet;
                unit = 'square feet';
                break;
            case 'squareMeters':
                totalRoofArea = roofSurfaceAreaInSquareFeet * 0.092903;
                unit = 'square meters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Total Roof Surface Area: ${totalRoofArea.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Length: ${length} ${lengthUnit}</p>
            <p>Width: ${width} ${widthUnit}</p>
            <p>Pitch: ${pitch} degrees</p>
            <p>Total Roof Surface Area: ${totalRoofArea.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return 0;
        }
    }

    function calculateSurfaceArea(length, width, pitch) {
        const pitchFactor = Math.sqrt(1 + Math.pow(Math.tan(pitch * (Math.PI / 180)), 2));
        return length * width * pitchFactor;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_surface_area_calculator', 'roof_surface_area_calculator_shortcode');

function roof_run_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Run Calculator</h1>
            <form id="roofRunCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Roof Pitch (in degrees):</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                </div>
                <div class="form-group">
                    <label for="resultUnit">Result in:</label>
                    <select id="resultUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofRun()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofRun() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const resultUnit = document.getElementById('resultUnit').value;

        if (isNaN(span) || isNaN(pitch)) {
            alert('Please enter valid numbers for span and pitch.');
            return;
        }

        let spanInFeet = convertToFeet(span, spanUnit);
        let roofRunInFeet = calculateRun(spanInFeet, pitch);

        // Convert roof run to the selected unit
        let totalRoofRun, unit;
        switch (resultUnit) {
            case 'feet':
                totalRoofRun = roofRunInFeet;
                unit = 'feet';
                break;
            case 'meters':
                totalRoofRun = roofRunInFeet * 0.3048;
                unit = 'meters';
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Total Roof Run: ${totalRoofRun.toFixed(2)} ${unit}.`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} degrees</p>
            <p>Total Roof Run: ${totalRoofRun.toFixed(2)} ${unit}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        switch (unit) {
            case 'feet':
                return value;
            case 'meters':
                return value * 3.28084; // 1 meter = 3.28084 feet
            default:
                return 0;
        }
    }

    function calculateRun(span, pitch) {
        // Assume the roof run is half the span length and adjust for pitch
        return (span / 2) / Math.cos(pitch * (Math.PI / 180));
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_run_calculator', 'roof_run_calculator_shortcode');


function gambrel_roof_shingle_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Gambrel Roof Shingle Calculator</h1>
            <form id="gambrelRoofShingleCalculatorForm">
                <div class="form-group">
                    <label for="length">Length:</label>
                    <input type="number" id="length" class="form-input" step="any" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width">Width:</label>
                    <input type="number" id="width" class="form-input" step="any" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shingleLength">Shingle Length:</label>
                    <input type="number" id="shingleLength" class="form-input" step="any" required>
                    <select id="shingleLengthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="shingleWidth">Shingle Width:</label>
                    <input type="number" id="shingleWidth" class="form-input" step="any" required>
                    <select id="shingleWidthUnit" class="form-select">
                        <option value="inches">Inches</option>
                        <option value="feet">Feet</option>
                        <option value="centimeters">Centimeters</option>
                        <option value="meters">Meters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateGambrelRoofShingles()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateGambrelRoofShingles() {
        const length = parseFloat(document.getElementById('length').value);
        const lengthUnit = document.getElementById('lengthUnit').value;
        const width = parseFloat(document.getElementById('width').value);
        const widthUnit = document.getElementById('widthUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const shingleLength = parseFloat(document.getElementById('shingleLength').value);
        const shingleLengthUnit = document.getElementById('shingleLengthUnit').value;
        const shingleWidth = parseFloat(document.getElementById('shingleWidth').value);
        const shingleWidthUnit = document.getElementById('shingleWidthUnit').value;

        if (isNaN(length) || isNaN(width) || isNaN(pitch) || isNaN(shingleLength) || isNaN(shingleWidth)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Convert dimensions to inches for calculation
        const lengthInInches = convertToInches(length, lengthUnit);
        const widthInInches = convertToInches(width, widthUnit);
        const shingleLengthInInches = convertToInches(shingleLength, shingleLengthUnit);
        const shingleWidthInInches = convertToInches(shingleWidth, shingleWidthUnit);

        // Calculate roof area
        const roofArea = calculateRoofArea(lengthInInches, widthInInches, pitch);

        // Calculate number of shingles needed
        const shinglesNeeded = calculateShinglesNeeded(roofArea, shingleLengthInInches, shingleWidthInInches);

        // Display results
        const resultText = `Total Shingles Needed: ${shinglesNeeded}`;
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        // Prepare explanation text
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Roof Length: ${length} ${lengthUnit}</p>
            <p>Roof Width: ${width} ${widthUnit}</p>
            <p>Roof Pitch: ${pitch} ${pitchUnit}</p>
            <p>Shingle Length: ${shingleLength} ${shingleLengthUnit}</p>
            <p>Shingle Width: ${shingleWidth} ${shingleWidthUnit}</p>
            <p>Total Shingles Needed: ${shinglesNeeded}</p>
        `;
        
        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function calculateRoofArea(lengthInInches, widthInInches, pitch) {
        // Calculate roof area based on length, width, and pitch (customize based on actual formula)
        const roofArea = lengthInInches * widthInInches * (1 + (pitch / 12));
        return roofArea;
    }

    function calculateShinglesNeeded(roofArea, shingleLengthInInches, shingleWidthInInches) {
        // Calculate the number of shingles needed based on roof area and shingle dimensions
        const shinglesNeeded = Math.ceil(roofArea / (shingleLengthInInches * shingleWidthInInches));
        return shinglesNeeded;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('gambrel_roof_shingle_calculator', 'gambrel_roof_shingle_calculator_shortcode');


function roof_truss_material_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Truss Material Calculator</h1>
            <form id="roofTrussMaterialCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofLoad">Roof Load:</label>
                    <input type="number" id="roofLoad" class="form-input" step="any" required>
                    <select id="roofLoadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg /Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="wood">Wood</option>
                        <option value="steel">Steel</option>
                        <option value="aluminum">Aluminum</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofTrussMaterial()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofTrussMaterial() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const roofLoad = parseFloat(document.getElementById('roofLoad').value);
        const roofLoadUnit = document.getElementById('roofLoadUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(span) || isNaN(pitch) || isNaN(roofLoad)) {
            alert('Please enter valid numbers for span, pitch, and roof load.');
            return;
        }

        // Convert dimensions and load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const roofLoadInPSF = convertToPSF(roofLoad, roofLoadUnit);

        // Example calculation for truss material based on material selected
        let materialCalculation;

        if (material === 'wood') {
            // Example calculation for wood truss material
            materialCalculation = calculateWoodTrussMaterial(spanInFeet, pitch, roofLoadInPSF);
        } else if (material === 'steel') {
            // Example calculation for steel truss material
            materialCalculation = calculateSteelTrussMaterial(spanInFeet, pitch, roofLoadInPSF);
        } else if (material === 'aluminum') {
            // Example calculation for aluminum truss material
            materialCalculation = calculateAluminumTrussMaterial(spanInFeet, pitch, roofLoadInPSF);
        }

        // Display results
        const resultText = `Recommended Truss Material: ${materialCalculation}`;
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        // Prepare explanation text
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Roof Load: ${roofLoad} ${roofLoadUnit}</p>
            <p>Material: ${material}</p>
            <p>Recommended Truss Material: ${materialCalculation}</p>
        `;

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert roof load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 20.885; // 1 kg/m² ≈ 20.885 psf
            default:
                return 0;
        }
    }

    function calculateWoodTrussMaterial(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for wood truss material
        // Replace with actual calculation logic based on engineering standards
        const woodMaterial = '2x4 lumber';
        return woodMaterial;
    }

    function calculateSteelTrussMaterial(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for steel truss material
        // Replace with actual calculation logic based on engineering standards
        const steelMaterial = 'Steel beams';
        return steelMaterial;
    }

    function calculateAluminumTrussMaterial(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for aluminum truss material
        // Replace with actual calculation logic based on engineering standards
        const aluminumMaterial = 'Aluminum trusses';
        return aluminumMaterial;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_truss_material_calculator', 'roof_truss_material_calculator_shortcode');


function lumber_calculator_for_roof_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Lumber Calculator for Roof</h1>
            <form id="lumberCalculatorForRoofForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofLoad">Roof Load:</label>
                    <input type="number" id="roofLoad" class="form-input" step="any" required>
                    <select id="roofLoadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg /Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="2x4">2x4</option>
                        <option value="2x6">2x6</option>
                        <option value="2x8">2x8</option>
                        <option value="2x10">2x10</option>
                        <option value="2x12">2x12</option>
                    </select>
                </div>
                <button type="button" onclick="calculateLumberForRoof()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateLumberForRoof() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const roofLoad = parseFloat(document.getElementById('roofLoad').value);
        const roofLoadUnit = document.getElementById('roofLoadUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(span) || isNaN(pitch) || isNaN(roofLoad)) {
            alert('Please enter valid numbers for span, pitch, and roof load.');
            return;
        }

        // Convert dimensions and load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const roofLoadInPSF = convertToPSF(roofLoad, roofLoadUnit);

        // Example calculation for lumber based on material selected
        const lumberSize = calculateLumberSize(spanInFeet, pitch, roofLoadInPSF, material);

        // Display results
        const resultText = `Recommended Lumber Size: ${lumberSize}`;
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        // Prepare explanation text
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Roof Load: ${roofLoad} ${roofLoadUnit}</p>
            <p>Material: ${material}</p>
            <p>Recommended Lumber Size: ${lumberSize}</p>
        `;

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert roof load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 20.885; // 1 kg/m² ≈ 20.885 psf
            default:
                return 0;
        }
    }

    function calculateLumberSize(spanInFeet, pitch, roofLoadInPSF, material) {
        // Example calculation for lumber size based on material
        // Replace with actual calculation logic based on engineering standards
        let lumberSize;

        // Example calculations for each material type
        switch (material) {
            case '2x4':
                lumberSize = '2x4';
                break;
            case '2x6':
                lumberSize = '2x6';
                break;
            case '2x8':
                lumberSize = '2x8';
                break;
            case '2x10':
                lumberSize = '2x10';
                break;
            case '2x12':
                lumberSize = '2x12';
                break;
            default:
                lumberSize = 'Not determined';
        }

        return lumberSize;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('lumber_calculator_for_roof', 'lumber_calculator_for_roof_shortcode');


function attic_trusses_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Attic Trusses Calculator</h1>
            <form id="atticTrussesCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofLoad">Roof Load:</label>
                    <input type="number" id="roofLoad" class="form-input" step="any" required>
                    <select id="roofLoadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg /Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="atticHeight">Attic Height:</label>
                    <input type="number" id="atticHeight" class="form-input" step="any" required>
                    <select id="atticHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateAtticTrusses()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateAtticTrusses() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const roofLoad = parseFloat(document.getElementById('roofLoad').value);
        const roofLoadUnit = document.getElementById('roofLoadUnit').value;
        const atticHeight = parseFloat(document.getElementById('atticHeight').value);
        const atticHeightUnit = document.getElementById('atticHeightUnit').value;

        if (isNaN(span) || isNaN(pitch) || isNaN(roofLoad) || isNaN(atticHeight)) {
            alert('Please enter valid numbers for span, pitch, roof load, and attic height.');
            return;
        }

        // Convert dimensions and load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const roofLoadInPSF = convertToPSF(roofLoad, roofLoadUnit);
        const atticHeightInFeet = convertToFeet(atticHeight, atticHeightUnit);

        // Example calculation for attic trusses based on parameters
        const trussDimensions = calculateAtticTrussDimensions(spanInFeet, pitch, roofLoadInPSF, atticHeightInFeet);

        // Display results
        const resultText = `Recommended Attic Truss Dimensions: ${trussDimensions}`;
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        // Prepare explanation text
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Roof Load: ${roofLoad} ${roofLoadUnit}</p>
            <p>Attic Height: ${atticHeight} ${atticHeightUnit}</p>
            <p>Recommended Attic Truss Dimensions: ${trussDimensions}</p>
        `;

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert roof load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 20.885; // 1 kg/m² ≈ 20.885 psf
            default:
                return 0;
        }
    }

    function calculateAtticTrussDimensions(spanInFeet, pitch, roofLoadInPSF, atticHeightInFeet) {
        // Example calculation for attic truss dimensions
        // Replace with actual calculation logic based on engineering standards
        let trussDimensions;

        // Example calculation based on parameters
        // Adjust calculations based on your specific requirements and standards
        trussDimensions = `Span: ${spanInFeet.toFixed(2)} feet, Pitch: ${pitch}, Roof Load: ${roofLoadInPSF.toFixed(2)} PSF, Attic Height: ${atticHeightInFeet.toFixed(2)} feet`;

        return trussDimensions;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('attic_trusses_calculator', 'attic_trusses_calculator_shortcode');

function trusses_cost_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Trusses Cost Calculator</h1>
            <form id="trussesCostCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="roofLoad">Roof Load:</label>
                    <input type="number" id="roofLoad" class="form-input" step="any" required>
                    <select id="roofLoadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg /Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="steel">Steel</option>
                        <option value="wood">Wood</option>
                        <option value="aluminum">Aluminum</option>
                    </select>
                </div>
                <button type="button" onclick="calculateTrussesCost()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateTrussesCost() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;
        const roofLoad = parseFloat(document.getElementById('roofLoad').value);
        const roofLoadUnit = document.getElementById('roofLoadUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(span) || isNaN(pitch) || isNaN(roofLoad)) {
            alert('Please enter valid numbers for span, pitch, and roof load.');
            return;
        }

        // Convert dimensions and load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const roofLoadInPSF = convertToPSF(roofLoad, roofLoadUnit);

        // Calculate truss cost based on material properties
        let trussCost;

        if (material === 'steel') {
            // Example calculation for steel trusses cost
            trussCost = calculateSteelTrussCost(spanInFeet, pitch, roofLoadInPSF);
        } else if (material === 'wood') {
            // Example calculation for wood trusses cost
            trussCost = calculateWoodTrussCost(spanInFeet, pitch, roofLoadInPSF);
        } else if (material === 'aluminum') {
            // Example calculation for aluminum trusses cost
            trussCost = calculateAluminumTrussCost(spanInFeet, pitch, roofLoadInPSF);
        }

        // Prepare result and explanation texts
        const resultText = `Estimated Trusses Cost (${material}): $${trussCost.toFixed(2)}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Roof Load: ${roofLoad} ${roofLoadUnit}</p>
            <p>Material: ${material}</p>
            <p>Estimated Trusses Cost: $${trussCost.toFixed(2)}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert roof load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 20.885; // 1 kg/m² ≈ 20.885 psf
            default:
                return 0;
        }
    }

    function calculateSteelTrussCost(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for steel trusses cost
        // Replace with actual calculation logic based on engineering standards and material costs
        // Example cost formula:
        const baseCostPerFoot = 10; // Example base cost per foot of truss
        const pitchFactor = 1.2; // Example factor based on pitch (adjust as per your calculation)
        const loadFactor = 1.5; // Example factor based on roof load (adjust as per your calculation)

        const trussCost = baseCostPerFoot * spanInFeet * pitchFactor * loadFactor;

        return trussCost;
    }

    function calculateWoodTrussCost(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for wood trusses cost
        // Replace with actual calculation logic based on engineering standards and material costs
        // Example cost formula:
        const baseCostPerFoot = 8; // Example base cost per foot of truss
        const pitchFactor = 1.1; // Example factor based on pitch (adjust as per your calculation)
        const loadFactor = 1.3; // Example factor based on roof load (adjust as per your calculation)

        const trussCost = baseCostPerFoot * spanInFeet * pitchFactor * loadFactor;

        return trussCost;
    }

    function calculateAluminumTrussCost(spanInFeet, pitch, roofLoadInPSF) {
        // Example calculation for aluminum trusses cost
        // Replace with actual calculation logic based on engineering standards and material costs
        // Example cost formula:
        const baseCostPerFoot = 12; // Example base cost per foot of truss
        const pitchFactor = 1.3; // Example factor based on pitch (adjust as per your calculation)
        const loadFactor = 1.7; // Example factor based on roof load (adjust as per your calculation)

        const trussCost = baseCostPerFoot * spanInFeet * pitchFactor * loadFactor;

        return trussCost;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('trusses_cost_calculator', 'trusses_cost_calculator_shortcode');


function roof_materials_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Materials Calculator</h1>
            <form id="roofMaterialsCalculatorForm">
                <div class="form-group">
                    <label for="roofArea">Roof Area:</label>
                    <input type="number" id="roofArea" class="form-input" step="any" required>
                    <select id="roofAreaUnit" class="form-select">
                        <option value="squareFeet">Square Feet</option>
                        <option value="squareMeters">Square Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="asphaltShingles">Asphalt Shingles</option>
                        <option value="metal">Metal Roofing</option>
                        <option value="tiles">Roof Tiles</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofMaterials()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofMaterials() {
        const roofArea = parseFloat(document.getElementById('roofArea').value);
        const roofAreaUnit = document.getElementById('roofAreaUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(roofArea)) {
            alert('Please enter a valid number for roof area.');
            return;
        }

        // Convert roof area to square feet for uniform calculation
        const roofAreaInSquareFeet = convertToSquareFeet(roofArea, roofAreaUnit);

        // Calculate materials based on selected material type
        let materialsNeeded, costEstimate;

        switch (material) {
            case 'asphaltShingles':
                materialsNeeded = calculateAsphaltShingles(roofAreaInSquareFeet);
                costEstimate = materialsNeeded * 25; // Example cost per square foot of asphalt shingles
                break;
            case 'metal':
                materialsNeeded = calculateMetalRoofing(roofAreaInSquareFeet);
                costEstimate = materialsNeeded * 40; // Example cost per square foot of metal roofing
                break;
            case 'tiles':
                materialsNeeded = calculateRoofTiles(roofAreaInSquareFeet);
                costEstimate = materialsNeeded * 50; // Example cost per square foot of roof tiles
                break;
            default:
                materialsNeeded = 0;
                costEstimate = 0;
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Materials Needed: ${materialsNeeded.toFixed(2)} units`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Roof Area: ${roofArea} ${roofAreaUnit}</p>
            <p>Material: ${material}</p>
            <p>Estimated Cost: $${costEstimate.toFixed(2)}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(value, unit) {
        // Convert roof area to square feet
        switch (unit) {
            case 'squareFeet':
                return value;
            case 'squareMeters':
                return value * 10.7639; // 1 square meter ≈ 10.7639 square feet
            default:
                return 0;
        }
    }

    function calculateAsphaltShingles(areaInSquareFeet) {
        // Example calculation for asphalt shingles: 3 bundles per 100 square feet
        const bundlesPer100Sqft = 3;
        return areaInSquareFeet / 100 * bundlesPer100Sqft;
    }

    function calculateMetalRoofing(areaInSquareFeet) {
        // Example calculation for metal roofing: 1 sheet per 50 square feet
        const sheetsPer50Sqft = 1;
        return areaInSquareFeet / 50 * sheetsPer50Sqft;
    }

    function calculateRoofTiles(areaInSquareFeet) {
        // Example calculation for roof tiles: 10 tiles per 100 square feet
        const tilesPer100Sqft = 10;
        return areaInSquareFeet / 100 * tilesPer100Sqft;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_materials_calculator', 'roof_materials_calculator_shortcode');

function roof_underlayment_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Underlayment Calculator</h1>
            <form id="roofUnderlaymentCalculatorForm">
                <div class="form-group">
                    <label for="roofArea">Roof Area:</label>
                    <input type="number" id="roofArea" class="form-input" step="any" required>
                    <select id="roofAreaUnit" class="form-select">
                        <option value="squareFeet">Square Feet</option>
                        <option value="squareMeters">Square Meters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="underlaymentType">Underlayment Type:</label>
                    <select id="underlaymentType" class="form-select">
                        <option value="felt">Felt Underlayment</option>
                        <option value="synthetic">Synthetic Underlayment</option>
                    </select>
                </div>
                <button type="button" onclick="calculateUnderlayment()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateUnderlayment() {
        const roofArea = parseFloat(document.getElementById('roofArea').value);
        const roofAreaUnit = document.getElementById('roofAreaUnit').value;
        const underlaymentType = document.getElementById('underlaymentType').value;

        if (isNaN(roofArea)) {
            alert('Please enter a valid number for roof area.');
            return;
        }

        // Convert roof area to square feet for uniform calculation
        const roofAreaInSquareFeet = convertToSquareFeet(roofArea, roofAreaUnit);

        // Calculate underlayment based on selected type
        let underlaymentNeeded, costEstimate;

        switch (underlaymentType) {
            case 'felt':
                underlaymentNeeded = calculateFeltUnderlayment(roofAreaInSquareFeet);
                costEstimate = underlaymentNeeded * 0.5; // Example cost per square foot of felt underlayment
                break;
            case 'synthetic':
                underlaymentNeeded = calculateSyntheticUnderlayment(roofAreaInSquareFeet);
                costEstimate = underlaymentNeeded * 0.8; // Example cost per square foot of synthetic underlayment
                break;
            default:
                underlaymentNeeded = 0;
                costEstimate = 0;
                break;
        }

        // Prepare result and explanation texts
        const resultText = `Underlayment Needed: ${underlaymentNeeded.toFixed(2)} rolls`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Roof Area: ${roofArea} ${roofAreaUnit}</p>
            <p>Underlayment Type: ${underlaymentType}</p>
            <p>Estimated Cost: $${costEstimate.toFixed(2)}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(value, unit) {
        // Convert roof area to square feet
        switch (unit) {
            case 'squareFeet':
                return value;
            case 'squareMeters':
                return value * 10.7639; // 1 square meter ≈ 10.7639 square feet
            default:
                return 0;
        }
    }

    function calculateFeltUnderlayment(areaInSquareFeet) {
        // Example calculation for felt underlayment: 2 rolls per 1000 square feet
        const rollsPer1000Sqft = 2;
        return areaInSquareFeet / 1000 * rollsPer1000Sqft;
    }

    function calculateSyntheticUnderlayment(areaInSquareFeet) {
        // Example calculation for synthetic underlayment: 1.5 rolls per 1000 square feet
        const rollsPer1000Sqft = 1.5;
        return areaInSquareFeet / 1000 * rollsPer1000Sqft;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_underlayment_calculator', 'roof_underlayment_calculator_shortcode');


function roofing_joist_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roofing Joist Calculator</h1>
            <form id="roofingJoistCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="load">Load:</label>
                    <input type="number" id="load" class="form-input" step="any" required>
                    <select id="loadUnit" class="form-select">
                        <option value="psf">PSF (Pounds/Sqft)</option>
                        <option value="kgsm">kg/m² (Kg /Sqm)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="wood">Wood</option>
                        <option value="steel">Steel</option>
                        <option value="aluminum">Aluminum</option>
                    </select>
                </div>
                <button type="button" onclick="calculateJoistSize()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateJoistSize() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        const load = parseFloat(document.getElementById('load').value);
        const loadUnit = document.getElementById('loadUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(span) || isNaN(load)) {
            alert('Please enter valid numbers for span and load.');
            return;
        }

        // Convert span and load to consistent units for calculation
        const spanInFeet = convertToFeet(span, spanUnit);
        const loadInPSF = convertToPSF(load, loadUnit);

        // Calculate joist size based on material properties
        let joistSize;

        if (material === 'wood') {
            // Example calculation for wood joists
            joistSize = calculateWoodJoistSize(spanInFeet, loadInPSF);
        } else if (material === 'steel') {
            // Example calculation for steel joists
            joistSize = calculateSteelJoistSize(spanInFeet, loadInPSF);
        } else if (material === 'aluminum') {
            // Example calculation for aluminum joists
            joistSize = calculateAluminumJoistSize(spanInFeet, loadInPSF);
        }

        // Prepare result and explanation texts
        const resultText = `Recommended Joist Size: ${joistSize}`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Load: ${load} ${loadUnit}</p>
            <p>Material: ${material}</p>
            <p>Recommended Joist Size: ${joistSize}</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToFeet(value, unit) {
        // Convert dimensions to feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 30.48; // 1 foot = 30.48 centimeters
            case 'meters':
                return value / 0.3048; // 1 foot = 0.3048 meters
            default:
                return 0;
        }
    }

    function convertToPSF(value, unit) {
        // Convert load to pounds per square foot (PSF)
        switch (unit) {
            case 'psf':
                return value;
            case 'kgsm':
                return value * 20.885; // 1 kg/m² ≈ 20.885 psf
            default:
                return 0;
        }
    }

    function calculateWoodJoistSize(spanInFeet, loadInPSF) {
        // Example calculation for wood joists
        // Replace with actual calculation logic based on engineering standards
        const joistSize = '2x8 inches';
        return joistSize;
    }

    function calculateSteelJoistSize(spanInFeet, loadInPSF) {
        // Example calculation for steel joists
        // Replace with actual calculation logic based on engineering standards
        const joistSize = 'W8x18';
        return joistSize;
    }

    function calculateAluminumJoistSize(spanInFeet, loadInPSF) {
        // Example calculation for aluminum joists
        // Replace with actual calculation logic based on engineering standards
        const joistSize = '6x2 inches';
        return joistSize;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roofing_joist_calculator', 'roofing_joist_calculator_shortcode');



function roof_weight_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Weight Calculator</h1>
            <form id="roofWeightCalculatorForm">
                <div class="form-group">
                    <label for="length">Length:</label>
                    <input type="number" id="length" class="form-input" step="any" required>
                    <select id="lengthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="width">Width:</label>
                    <input type="number" id="width" class="form-input" step="any" required>
                    <select id="widthUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="material">Material:</label>
                    <select id="material" class="form-select">
                        <option value="asphalt_shingles">Asphalt Shingles</option>
                        <option value="metal_sheet">Metal Sheet</option>
                        <option value="concrete_tiles">Concrete Tiles</option>
                        <option value="clay_tiles">Clay Tiles</option>
                        <option value="wood_shakes">Wood Shakes</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofWeight()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofWeight() {
        const length = parseFloat(document.getElementById('length').value);
        const lengthUnit = document.getElementById('lengthUnit').value;
        const width = parseFloat(document.getElementById('width').value);
        const widthUnit = document.getElementById('widthUnit').value;
        const material = document.getElementById('material').value;

        if (isNaN(length) || isNaN(width)) {
            alert('Please enter valid numbers for length and width.');
            return;
        }

        // Convert length and width to consistent units for calculation
        const area = convertToSquareFeet(length, lengthUnit) * convertToSquareFeet(width, widthUnit);

        // Calculate roof weight based on material properties
        let weightPerSquareFoot;

        switch (material) {
            case 'asphalt_shingles':
                weightPerSquareFoot = 2.85; // Example weight for asphalt shingles (lbs/ft²)
                break;
            case 'metal_sheet':
                weightPerSquareFoot = 1.5; // Example weight for metal sheet roofing (lbs/ft²)
                break;
            case 'concrete_tiles':
                weightPerSquareFoot = 10; // Example weight for concrete tiles (lbs/ft²)
                break;
            case 'clay_tiles':
                weightPerSquareFoot = 9; // Example weight for clay tiles (lbs/ft²)
                break;
            case 'wood_shakes':
                weightPerSquareFoot = 3.5; // Example weight for wood shakes (lbs/ft²)
                break;
            default:
                weightPerSquareFoot = 0; // Default value if material not recognized
                break;
        }

        if (weightPerSquareFoot === 0) {
            alert('Please select a valid roofing material.');
            return;
        }

        const totalWeight = area * weightPerSquareFoot;

        // Prepare result and explanation texts
        const resultText = `Estimated Roof Weight: ${totalWeight.toFixed(2)} lbs`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Length: ${length} ${lengthUnit}</p>
            <p>Width: ${width} ${widthUnit}</p>
            <p>Material: ${material}</p>
            <p>Estimated Roof Weight: ${totalWeight.toFixed(2)} lbs</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToSquareFeet(value, unit) {
        // Convert dimensions to square feet
        switch (unit) {
            case 'feet':
                return value;
            case 'inches':
                return value / 144; // 1 square foot = 144 square inches
            case 'centimeters':
                return value / 929.03; // 1 square foot = 929.03 square centimeters
            case 'meters':
                return value / 10.764; // 1 square foot = 10.764 square meters
            default:
                return 0;
        }
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_weight_calculator', 'roof_weight_calculator_shortcode');


function rafter_layout_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Rafter Layout Calculator</h1>
            <form id="rafterLayoutCalculatorForm">
                <div class="form-group">
                    <label for="span">Span:</label>
                    <input type="number" id="span" class="form-input" step="any" required>
                    <select id="spanUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pitch">Pitch:</label>
                    <input type="number" id="pitch" class="form-input" step="any" required>
                    <select id="pitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRafterLayout()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRafterLayout() {
        const span = parseFloat(document.getElementById('span').value);
        const spanUnit = document.getElementById('spanUnit').value;
        let pitch = parseFloat(document.getElementById('pitch').value);
        const pitchUnit = document.getElementById('pitchUnit').value;

        if (isNaN(span) || isNaN(pitch)) {
            alert('Please enter valid numbers for span and pitch.');
            return;
        }

        let spanInInches = convertToInches(span, spanUnit);

        if (pitchUnit === 'degrees') {
            // Convert degrees pitch to in/12 pitch
            pitch = degreesToPitch(pitch);
        }

        // Example calculation:
        const rafterLength = calculateRafterLength(spanInInches, pitch);

        // Prepare result and explanation texts
        const resultText = `Rafter Layout Calculation: Length ${rafterLength.toFixed(2)} inches`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Span: ${span} ${spanUnit}</p>
            <p>Pitch: ${pitch} ${pitchUnit}</p>
            <p>Rafter Length: ${rafterLength.toFixed(2)} inches</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        // Convert dimensions to inches
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function degreesToPitch(degrees) {
        // Convert degrees pitch to in/12 pitch (example conversion, adjust as needed)
        return Math.tan(degrees * (Math.PI / 180)) * 12;
    }

    function calculateRafterLength(spanInInches, pitch) {
        // Example calculation for rafter length (customize based on actual formula)
        const length = Math.sqrt(Math.pow(spanInInches, 2) + Math.pow(pitch, 2));
        return length;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('rafter_layout_calculator', 'rafter_layout_calculator_shortcode');


function roof_rake_calculator_shortcode() {
    ob_start();
    ?>
    <div class="calculator-container">
        <div class="calculator">
            <h1>Roof Rake Calculator</h1>
            <form id="roofRakeCalculatorForm">
                <div class="form-group">
                    <label for="roofPitch">Roof Pitch:</label>
                    <input type="number" id="roofPitch" class="form-input" step="any" required>
                    <select id="roofPitchUnit" class="form-select">
                        <option value="in12">In/12</option>
                        <option value="degrees">Degrees</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="eavesHeight">Eaves Height:</label>
                    <input type="number" id="eavesHeight" class="form-input" step="any" required>
                    <select id="eavesHeightUnit" class="form-select">
                        <option value="feet">Feet</option>
                        <option value="inches">Inches</option>
                        <option value="meters">Meters</option>
                        <option value="centimeters">Centimeters</option>
                    </select>
                </div>
                <button type="button" onclick="calculateRoofRake()" class="form-button">Calculate</button>
            </form>
            <div id="result" class="result-text"></div>
            <div id="explanation" class="explanation-text"></div>
        </div>
    </div>

    <script>
    function calculateRoofRake() {
        const roofPitch = parseFloat(document.getElementById('roofPitch').value);
        const roofPitchUnit = document.getElementById('roofPitchUnit').value;
        const eavesHeight = parseFloat(document.getElementById('eavesHeight').value);
        const eavesHeightUnit = document.getElementById('eavesHeightUnit').value;

        if (isNaN(roofPitch) || isNaN(eavesHeight)) {
            alert('Please enter valid numbers for roof pitch and eaves height.');
            return;
        }

        let pitchFactor = 1;
        if (roofPitchUnit === 'degrees') {
            // Convert degrees pitch to in/12 pitch
            pitchFactor = degreesToPitch(roofPitch);
        } else {
            pitchFactor = roofPitch;
        }

        // Convert eaves height to inches for calculation
        const eavesHeightInInches = convertToInches(eavesHeight, eavesHeightUnit);

        // Calculate roof rake length
        const roofRakeLength = pitchFactor * eavesHeightInInches;

        // Prepare result and explanation texts
        const resultText = `Roof Rake Length: ${roofRakeLength.toFixed(2)} inches`;
        const explanationText = `
            <h2 style="text-align: center;margin-top:10px;">Calculation Details</h2>
            <p>Roof Pitch: ${roofPitch} ${roofPitchUnit}</p>
            <p>Eaves Height: ${eavesHeight} ${eavesHeightUnit}</p>
            <p>Roof Rake Length: ${roofRakeLength.toFixed(2)} inches</p>
        `;

        // Display results
        document.getElementById('result').innerHTML = resultText;
        document.getElementById('result').style.display = 'block';

        document.getElementById('explanation').innerHTML = explanationText;
        document.getElementById('explanation').style.display = 'block';
    }

    function convertToInches(value, unit) {
        // Convert dimensions to inches
        switch (unit) {
            case 'inches':
                return value;
            case 'feet':
                return value * 12; // 1 foot = 12 inches
            case 'centimeters':
                return value / 2.54; // 1 centimeter = 0.393701 inches
            case 'meters':
                return value * 39.3701; // 1 meter = 39.3701 inches
            default:
                return 0;
        }
    }

    function degreesToPitch(degrees) {
        // Convert degrees pitch to in/12 pitch (example conversion, adjust as needed)
        return Math.tan(degrees * (Math.PI / 180)) * 12;
    }
    </script>

    <?php
    return ob_get_clean();
}

add_shortcode('roof_rake_calculator', 'roof_rake_calculator_shortcode');
























// Add shortcode for listing calculator pages in the sidebar
function custom_calculator_list_shortcode() {
    // Pages to omit
    $omit_pages = array(
        'about',
        'contact',
        'home',
        'privacy-policy',
        'disclaimer',
        'terms-and-conditions',
        // Add more slugs of pages you want to omit
    );

    // Get all pages
    $pages = get_pages();
    
    // Filter out the omitted pages
    $filtered_pages = array_filter($pages, function($page) use ($omit_pages) {
        return !in_array($page->post_name, $omit_pages);
    });

    // Shuffle and get only 20 pages
    $filtered_pages = array_values($filtered_pages);
    shuffle($filtered_pages);
    $filtered_pages = array_slice($filtered_pages, 0, 20);

    // Sort the selected pages in ascending order based on the first letter of their titles
    usort($filtered_pages, function($a, $b) {
        return strcmp(substr($a->post_title, 0, 1), substr($b->post_title, 0, 1));
    });
    
    // Start output buffer
    ob_start();
    
    echo '<div class="calculator-list">';
    echo '<ul>';

    // Loop through the filtered pages and create list items
    foreach ($filtered_pages as $page) {
        echo '<li><a href="' . get_permalink($page->ID) . '">' . $page->post_title . '</a></li>';
    }

    echo '</ul>';
    echo '</div>';
    
    // Return the output buffer content
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('custom_calculator_list', 'custom_calculator_list_shortcode');

// Add CSS to style the list
function custom_calculator_list_styles() {
    echo '
    <style>
    .calculator-list ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .calculator-list li {
        margin-bottom: 10px;
    }

    .calculator-list a {
        display: block;
        padding: 10px 15px;
        text-decoration: none;
        color: #ffffff; /* Default link color */
        background-color: #0073aa; /* Default background color */
        border: 1px solid #0073aa;
        border-radius: 5px;
        text-align: center;
        transition: all 0.3s ease;
    }

    .calculator-list a:hover {
        color: #0073aa; /* Hover link color */
        background-color: #ffffff; /* Hover background color */
        border-color: #0073aa; /* Hover border color */
    }
    </style>
    ';
}
add_action('wp_head', 'custom_calculator_list_styles');

//function for the front page display
function calculator_front_page_shortcode() {
    ob_start();
    ?>



    <div class="calculator-front-page">
		
        <h2>Search Construction Calculators</h2>
        <!-- Search Bar -->
        <input type="text" id="calculator-search" placeholder="Search Construction calculators">

        <h2>Construction Calculators</h2>
        <!-- Calculator Cards -->
        <div class="calculator-cards">
            <?php
            $omit_pages = array(
                'about',
                'contact',
                'privacy-policy',
                'disclaimer',
                'terms-and-conditions',
				'test-page',
				'home'
                // Add more slugs of pages you want to omit
            );

            $args = array(
                'post_type' => 'page',
                'posts_per_page' => -1, // Get all pages
                'post_status' => 'publish',
                'orderby' => 'title',
                'order' => 'ASC'
            );
            $query = new WP_Query($args);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    $slug = get_post_field('post_name', get_post());
                    if (in_array($slug, $omit_pages)) {
                        continue; // Skip omitted pages
                    }
                    ?>
                    <a href="<?php the_permalink(); ?>" class="calculator-card"  >
                        <h3><?php the_title(); ?></h3>
                        <!-- Additional calculator details can go here -->
                    </a>
                <?php endwhile;
            else :
                echo 'No calculators found.';
            endif;
            wp_reset_postdata();
            ?>
        </div>
    </div>

    <style>
        .calculator-front-page {
            font-family: Arial, sans-serif;
            margin: 20px;
            text-align: center;
        }

        .calculator-front-page h2 {
            margin-top: 20px;
            font-size: 24px;
        }

        #calculator-search {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .calculator-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            grid-gap: 20px;
        }

        .calculator-card {
            background-color: #0073aa;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Added transition for background color */
            text-decoration: none;
            color: #0073aa; /* Default text color */
            display: flex;
            justify-content: center;
            align-items: center;
        }

       .calculator-card:hover {
    color: #0073aa; /* Change text color to blue on hover */
    background-color: #ffffff;
    border-color: #0073aa;
    cursor: pointer;
}

.calculator-card:hover h3 {
    color: #0073aa; /* Change text color to blue on hover */
}



        .calculator-card h3 {
            margin-top: 0;
            font-size: 18px;
            color: #fff;
        }
		
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('calculator-search');
            const calculatorCards = document.querySelectorAll('.calculator-card');

            searchInput.addEventListener('input', function () {
                const searchTerm = this.value.toLowerCase().trim();

                calculatorCards.forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    if (title.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('calculator_front_page', 'calculator_front_page_shortcode');



?>
